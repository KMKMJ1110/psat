# No.70 재현 코드

No.70 = 69 + GFS 추가 변수 34개 + 앙상블 비율 변경
      = [53번 트리 + GFS 일사량 63개 + GFS 추가 변수 34개] 30 : MLP(명준 54번) 10 : 발전소별 TabPFN-2(+ GFS 15개) 60
      + 시간별 배율 + 그리디 그룹
검증 (No.2 = Baseline + 학습 기간 전체, 날짜 60/20/20 seed 42): holdout 최적 51,294,355

`codes` 폴더에 넣고 데이터 폴더(baseline.py 있는 곳)에서 순서대로 실행 (.venv\Scripts\python.exe)

## 1. 외부 예보 GFS 받기 (NOAA, 인증키 없음)
    python codes\gfs_download.py  --start 2021-02-27 --end 2026-06-01 --workers 8   # 일사량 DSWRF
    python codes\check_gfs_time.py                                                 # 공개 시각 근거 -> publish_check.csv
    python codes\gfs_download2.py --start 2021-02-27 --end 2026-06-01 --workers 8   # 구름층·기온·강수·가강수량
    python codes\gfs_features.py      # -> output/external/gfs_features.parquet  (63개)
    python codes\gfs2_features.py     # -> output/external/gfs2_features.parquet (34개)
  (이미 받은 gfs 폴더/압축본이 있으면 다운로드는 건너뛰고 features 부터)

## 2. 검증 (점수 확인, 비율 정하기)
    python codes\gfs_tree.py      # 63번 트리 -> output/feat_gfs/random
    python codes\gfs_tabpfn.py    # GFS TabPFN -> output/site_tabpfn/random_gfs   (GPU, 9시간 안팎)
    python codes\gfs2_tree.py     # 70번 트리 + 비율 비교 -> output/feat_gfs2/random

## 3. 평가 기간 예측 + 제출 파일
    python codes\test_tree.py --gfs --gfs2   # -> output/submit_final/test_tree_gfs2.parquet (CPU 1시간)
    python codes\test_tabpfn.py --gfs        # -> test_tabpfn_gfs.parquet (GPU 14시간 안팎)
    python codes\test_mlp.py                 # -> test_mlp.parquet (CPU 수십 분)
    python codes\make_submission.py --name submit_70 --tree gfs2 --tab gfs --w 0.3 0.1 0.6
  -> output/submit_final/submit_70/composition.csv, forecast.csv
  확인: '검증 holdout 최적: 51,294,355' / composition 254행 / forecast 17,521행 / 음수·빈 값 0

## 필요한 기존 것
- output: preprocessed/train, preprocessed/test, feat_site/random(53번), sleeping_ranking_50(명준 MLP 검증 예측)
- test_tabpfn, gfs_tabpfn 은 꺼져도 다시 실행하면 끝난 발전소부터 이어서 함

## 규칙 근거
- 규칙 6: 대상일 D 는 D-1 00 UTC(09시 KST) GFS 실행분만 사용. 보통 D-1 12:45 KST 공개 (마감 17:00 전).
  근거 = output/external/gfs/publish_check.csv (파일 Last-Modified vs 마감)
- 규칙 7: GFS 는 한국 상자 요약·고정 1도 칸·PCA 등 모든 발전소에 같은 값. 좌표로 격자 고르기 안 함.
  PCA 는 평가 기간(2025-06) 이전 자료로만 맞춤
- 출처: NOAA GFS (AWS noaa-gfs-bdp-pds), TabPFN-2 (Apache 2.0, "Built with PriorLabs-TabPFN")
