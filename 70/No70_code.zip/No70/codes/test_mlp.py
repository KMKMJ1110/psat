"""제출용 2/3: No.54 MLP (명준, 하루 24시간 한 번에 예측) 를 학습 기간 전체로 다시 학습 -> 평가 기간 예측.
위치: codes/test_mlp.py
실행: python codes/test_mlp.py      (CPU, 수십 분)
결과: output/submit_final/test_mlp.parquet  (site_id, ts, kwh)  <- MLP 단독 예측 (트리와 섞기 전)

명준 _neural.py rank_17 과 같은 구조·설정:
  입력 = 하루 24시간 x [wa_cloud, wb_cloud, wa_temp, wb_temp, wb_uv_idx, elev, cosz, cap] (17시판)
  발전소 embedding 12 + 256 -> 128 -> 24, dropout 0.1, Smooth L1(beta 0.05), AdamW(lr 1e-3, wd 1e-4)
  epoch 8, batch 512, 학습 발전소-날짜 최대 160,000개 (seed 42), 24시간이 다 있는 날만 학습
다른 점: 학습 데이터만 '전체'. 명준과 같이 시드 5개(2, 3, 5, 7, 11)로 각각 학습해서 예측 평균.
"""
import numpy as np
import pandas as pd
import torch
from torch import nn
import torch.nn.functional as F
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

import baseline_validation as val
import submit_common as sc

FCOLS = ["wa_cloud", "wb_cloud", "wa_temp", "wb_temp", "wb_uv_idx", "elev", "cosz", "cap"]
MAX_TRAIN = 160000
EPOCHS = 8
SEEDS = [2, 3, 5, 7, 11]


def pack(d, with_y):
    """발전소 x 배송일(01시~24시) 로 묶어서 24시간이 다 있는 날만 한 줄로 펼침"""
    d = d.copy()
    d["_day"] = (d["ts"] - pd.Timedelta(hours=1)).dt.normalize()
    d = d.sort_values(["site_id", "_day", "ts"])
    size = d.groupby(["site_id", "_day"], sort=False)["ts"].transform("size")
    d = d[size == 24]
    n = len(d) // 24
    X = d[FCOLS].to_numpy("float32").reshape(n, 24 * len(FCOLS))
    if with_y:
        Y = (d["energy"] / d["cap"]).clip(0, 1.2).to_numpy("float32").reshape(n, 24)
    else:
        Y = None
    site_ids = d["site_id"].to_numpy().reshape(n, 24)[:, 0]
    keys = d[["site_id", "ts"]].reset_index(drop=True)
    return X, Y, site_ids, keys


class DayDense(nn.Module):
    def __init__(self, nf, nsite):
        super().__init__()
        self.emb = nn.Embedding(nsite, 12)
        self.mlp = nn.Sequential(nn.Linear(nf + 12, 256), nn.ReLU(), nn.Dropout(0.1),
                                 nn.Linear(256, 128), nn.ReLU(), nn.Linear(128, 24))

    def forward(self, x, i):
        return self.mlp(torch.cat([x, self.emb(i)], dim=1))


def main():
    sc.OUT.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    base = val.load_module(sc.ROOT / "baseline.py", "oibc_baseline_testmlp")
    sites = sc.load_sites()
    mapping = {}
    for i, s in enumerate(sites["site_id"]):
        mapping[s] = i

    # 학습
    gen = sc.load_gen_all()
    fa, fb = sc.load_weather_train(base, gen["ts"].min())
    xtr = base.features(gen, sites, fa, fb, None, 17)
    del fa, fb, gen
    X, Y, sids, _ = pack(xtr, True)
    del xtr
    print("학습 발전소-날짜:", len(X))
    if len(X) > MAX_TRAIN:
        rng = np.random.default_rng(42)
        ix = rng.choice(len(X), MAX_TRAIN, replace=False)
        X = X[ix]
        Y = Y[ix]
        sids = sids[ix]
    im = SimpleImputer(strategy="median")
    scl = StandardScaler()
    X = scl.fit_transform(im.fit_transform(X)).astype("float32")
    idx = np.array([mapping[s] for s in sids], dtype="int64")

    models = []
    for seed in SEEDS:
        torch.manual_seed(seed)
        model = DayDense(X.shape[1], len(mapping))
        opt = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=1e-4)
        ds = torch.utils.data.TensorDataset(torch.tensor(X), torch.tensor(Y), torch.tensor(idx))
        loader = torch.utils.data.DataLoader(ds, batch_size=512, shuffle=True, num_workers=0)
        for e in range(EPOCHS):
            model.train()
            losses = []
            for xb, yb, ib in loader:
                opt.zero_grad()
                loss = F.smooth_l1_loss(model(xb, ib), yb, beta=0.05)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()
                losses.append(float(loss.detach()))
            print(f"seed {seed} epoch {e + 1}/{EPOCHS} mean_smoothL1={np.mean(losses):.6f}")
        torch.save({"state": model.state_dict(), "features": FCOLS, "seed": seed},
                   sc.OUT / ("test_mlp_model_seed" + str(seed) + ".pt"))
        models.append(model)

    # 평가 기간 예측
    grid = sc.test_grid(sites)
    fa_te, fb_te = sc.load_weather_test(base)
    xte = base.features(grid, sites, fa_te, fb_te, None, 17)
    Xt, _, sids_t, keys = pack(xte, False)
    Xt = scl.transform(im.transform(Xt)).astype("float32")
    it = np.array([mapping[s] for s in sids_t], dtype="int64")
    all_seeds = []
    with torch.no_grad():
        for model in models:
            model.eval()
            preds = []
            for p in range(0, len(Xt), 4096):
                preds.append(model(torch.tensor(Xt[p:p + 4096]), torch.tensor(it[p:p + 4096])).numpy())
            all_seeds.append(np.vstack(preds))
    preds = [np.mean(all_seeds, axis=0)]      # 시드 5개 평균
    cf = np.clip(np.vstack(preds).reshape(-1), 0, 1.2)
    keys["cf"] = cf

    out = xte[["site_id", "ts", "cap", "elev"]].merge(keys, on=["site_id", "ts"], how="left")
    print("24시간이 다 안 맞아 MLP 예측이 없는 행:", int(out["cf"].isna().sum()), "(0으로 둠)")
    out["cf"] = out["cf"].fillna(0.0)
    out.loc[out["elev"] <= 0, "cf"] = 0.0
    out["kwh"] = out["cf"] * out["cap"]
    out = out[["site_id", "ts", "kwh"]]
    out.to_parquet(sc.OUT / "test_mlp.parquet", index=False)
    print("저장:", sc.OUT / "test_mlp.parquet", len(out), "행")


if __name__ == "__main__":
    main()
