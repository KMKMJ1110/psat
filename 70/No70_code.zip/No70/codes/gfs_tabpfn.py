"""검증: 발전소별 TabPFN (큰 설정, No.60) + GFS 피처 15개 -> 섞기 비교 (65번).
위치: codes/gfs_tabpfn.py
실행: .venv\\Scripts\\python.exe codes\\gfs_tabpfn.py     (GPU, 12시간 안팎. 꺼져도 다시 실행하면 끝난 발전소는 건너뜀)
필요: output/external/gfs_features.parquet, output/feat_gfs/random/ (63번 GFS 트리),
      output/sleeping_ranking_50/ (명준 MLP), output/site_tabpfn/random_big/ (60번 TabPFN, 비교용)
결과: output/site_tabpfn/random_gfs/tabpfn_eval_pred.parquet, sites/, result.csv

60번과 같은 것: 학습·검증 날짜, 17시판 예보, 기존 피처 64개, 발전소별 최대 10,000행, n_estimators 8, 중앙값
다른 것: GFS 피처 15개 추가 (모든 발전소 같은 값)
  gfs_mean, gfs_std, gfs_max, gfs_pc1~8, gfs_mean_prev, gfs_mean_next, gfs_mean_daysum, gfs_mean_daymax
  (1도 칸 48개는 TabPFN 이 느려져서 뺌. 지역 차이는 PCA 8개가 담당)
섞기: GFS 트리(63) + MLP(54) + 이 TabPFN, 비율은 group_opt 기준으로 고르기
  후보: TabPFN 40~90, MLP 0~20, 나머지 트리 (1차 후보에서 TabPFN 60 = 끝값이 최선이라 넓힘)
  빈 칸 채우기·밤 0 은 make_submission 과 같게 (GFS 트리 기준) -> 64번도 같은 방식으로 다시 계산 (53,347,718)
TabPFN-2 고정 (Apache 2.0 + 출처 표기 "Built with PriorLabs-TabPFN")
"""
import os
os.environ["TABPFN_DISABLE_TELEMETRY"] = "1"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL"] = "1"

import time
import numpy as np
import pandas as pd
import torch

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs
import mix_all as mx

ROOT = val.DEFAULT_ROOT
opt.log = lambda message: None
OUT = ROOT / "output" / "site_tabpfn" / "random_gfs"
SITE_DIR = OUT / "sites"
TAB_OLD = ROOT / "output" / "site_tabpfn" / "random_big" / "tabpfn_eval_pred.parquet"
TREE_GFS = ROOT / "output" / "feat_gfs" / "random"
GFS_PATH = ROOT / "output" / "external" / "gfs_features.parquet"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_CTX = 10000
N_EST = 8
ROUND = 17
CHUNK = 500
GFS_USE = ["gfs_mean", "gfs_std", "gfs_max"] + ["gfs_pc" + str(k) for k in range(1, 9)] + \
          ["gfs_mean_prev", "gfs_mean_next", "gfs_mean_daysum", "gfs_mean_daymax"]


def fit_predict_site(X_tr, y_tr, X_te):
    from tabpfn import TabPFNRegressor
    from tabpfn.constants import ModelVersion
    model = TabPFNRegressor.create_default_for_version(ModelVersion.V2, device=DEVICE,
                                                       random_state=42, n_estimators=N_EST)
    model.fit(X_tr, y_tr)
    preds = []
    for start in range(0, len(X_te), CHUNK):
        preds.append(model.predict(X_te[start:start + CHUNK], output_type="median"))
    return np.concatenate(preds)


def score(pred, sites, group_actual, hold_actual):
    """시간별 배율 -> 그리디 -> holdout 점수"""
    Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
    Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
    wg = opt.time_weights(ROOT, tg)
    c_hour = {}
    for h in range(24):
        idx = (tg.hour == h)
        if idx.sum() == 0:
            c_hour[h] = 1.0
        else:
            c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])
    cg = np.array([c_hour[h] for h in tg.hour])[:, None]
    ch = np.array([c_hour[h] for h in th.hour])[:, None]
    init_mask = opt.initial_mask(sites)
    optimized, meta, trace = opt.greedy_best_improvement(cg * Pg - Yg, wg, sites, init_mask)
    sg = val.score_group(opt, ROOT, cg * Pg - Yg, tg, init_mask, optimized)
    sh = val.score_group(opt, ROOT, ch * Ph - Yh, th, init_mask, optimized)
    pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
    pred_h["pred_kwh"] = pred_h["pred_kwh"] * pred_h["ts"].dt.hour.map(c_hour)
    m_h = val.model_metrics(ROOT, hold_actual, pred_h)
    return {"weighted_MAE": round(m_h["weighted_MAE_kwh"], 5),
            "group_opt_optimized": round(sg["W_optimized_krw"]),
            "initial": round(sh["W_initial_krw"]),
            "optimized": round(sh["W_optimized_krw"]),
            "lower_bound": round(sh["W_lower_bound_krw"])}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    SITE_DIR.mkdir(parents=True, exist_ok=True)
    print("장치:", DEVICE)
    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_gfstabpfn")

    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]
    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    model_fit, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    model_fit = pd.concat([gen[gen["ts"] < base.TRAIN_FROM], model_fit], ignore_index=True)
    eval_actual = pd.concat([group_actual, hold_actual], ignore_index=True)
    del gen, baseline_gen

    gfs = pd.read_parquet(GFS_PATH, columns=["ts"] + GFS_USE)
    if getattr(model_fit["ts"].dt, "tz", None) is not None:
        gfs["ts"] = gfs["ts"].dt.tz_localize(model_fit["ts"].dt.tz)

    # 피처 = 60번과 같은 64개 + GFS 15개
    new_feats = []
    for c in fs.A_COLS + fs.B_COLS:
        new_feats = new_feats + [c + "_prev", c + "_next", c + "_daymean"]
    new_feats.append("cloud_diff")
    new_feats = new_feats + fs.NAT_FEATS + fs.F3_FEATS
    feats = []
    for c in list(base.FEATS) + new_feats:
        if c not in ["lat", "lon", "cap"]:
            feats.append(c)
    print("기존 피처:", len(feats), "/ + GFS", len(GFS_USE), "=", len(feats) + len(GFS_USE))
    feats = feats + GFS_USE

    original_features = base.features

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        n = len(d)
        d = d.merge(gfs, on="ts", how="left")
        if len(d) != n:
            raise ValueError("GFS 붙이다가 행 수가 바뀜")
        return d

    base.features = features_plus

    fa, fb = val.load_weather(ROOT, base, model_fit["ts"].min())
    fa, _ = fs.add_time_feats(fa, "wa_station", fs.A_COLS)
    fb, _ = fs.add_time_feats(fb, "wb_station", fs.B_COLS)
    fa = fs.drop_next_at_midnight(fa, fs.A_COLS)
    fb = fs.drop_next_at_midnight(fb, fs.B_COLS)
    fa, fb = fs.add_national(fa, fb)
    fa = fs.add_feat3(fa, "wa_station", "wa_cloud")
    fb = fs.add_feat3(fb, "wb_station", "wb_cloud")

    print("피처 만드는 중 ...")
    tr = base.features(model_fit, sites, fa, fb, None, ROUND)
    tr = tr[tr["elev"] > 0]
    tr = tr[["site_id", "energy", "cap"] + feats].copy()
    tr["y"] = (tr["energy"] / tr["cap"]).clip(0, 1.2)
    ev = base.features(eval_actual, sites, fa, fb, None, ROUND)
    if len(ev) != len(eval_actual):
        raise ValueError("평가 행 수가 바뀜")
    ev_day = ev[ev["elev"] > 0][["site_id", "ts", "cap"] + feats].copy()
    del fa, fb, model_fit
    print("학습 낮 행:", len(tr), "/ 평가 낮 행:", len(ev_day),
          "/ 평가 낮 행 중 GFS 빈 값:", int(ev_day["gfs_mean"].isna().sum()))

    # ---------- 1. 발전소별 TabPFN ----------
    tr_groups = dict(list(tr.groupby("site_id")))
    ev_groups = dict(list(ev_day.groupby("site_id")))
    rng = np.random.default_rng(42)
    site_list = list(sites["site_id"])
    started = time.time()
    for i, site in enumerate(site_list):
        t = tr_groups.get(site)
        if t is not None and len(t) > MAX_CTX:      # 다시 실행해도 같은 행을 뽑도록 항상 뽑음
            pick = np.sort(rng.choice(len(t), MAX_CTX, replace=False))
        else:
            pick = None
        path = SITE_DIR / (site + ".parquet")
        if path.exists() or site not in ev_groups:
            continue
        e = ev_groups[site]
        if t is None or len(t) < 200:
            print(site, ": 학습 행이 너무 적어서 건너뜀")
            continue
        if pick is not None:
            t = t.iloc[pick]
        cf = fit_predict_site(t[feats].to_numpy(np.float32), t["y"].to_numpy(np.float32),
                              e[feats].to_numpy(np.float32))
        out = e[["site_id", "ts"]].copy()
        out["pred_kwh"] = np.clip(cf, 0, 1.2) * e["cap"].to_numpy()
        out.to_parquet(path, index=False)
        spent = time.time() - started
        print(f"[{i + 1}/{len(site_list)}] {site} 학습 {len(t):,}행 / 예측 {len(e):,}행 / 누적 {spent / 60:.1f}분")

    parts = []
    for site in site_list:
        path = SITE_DIR / (site + ".parquet")
        if path.exists():
            parts.append(pd.read_parquet(path))
    allp = ev[["site_id", "ts"]].merge(pd.concat(parts, ignore_index=True), on=["site_id", "ts"], how="left")
    allp["pred_kwh"] = allp["pred_kwh"].fillna(0.0)
    allp.to_parquet(OUT / "tabpfn_eval_pred.parquet", index=False)
    print("저장:", OUT / "tabpfn_eval_pred.parquet")

    # ---------- 2. 섞기 비교 ----------
    pa = pd.read_parquet(TREE_GFS / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(TREE_GFS / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    d = both[["site_id", "ts"]].copy()
    d["tree"] = 0.75 * both["pred_kwh_a"] + 0.25 * both["pred_kwh_b"]
    d = d.merge(mx.load_mlp(), on=["site_id", "ts"], how="left")
    old = pd.read_parquet(TAB_OLD).rename(columns={"pred_kwh": "tab_old"})
    old["ts"] = val.to_kst(old["ts"])
    d = d.merge(old, on=["site_id", "ts"], how="left")
    new = allp.rename(columns={"pred_kwh": "tab_gfs"})
    d = d.merge(new, on=["site_id", "ts"], how="left")
    d["mlp"] = d["mlp_kwh"].fillna(d["tree"])
    d["tab_old"] = d["tab_old"].fillna(d["tree"])
    d["tab_gfs"] = d["tab_gfs"].fillna(d["tree"])
    night = d["tree"] <= 0
    d.loc[night, ["mlp", "tab_old", "tab_gfs"]] = 0.0

    cands = [("GFS TabPFN 단독", "tab_gfs", 0.0, 0.0, 1.0),
             ("64번 (TabPFN GFS 없음) 60 : 20 : 20", "tab_old", 0.6, 0.2, 0.2)]
    for w_tab in [0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
        for w_mlp in [0.0, 0.1, 0.2]:
            w_tree = round(1 - w_tab - w_mlp, 2)
            if w_tree < 0.0:
                continue
            label = ("GFS 트리 " + str(int(round(w_tree * 100))) + " : MLP " + str(int(round(w_mlp * 100)))
                     + " : GFS TabPFN " + str(int(round(w_tab * 100))))
            cands.append((label, "tab_gfs", w_tree, w_mlp, w_tab))

    rows = []
    for label, tcol, w_tree, w_mlp, w_tab in cands:
        pred = d[["site_id", "ts"]].copy()
        pred["pred_kwh"] = w_tree * d["tree"] + w_mlp * d["mlp"] + w_tab * d[tcol]
        r = {"blend": label, **score(pred, sites, group_actual, hold_actual)}
        rows.append(r)
        print(label, "| 최적", f"{r['optimized']:,}", "| group_opt", f"{r['group_opt_optimized']:,}")

    table = pd.DataFrame(rows)
    table.to_csv(OUT / "result.csv", index=False)
    mix_rows = table[table["blend"].str.startswith("GFS 트리 ")]
    best = mix_rows.loc[mix_rows["group_opt_optimized"].idxmin()]
    print("=" * 70)
    print("비교: 64번 = 53,347,718 (제출 코드와 같은 채우기 방식)")
    print(table.to_string(index=False))
    print("-" * 70)
    print("group_opt 기준 최선:", best["blend"], "-> holdout 최적", f"{best['optimized']:,}")


if __name__ == "__main__":
    main()
