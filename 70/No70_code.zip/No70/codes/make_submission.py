"""제출 파일 만들기: 그룹(검증 group_opt 로 정함) + 평가 기간 예측 섞기 + 시간별 배율.
위치: codes/make_submission.py
실행:
  python codes/make_submission.py --name submit_60 --w 0.2 0.3 0.5    # No.60 트리 20 : MLP 30 : TabPFN(큰 설정) 50
  python codes/make_submission.py --name submit_56 --w 0.6 0.4 0.0    # No.56 트리 60 : MLP 40 (TabPFN 없음, 예비)
  python codes/make_submission.py --name submit_gfs --tree gfs --w 0.6 0.2 0.2   # 64번 GFS 트리 (gfs_tree.py + test_tree.py --gfs)
  python codes/make_submission.py --name submit_65 --tree gfs --tab gfs --w 0.3 0.1 0.6   # 65번 + GFS TabPFN (gfs_tabpfn.py + test_tabpfn.py --gfs)
  python codes/make_submission.py --name submit_icl --tree gfs2 --tab gfs --w 0.3 0.1 0.15 --icl 0.45   # + TabICL (gfs_tabicl.py + test_tabicl.py)
필요:
  검증 예측 (그룹·배율 정하기): output/feat_site/random/, output/sleeping_ranking_50/, output/site_tabpfn/random_big/ (큰 설정 1만 행·n_est 8)
  평가 기간 예측: output/submit_final/test_tree.parquet, test_mlp.parquet, test_tabpfn.parquet (TabPFN 비율 0이면 없어도 됨)
결과: output/submit_final/<name>/composition.csv, forecast.csv

순서 (검증 No.56·58 과 똑같이)
  1. 검증 group_opt 날짜: 세 예측을 같은 비율로 섞음 -> 시각별 배율 c(0~23시) 계산 -> 배율 곱한 오차로 그리디 -> 그룹
     (holdout 점수도 같이 출력 -> 시트 값과 같은지 확인용)
  2. 평가 기간: 세 예측을 같은 비율로 섞음 -> 밤 0 -> 같은 배율 c 곱함 -> 그룹별 합계
"""
import argparse

import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs
import mix_all as mx
import submit_common as sc

opt.log = lambda message: None


def validation_frame(use_tab, tree_kind, tab_kind, use_icl=False):
    if tree_kind == "gfs":
        folder = sc.ROOT / "output" / "feat_gfs" / "random"
    elif tree_kind == "gfs2":
        folder = sc.ROOT / "output" / "feat_gfs2" / "random"
    elif tree_kind == "ec":
        folder = sc.ROOT / "output" / "feat_ec" / "random"
    elif tree_kind == "gefs":
        folder = sc.ROOT / "output" / "feat_gefs" / "random"
    elif tree_kind == "asos":
        folder = sc.ROOT / "output" / "feat_asos" / "random"
    else:
        folder = mx.OURS
    pa = pd.read_parquet(folder / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(folder / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    d = both[["site_id", "ts"]].copy()
    d["tree"] = mx.WA * both["pred_kwh_a"] + (1 - mx.WA) * both["pred_kwh_b"]
    mlp = mx.load_mlp()
    d = d.merge(mlp, on=["site_id", "ts"], how="left")
    d["mlp"] = d["mlp_kwh"].fillna(d["tree"])
    if use_tab:
        tab_folder = "random_gfs" if tab_kind == "gfs" else "random_big"
        tab = pd.read_parquet(sc.ROOT / "output" / "site_tabpfn" / tab_folder / "tabpfn_eval_pred.parquet")
        tab = tab.rename(columns={"pred_kwh": "tab"})
        tab["ts"] = val.to_kst(tab["ts"])
        d = d.merge(tab, on=["site_id", "ts"], how="left")
        d["tab"] = d["tab"].fillna(d["tree"])
    else:
        d["tab"] = 0.0
    if use_icl:
        icl = pd.read_parquet(sc.ROOT / "output" / "site_tabicl" / "random_gfs" / "tabicl_eval_pred.parquet")
        icl = icl.rename(columns={"pred_kwh": "icl"})
        icl["ts"] = val.to_kst(icl["ts"])
        d = d.merge(icl, on=["site_id", "ts"], how="left")
        d["icl"] = d["icl"].fillna(d["tree"])
    else:
        d["icl"] = 0.0
    night = d["tree"] <= 0
    d.loc[night, "mlp"] = 0.0
    d.loc[night, "tab"] = 0.0
    d.loc[night, "icl"] = 0.0
    return d


def test_frame(use_tab, tree_kind, tab_kind, use_icl=False):
    if tree_kind == "gfs":
        name = "test_tree_gfs.parquet"
    elif tree_kind == "gfs2":
        name = "test_tree_gfs2.parquet"
    elif tree_kind == "ec":
        name = "test_tree_ec.parquet"
    elif tree_kind == "gefs":
        name = "test_tree_gefs.parquet"
    elif tree_kind == "asos":
        name = "test_tree_asos.parquet"
    else:
        name = "test_tree.parquet"
    d = pd.read_parquet(sc.OUT / name).rename(columns={"kwh": "tree"})
    m = pd.read_parquet(sc.OUT / "test_mlp.parquet").rename(columns={"kwh": "mlp"})
    d = d.merge(m, on=["site_id", "ts"], how="left")
    if use_tab:
        tab_name = "test_tabpfn_gfs.parquet" if tab_kind == "gfs" else "test_tabpfn.parquet"
        t = pd.read_parquet(sc.OUT / tab_name).rename(columns={"kwh": "tab"})
        d = d.merge(t, on=["site_id", "ts"], how="left")
    else:
        d["tab"] = 0.0
    if use_icl:
        c = pd.read_parquet(sc.OUT / "test_tabicl_gfs.parquet").rename(columns={"kwh": "icl"})
        d = d.merge(c, on=["site_id", "ts"], how="left")
    else:
        d["icl"] = 0.0
    if d[["tree", "mlp", "tab", "icl"]].isna().any().any():
        raise ValueError("평가 기간 예측에 빈 값이 있음")
    night = d["tree"] <= 0
    d.loc[night, "mlp"] = 0.0
    d.loc[night, "tab"] = 0.0
    d.loc[night, "icl"] = 0.0
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="submit_60")
    ap.add_argument("--w", nargs=3, type=float, default=[0.2, 0.3, 0.5], metavar=("TREE", "MLP", "TAB"))
    ap.add_argument("--tree", default="old", choices=["old", "gfs", "gfs2", "ec", "gefs", "asos"], help="old = No.53 / gfs = GFS 트리(63) / gfs2 = + 추가 변수(70) / ec = + ECMWF / gefs = + GEFS / asos = + ASOS 전날 관측")
    ap.add_argument("--tab", default="old", choices=["old", "gfs"], help="old = No.60 TabPFN / gfs = GFS TabPFN (65번)")
    ap.add_argument("--icl", type=float, default=0.0, help="TabICL 비율 (트리+MLP+TabPFN+TabICL = 1)")
    args = ap.parse_args()
    w_tree, w_mlp, w_tab = args.w
    w_icl = args.icl
    if abs(w_tree + w_mlp + w_tab + w_icl - 1) > 1e-9:
        raise ValueError("비율 합이 1이 아님")
    use_tab = w_tab > 0
    use_icl = w_icl > 0
    out_dir = sc.OUT / args.name
    out_dir.mkdir(parents=True, exist_ok=True)
    print("트리:", args.tree, "/ TabPFN:", args.tab, "/ 비율 트리:MLP:TabPFN:TabICL =", w_tree, w_mlp, w_tab, w_icl)

    base = val.load_module(sc.ROOT / "baseline.py", "oibc_baseline_makesub")
    sites = sc.load_sites()
    cap = sites.set_index("site_id")["capacity_kw"]

    # ---------- 1. 검증 날짜로 배율 + 그룹 ----------
    gen = sc.load_gen_all()
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    _, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    del gen, baseline_gen

    d = validation_frame(use_tab, args.tree, args.tab, use_icl)
    pred = d[["site_id", "ts"]].copy()
    pred["pred_kwh"] = w_tree * d["tree"] + w_mlp * d["mlp"] + w_tab * d["tab"] + w_icl * d["icl"]
    Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
    Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
    wg = opt.time_weights(sc.ROOT, tg)
    c_hour = {}
    for h in range(24):
        idx = (tg.hour == h)
        if idx.sum() == 0:
            c_hour[h] = 1.0
        else:
            c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])
    cg = np.array([c_hour[h] for h in tg.hour])[:, None]
    ch = np.array([c_hour[h] for h in th.hour])[:, None]
    init_mask = opt.initial_mask(sites)
    optimized, meta, trace = opt.greedy_best_improvement(cg * Pg - Yg, wg, sites, init_mask)
    opt.check_capacity(optimized, sites.capacity_kw.to_numpy(np.float64))
    score_h = val.score_group(opt, sc.ROOT, ch * Ph - Yh, th, init_mask, optimized)
    print("검증 holdout 최적:", f"{round(score_h['W_optimized_krw']):,}", "(시트 값과 같아야 함)")
    pd.Series(c_hour, name="c").rename_axis("hour").to_csv(out_dir / "hour_scale.csv")

    group_of = pd.Series(np.where(optimized, "G1", "G2"), index=sites.site_id)
    comp = pd.DataFrame({"site_id": sites.site_id, "group": group_of.values})
    comp.to_csv(out_dir / "composition.csv", index=False)
    print("그룹: G1", int(optimized.sum()), "개", round(sites.capacity_kw[optimized].sum(), 1), "kW / G2",
          int((~optimized).sum()), "개", round(sites.capacity_kw[~optimized].sum(), 1), "kW")

    # ---------- 2. 평가 기간 예측 ----------
    t = test_frame(use_tab, args.tree, args.tab, use_icl)
    t["kwh"] = w_tree * t["tree"] + w_mlp * t["mlp"] + w_tab * t["tab"] + w_icl * t["icl"]
    t["kwh"] = t["kwh"] * t["ts"].dt.hour.map(c_hour).to_numpy()
    t["kwh"] = np.clip(t["kwh"].to_numpy(), 0, t["site_id"].map(cap).to_numpy())
    t[["site_id", "ts", "kwh"]].to_parquet(out_dir / "site_predictions.parquet", index=False)

    t["group"] = t["site_id"].map(group_of)
    fc = t.groupby(["group", "ts"], as_index=False)["kwh"].sum()
    fc = fc.rename(columns={"kwh": "forecast_kwh"}).sort_values(["group", "ts"])
    fc.to_csv(out_dir / "forecast.csv", index=False)

    print("=" * 60)
    print("composition.csv :", len(comp) + 1, "행 (헤더 포함, 정답 254)")
    print("forecast.csv    :", len(fc) + 1, "행 (헤더 포함, 정답 17,521)")
    print("음수 / 빈 값    :", int((fc["forecast_kwh"] < 0).sum()), "/", int(fc["forecast_kwh"].isna().sum()), "(정답 0 / 0)")
    print("그룹별 1년 합계 (GWh):", (fc.groupby("group")["forecast_kwh"].sum() / 1e6).round(2).to_dict())
    print("저장 위치:", out_dir)


if __name__ == "__main__":
    main()
