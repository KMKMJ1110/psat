"""외부 예보 2탄: NOAA GFS 구름(층별)·기온·강수·가강수량 받기 -> 한국 영역만 잘라 저장.
위치: codes/gfs_download2.py   (gfs_download.py 와 같은 실행분·같은 규칙, 변수만 다름)
실행:
  python codes/gfs_download2.py --start 2025-06-01 --end 2025-06-01 --workers 1   # 시험 (하루, 받은 변수 이름 출력)
  python codes/gfs_download2.py --start 2025-06-01 --end 2026-06-01 --workers 8   # 평가 기간 먼저
  python codes/gfs_download2.py --start 2021-02-27 --end 2026-06-01 --workers 8   # 전체 (받은 날은 건너뜀)
결과: output/external/gfs2/YYYYMMDD.npz  (변수마다 (24, 위도, 경도), 대상일 01~24시 KST)
      output/external/gfs2/download_log.csv

받는 변수 (GFS 0.25도 pgrb2, AWS noaa-gfs-bdp-pds)
  LCDC / MCDC / HCDC 낮은/중간/높은 구름층 구름 양 %, TCDC 전체 대기·경계층 구름 양 %
  TMP 지상 2m (기온), PRATE 지표 (강수율, 평균형), PWAT 전체 대기 (가강수량)
규칙: 대상일 D 는 D-1 00 UTC(= D-1 09시 KST) 실행분의 16~39시간 뒤 예보만 (gfs_download.py 와 같음, 보통 D-1 12:45 KST 공개)
      모든 발전소에 같은 값으로 쓸 것 (좌표로 격자 고르기 안 함)
'평균' 으로 저장된 변수(stepType avg)는 6시간 구간 평균 -> 1시간 평균으로 바꿈, 순간값(instant)은 그대로
"""
import argparse
import csv
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "output" / "external" / "gfs2"
TMP = OUT / "_tmp"
LAT_MIN, LAT_MAX = 33.0, 39.0
LON_MIN, LON_MAX = 124.0, 131.5
LEADS = list(range(13, 40))
# 낮은/중간/높은 구름은 GFS 에서 LCDC/MCDC/HCDC 라는 이름. 평균형이 있는 변수는 평균형만 받음 (순간값과 중복 방지)
SEARCH = (r":(?:LCDC|MCDC|HCDC):"
          r"|:TCDC:entire atmosphere:\d+-\d+ hour ave"
          r"|:TCDC:boundary layer cloud layer:"
          r"|:TMP:2 m above ground:"
          r"|:PRATE:surface:\d+-\d+ hour ave"
          r"|:PWAT:entire atmosphere")


def one_lead(run, n):
    """한 실행분의 n 시간 뒤 -> {변수이름: 2차원 배열}, 위도, 경도, 주소, 공개시각"""
    from herbie import Herbie
    import requests
    H = Herbie(run, model="gfs", product="pgrb2.0p25", fxx=n, priority=["aws"],
               save_dir=TMP, verbose=False)
    got = H.xarray(SEARCH, remove_grib=True)
    if not isinstance(got, list):
        got = [got]
    arrays = {}
    lats = None
    lons = None
    for ds in got:
        for var in ds.data_vars:
            da = ds[var]
            short = str(da.attrs.get("GRIB_shortName", var))
            level = str(da.attrs.get("GRIB_typeOfLevel", "lev"))
            step = str(da.attrs.get("GRIB_stepType", "instant"))
            key = (short + "_" + level + "_" + step).lower()
            da = da.sel(latitude=slice(LAT_MAX, LAT_MIN), longitude=slice(LON_MIN, LON_MAX))
            arrays[key] = da.values.astype("float32")
            lats = da["latitude"].values
            lons = da["longitude"].values
    last_mod = ""
    try:
        last_mod = requests.head(str(H.grib), timeout=30).headers.get("Last-Modified", "")
    except Exception:
        pass
    return arrays, lats, lons, str(H.grib), last_mod


def one_day(target_day):
    path = OUT / (target_day.strftime("%Y%m%d") + ".npz")
    if path.exists():
        return None
    run = (target_day - pd.Timedelta(days=1)).strftime("%Y-%m-%d 00:00")
    per_lead = {}
    info = ("", "")
    lats = None
    lons = None
    for n in LEADS:
        for attempt in range(3):
            try:
                arrays, la, lo, url, last_mod = one_lead(run, n)
                per_lead[n] = arrays
                lats, lons = la, lo
                if n == 39:
                    info = (url, last_mod)
                break
            except Exception as e:
                if attempt == 2:
                    return (target_day.strftime("%Y-%m-%d"), run, "실패 fxx=" + str(n) + " " + str(e)[:80], "", "")
                time.sleep(5)

    keys = sorted(per_lead[39].keys())
    out = {}
    for key in keys:
        hourly = []
        ok = True
        for n in range(16, 40):
            if key not in per_lead[n]:
                ok = False
                break
            if key.endswith("_avg"):
                b = 6 * ((n - 1) // 6)
                if n - 1 > b:
                    if key not in per_lead[n - 1]:
                        ok = False
                        break
                    h = (n - b) * per_lead[n][key] - (n - 1 - b) * per_lead[n - 1][key]
                else:
                    h = per_lead[n][key]
            else:
                h = per_lead[n][key]
            hourly.append(h)
        if ok:
            out[key] = np.stack(hourly).astype("float32")
    np.savez_compressed(path, lats=lats, lons=lons, run=run, **out)
    return (target_day.strftime("%Y-%m-%d"), run, info[0], info[1], "|".join(sorted(out.keys())))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--workers", type=int, default=6)
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    TMP.mkdir(parents=True, exist_ok=True)

    days = pd.date_range(args.start, args.end, freq="D")
    todo = [d for d in days if not (OUT / (d.strftime("%Y%m%d") + ".npz")).exists()]
    print("대상일", len(days), "일 / 남은 날", len(todo), "일")
    log_path = OUT / "download_log.csv"
    new_file = not log_path.exists()
    started = time.time()
    done = 0
    with open(log_path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(["target_day_kst", "gfs_run_utc", "source_url_f039", "last_modified", "variables"])
        with ProcessPoolExecutor(max_workers=args.workers) as ex:
            for res in ex.map(one_day, todo):
                done += 1
                if res is not None:
                    w.writerow(res)
                    f.flush()
                    if "실패" in str(res[2]):
                        print("  !!", res[0], res[2])
                if done % 10 == 0 or done == len(todo):
                    spent = (time.time() - started) / 60
                    print(f"{done}/{len(todo)}일 완료 / {spent:.1f}분 / 남은 예상 {spent / done * (len(todo) - done):.0f}분")

    files = sorted(OUT.glob("*.npz"))
    if files:
        z = np.load(files[-1])
        print("확인:", files[-1].name)
        for k in z.files:
            if k in ["lats", "lons", "run"]:
                continue
            a = z[k]
            print("  ", k, a.shape, "/ 최소", round(float(a.min()), 2), "/ 최대", round(float(a.max()), 2),
                  "/ 13시 평균", round(float(a[12].mean()), 2))


if __name__ == "__main__":
    main()
