"""GFS 추가 변수(구름층·기온·강수·가강수량) -> 시간별 피처 표 (모든 발전소에 같은 값).
위치: codes/gfs2_features.py
실행: python codes/gfs2_features.py        (몇 분)
입력: output/external/gfs2/YYYYMMDD.npz      (gfs_download2.py 결과, 2023-06 ~ 2026-06)
결과: output/external/gfs2_features.parquet  (ts + 피처 34개)

변수 8개: 낮은/중간/높은/전체/경계층 구름 양(%), 기온(도), 강수(mm/h), 가강수량(mm)
  변수마다: 상자(위도 33~39, 경도 124~131.5) 평균, 표준편차      -> 16개
  구름 4개(낮은/중간/높은/전체): 격자 PCA 4개 (2025-06 이전으로만 맞춤) -> 16개
  낮은·전체 구름의 그날 낮 평균                                     -> 2개
규칙 7: 좌표로 격자 고르기 안 함, 모든 발전소 같은 값. 시점은 gfs_download2.py 와 같음 (전날 09시 KST 실행분)
2023-06 이전은 안 받아서 빈 값 (트리가 빈 값으로 처리)
"""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "output" / "external" / "gfs2"
OUT = ROOT / "output" / "external" / "gfs2_features.parquet"
EVAL_START = pd.Timestamp("2025-06-01 01:00")
NAMES = ["lcc", "mcc", "hcc", "tcc", "bcc", "t2m", "prate", "pwat"]
CLOUDS = ["lcc", "mcc", "hcc", "tcc"]
N_PCA = 4


def short_name(key):
    """npz 안의 이름 -> 짧은 이름 (평균형 우선, 없으면 None)"""
    if key.endswith("_avg"):
        if "lcc_lowcloudlayer" in key:
            return "lcc"
        if "mcc_middlecloudlayer" in key:
            return "mcc"
        if "hcc_highcloudlayer" in key:
            return "hcc"
        if key == "tcc_atmosphere_avg":
            return "tcc"
        if "boundarylayer" in key:
            return "bcc"
        if key.startswith("prate"):
            return "prate"
    else:
        if key.startswith("2t_"):
            return "t2m"
        if key.startswith("pwat"):
            return "pwat"
    return None


def main():
    files = sorted(SRC.glob("*.npz"))
    print("파일:", len(files), "일")
    cubes = {}
    for name in NAMES:
        cubes[name] = []
    ts_list = []
    shape = None
    for p in files:
        z = np.load(p)
        day = pd.Timestamp(p.stem)
        found = {}
        for k in z.files:
            s = short_name(k)
            if s is not None:
                found[s] = z[k].astype("float32")
                shape = z[k].shape
        for name in NAMES:
            if name in found:
                cubes[name].append(found[name])
            else:
                cubes[name].append(None)
        for i in range(24):
            ts_list.append(day + pd.Timedelta(hours=i + 1))
    ts = pd.DatetimeIndex(ts_list)

    feats = pd.DataFrame({"ts": ts})
    fit_rows = np.array(ts < EVAL_START)
    for name in NAMES:
        parts = []
        missing = 0
        for c in cubes[name]:
            if c is None:
                parts.append(np.full(shape, np.nan, dtype="float32"))
                missing += 1
            else:
                parts.append(c)
        cube = np.concatenate(parts, axis=0)
        if name in ["lcc", "mcc", "hcc", "tcc", "bcc"]:
            cube = np.clip(cube, 0, 100)
        if name == "t2m":
            cube = cube - 273.15
        if name == "prate":
            cube = np.clip(cube, 0, None) * 3600
        flat = cube.reshape(len(cube), -1)
        feats["g2_" + name + "_mean"] = np.nanmean(flat, axis=1)
        feats["g2_" + name + "_std"] = np.nanstd(flat, axis=1)
        print(name, ": 빠진 날", missing, "/ 13시 평균", round(float(np.nanmean(flat[ts.hour == 13])), 2))
        if name in CLOUDS:
            ok = fit_rows & ~np.isnan(flat).any(axis=1)
            pca = PCA(n_components=N_PCA, random_state=42)
            pca.fit(flat[ok])
            comp = np.full((len(flat), N_PCA), np.nan, dtype="float32")
            good = ~np.isnan(flat).any(axis=1)
            comp[good] = pca.transform(flat[good])
            for k in range(N_PCA):
                feats["g2_" + name + "_pc" + str(k + 1)] = comp[:, k]

    # 그날 낮(09~16시) 평균 구름
    feats["_day"] = (feats["ts"] - pd.Timedelta(hours=1)).dt.normalize()
    day_hours = feats["ts"].dt.hour.between(9, 16)
    for name in ["lcc", "tcc"]:
        col = "g2_" + name + "_mean"
        daymean = feats[day_hours].groupby("_day")[col].mean()
        feats["g2_" + name + "_daymean"] = feats["_day"].map(daymean)
    feats = feats.drop(columns="_day")

    feats.to_parquet(OUT, index=False)
    print("저장:", OUT, len(feats), "행 /", feats.shape[1] - 1, "피처")
    print("기간:", feats["ts"].min(), "~", feats["ts"].max())


if __name__ == "__main__":
    main()
