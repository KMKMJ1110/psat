"""검증 (66번 후보): GFS 트리(63) + GFS 추가 변수 34개 (구름층·기온·강수·가강수량) -> 점수 비교.
위치: codes/gfs2_tree.py
실행: python codes/gfs2_tree.py       (CPU, 1시간 안팎. 다시 실행하면 저장된 트리 예측을 불러옴)
필요: output/external/gfs_features.parquet, output/external/gfs2_features.parquet (gfs2_features.py 결과)
      output/feat_gfs/random/ (63번 트리), output/sleeping_ranking_50/ (명준 MLP),
      output/site_tabpfn/random_gfs/ (65번 GFS TabPFN)
결과: output/feat_gfs2/random/{l1_cap_smpk,cat_l1_cap_smpk}_eval_pred.parquet, result.csv

비교 (시간별 배율, 비율은 group_opt 기준, 빈 칸 채우기·밤 0 은 make_submission 과 같게 = 각 트리 기준)
  - 트리만: 63번 GFS 트리 vs 추가 변수 트리
  - 65번 (63 트리 20 : MLP 10 : GFS TabPFN 70) = 51,387,513
  - 추가 변수 트리 + MLP + GFS TabPFN 비율 다시 찾기
학습·검증 날짜, 손실, 가중치, 하이퍼파라미터는 63번과 같음. 피처만 GFS 추가 변수 34개 더함.
"""
import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs
import mix_all as mx

ROOT = val.DEFAULT_ROOT
opt.log = lambda message: None
GFS_PATH = ROOT / "output" / "external" / "gfs_features.parquet"
GFS2_PATH = ROOT / "output" / "external" / "gfs2_features.parquet"
TAB_GFS = ROOT / "output" / "site_tabpfn" / "random_gfs" / "tabpfn_eval_pred.parquet"
TREE_GFS = ROOT / "output" / "feat_gfs" / "random"
FOLDER = ROOT / "output" / "feat_gfs2" / "random"
WA = 0.75


def load_gfs(like_ts):
    g = pd.read_parquet(GFS_PATH)
    g2 = pd.read_parquet(GFS2_PATH)
    g = g.merge(g2, on="ts", how="left")
    if getattr(like_ts.dt, "tz", None) is not None:
        g["ts"] = g["ts"].dt.tz_localize(like_ts.dt.tz)
    return g


def score(pred, sites, group_actual, hold_actual):
    """시간별 배율 -> 그리디 -> holdout 점수"""
    Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
    Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
    wg = opt.time_weights(ROOT, tg)
    c_hour = {}
    for h in range(24):
        idx = (tg.hour == h)
        if idx.sum() == 0:
            c_hour[h] = 1.0
        else:
            c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])
    cg = np.array([c_hour[h] for h in tg.hour])[:, None]
    ch = np.array([c_hour[h] for h in th.hour])[:, None]
    init_mask = opt.initial_mask(sites)
    optimized, meta, trace = opt.greedy_best_improvement(cg * Pg - Yg, wg, sites, init_mask)
    sg = val.score_group(opt, ROOT, cg * Pg - Yg, tg, init_mask, optimized)
    sh = val.score_group(opt, ROOT, ch * Ph - Yh, th, init_mask, optimized)
    pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
    pred_h["pred_kwh"] = pred_h["pred_kwh"] * pred_h["ts"].dt.hour.map(c_hour)
    m_h = val.model_metrics(ROOT, hold_actual, pred_h)
    return {"weighted_MAE": round(m_h["weighted_MAE_kwh"], 5),
            "group_opt_optimized": round(sg["W_optimized_krw"]),
            "initial": round(sh["W_initial_krw"]),
            "optimized": round(sh["W_optimized_krw"]),
            "lower_bound": round(sh["W_lower_bound_krw"])}


def tree_of(folder):
    pa = pd.read_parquet(folder / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(folder / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    d = both[["site_id", "ts"]].copy()
    d["tree"] = WA * both["pred_kwh_a"] + (1 - WA) * both["pred_kwh_b"]
    return d


def main():
    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_gfs2tree")
    FOLDER.mkdir(parents=True, exist_ok=True)

    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]
    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    model_fit, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    model_fit = pd.concat([gen[gen["ts"] < base.TRAIN_FROM], model_fit], ignore_index=True)
    eval_actual = pd.concat([group_actual, hold_actual], ignore_index=True)
    del gen, baseline_gen

    gfs = load_gfs(model_fit["ts"])
    gfs_cols = [c for c in gfs.columns if c != "ts"]
    n2 = len([c for c in gfs_cols if c.startswith("g2_")])
    print("GFS 피처:", len(gfs_cols), "개 (일사량", len(gfs_cols) - n2, "+ 추가 변수", n2, ") /", len(gfs), "시각")
    hold_ts = hold_actual[["ts"]].drop_duplicates().merge(gfs[["ts", "g2_tcc_mean"]], on="ts", how="left")
    print("holdout 시각 중 추가 변수 빈 값:", int(hold_ts["g2_tcc_mean"].isna().sum()), "/", len(hold_ts))

    # ---------- 1. 트리 학습 (feat_site 와 같은데 GFS 피처만 추가) ----------
    new_feats = []
    for c in fs.A_COLS + fs.B_COLS:
        new_feats = new_feats + [c + "_prev", c + "_next", c + "_daymean"]
    new_feats.append("cloud_diff")
    new_feats = new_feats + fs.NAT_FEATS + fs.F3_FEATS + fs.SITE_FEATS + gfs_cols
    base.FEATS = list(base.FEATS) + new_feats
    print("피처 수:", len(base.FEATS))

    site_table = fs.build_site_table(model_fit, eval_actual, sites, base)
    original_features = base.features

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        n = len(d)
        d = d.merge(site_table, on=["site_id", "ts"], how="left")
        d = d.merge(gfs, on="ts", how="left")
        if len(d) != n:
            raise ValueError("피처 붙이다가 행 수가 바뀜")
        d["site_num"] = d["site_id"].str[2:].astype(int)
        return d

    base.features = features_plus
    fs.get_predictions(fs.MODEL_A, base, sites, model_fit, eval_actual, FOLDER)
    fs.get_predictions(fs.MODEL_B, base, sites, model_fit, eval_actual, FOLDER)
    del model_fit

    # ---------- 2. 섞기 비교 ----------
    t63 = tree_of(TREE_GFS).rename(columns={"tree": "tree63"})
    t66 = tree_of(FOLDER).rename(columns={"tree": "tree66"})
    d = t63.merge(t66, on=["site_id", "ts"])
    tab = pd.read_parquet(TAB_GFS).rename(columns={"pred_kwh": "tab"})
    tab["ts"] = val.to_kst(tab["ts"])
    d = d.merge(tab, on=["site_id", "ts"], how="left")
    d = d.merge(mx.load_mlp(), on=["site_id", "ts"], how="left")

    def frame(tcol):
        """make_submission 과 같은 방식: 빈 칸은 그 트리로, 밤은 그 트리 기준 0"""
        f = d[["site_id", "ts"]].copy()
        f["tree"] = d[tcol]
        f["mlp"] = d["mlp_kwh"].fillna(d[tcol])
        f["tab"] = d["tab"].fillna(d[tcol])
        night = f["tree"] <= 0
        f.loc[night, ["mlp", "tab"]] = 0.0
        return f

    f63 = frame("tree63")
    f66 = frame("tree66")
    cands = [("63번 GFS 트리만", f63, 1.0, 0.0, 0.0),
             ("추가 변수 트리만", f66, 1.0, 0.0, 0.0),
             ("65번 (63 트리 20 : MLP 10 : TabPFN 70)", f63, 0.2, 0.1, 0.7)]
    for w_tab in [0.4, 0.5, 0.6, 0.7, 0.8]:
        for w_mlp in [0.0, 0.1, 0.2]:
            w_tree = round(1 - w_tab - w_mlp, 2)
            if w_tree < 0.1:
                continue
            label = ("추가 변수 트리 " + str(int(round(w_tree * 100))) + " : MLP " + str(int(round(w_mlp * 100)))
                     + " : TabPFN " + str(int(round(w_tab * 100))))
            cands.append((label, f66, w_tree, w_mlp, w_tab))

    rows = []
    for label, f, w_tree, w_mlp, w_tab in cands:
        pred = f[["site_id", "ts"]].copy()
        pred["pred_kwh"] = w_tree * f["tree"] + w_mlp * f["mlp"] + w_tab * f["tab"]
        r = {"blend": label, **score(pred, sites, group_actual, hold_actual)}
        rows.append(r)
        print(label, "| 최적", f"{r['optimized']:,}", "| group_opt", f"{r['group_opt_optimized']:,}")

    table = pd.DataFrame(rows)
    table.to_csv(FOLDER / "result.csv", index=False)
    mix_rows = table[table["blend"].str.startswith("추가 변수 트리 ")]
    best = mix_rows.loc[mix_rows["group_opt_optimized"].idxmin()]
    print("=" * 70)
    print("비교 기준 65번 holdout 51,387,513")
    print(table.to_string(index=False))
    print("-" * 70)
    print("group_opt 기준 최선:", best["blend"], "-> holdout 최적", f"{best['optimized']:,}")


if __name__ == "__main__":
    main()
