"""시간 순 검증.
팀장님 baseline_validation.py / baseline_optimizer.py 함수를 그대로 불러 씀 (원본 수정 X).
위치: data/codes/validation_timesplit.py (baseline_validation.py, baseline_optimizer.py와 같은 폴더)

--split year   : 2024-06 이전 전체로 학습, 마지막 1년(2024-06 ~ 2025-05)으로 검증 (기본값)
                 그룹 최적화 = 검증 1년 중 짝수 주 / 그룹 평가 = 홀수 주
--split blocks : 마지막 1년에서 계절별 4주 블록 4개(2024-07, 2024-10, 2025-01, 2025-04)만 검증,
                 블록 앞뒤 1주는 비우고 나머지 전부 학습
                 그룹 최적화 = 각 블록 1·3주 / 그룹 평가 = 2·4주

variant
  baseline, round17_only, l1_loss : 팀장님 fit_models 그대로
  l2_smpk          : LightGBM, L2 + 가중치(SMP x k)
  l1_smpk          : LightGBM, L1 + 가중치(SMP x k)
  l1_cap_smpk      : LightGBM, L1 + 가중치(용량 x SMP x k)
  l1_cap           : LightGBM, L1 + 가중치(용량)
  cat_l1_cap_smpk  : CatBoost, L1 + 가중치(용량 x SMP x k)   (pip install catboost)
  xgb_l1_cap_smpk  : XGBoost,  L1 + 가중치(용량 x SMP x k)   (pip install xgboost)

가중치는 평균 1로 정규화해서 sample_weight로 넣음.

실행 예:
  python3 codes/validation_timesplit.py --variant baseline
  python3 codes/validation_timesplit.py --variant l1_cap_smpk --split blocks
결과: output/validation_timesplit/<variant>[_blocks]/summary.json
"""
import argparse
import json
import time

import lightgbm as lgb
import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt

ROOT = val.DEFAULT_ROOT
CUT = pd.Timestamp("2024-06-01 01:00", tz="Asia/Seoul")   # year 방식: 이 시각부터 검증

# blocks 방식 설정
BLOCK_STARTS = ["2024-07-01", "2024-10-01", "2025-01-01", "2025-04-01"]
BLOCK_DAYS = 28
BUFFER_DAYS = 7

BASIC_VARIANTS = ["baseline", "round17_only", "l1_loss"]
WEIGHT_VARIANTS = {
    # 이름: (모델, 손실, 가중치 종류)
    "l2_smpk": ("lgbm", "l2", "smpk"),
    "l1_smpk": ("lgbm", "l1", "smpk"),
    "l1_cap_smpk": ("lgbm", "l1", "cap_smpk"),
    "l1_cap": ("lgbm", "l1", "cap"),
    "cat_l1_cap_smpk": ("catboost", "l1", "cap_smpk"),
    "xgb_l1_cap_smpk": ("xgboost", "l1", "cap_smpk"),
}


# =========================================
# 나누는 방법 2가지
# =========================================
def split_year(gen):
    fit = gen[gen["ts"] < CUT].copy()
    valid = gen[gen["ts"] >= CUT].copy()

    valid_day = val.days_of(valid["ts"])
    week_no = (valid_day - valid_day.min()).dt.days // 7
    group_actual = valid[week_no % 2 == 0].copy()
    hold_actual = valid[week_no % 2 == 1].copy()
    return fit, valid, group_actual, hold_actual


def split_blocks(gen):
    day = val.days_of(gen["ts"])
    in_valid = pd.Series(False, index=gen.index)
    in_buffer = pd.Series(False, index=gen.index)
    week_in_block = pd.Series(-1, index=gen.index)

    for s in BLOCK_STARTS:
        start = pd.Timestamp(s, tz="Asia/Seoul")
        end = start + pd.Timedelta(days=BLOCK_DAYS)
        buf = pd.Timedelta(days=BUFFER_DAYS)

        inside = (day >= start) & (day < end)
        in_valid = in_valid | inside
        week_in_block.loc[inside] = (day[inside] - start).dt.days // 7

        before = (day >= start - buf) & (day < start)
        after = (day >= end) & (day < end + buf)
        in_buffer = in_buffer | before | after

    fit = gen[~in_valid & ~in_buffer].copy()
    valid = gen[in_valid].copy()
    group_actual = gen[in_valid & (week_in_block % 2 == 0)].copy()
    hold_actual = gen[in_valid & (week_in_block % 2 == 1)].copy()
    print("버퍼로 비운 행:", int(in_buffer.sum()))
    return fit, valid, group_actual, hold_actual


# =========================================
# 가중치 학습
# =========================================
def make_weight(df, smp_series, weight_type):
    """학습 행마다 가중치 계산. 평균이 1이 되게 맞춤."""
    smp = df["ts"].map(smp_series).fillna(0).to_numpy(np.float64)
    hour = df["ts"].dt.hour.to_numpy()
    k = np.where((hour >= 11) & (hour <= 15), 3.0, 1.0)
    cap = df["cap"].to_numpy(np.float64)

    if weight_type == "smpk":
        w = smp * k
    elif weight_type == "cap_smpk":
        w = cap * smp * k
    elif weight_type == "cap":
        w = cap.copy()
    else:
        raise ValueError("모르는 가중치: " + weight_type)

    w = w / w.mean()
    return w


def fit_models_weighted(base, sites, fit, fa, fb, variant):
    model_type, loss, weight_type = WEIGHT_VARIANTS[variant]
    rounds = (10, 17)

    if model_type == "lgbm":
        params = dict(val.BASELINE_PARAMS)
        if loss == "l1":
            params["objective"] = "regression_l1"
    elif model_type == "catboost":
        from catboost import CatBoostRegressor
        params = dict(
            loss_function="MAE" if loss == "l1" else "RMSE",
            iterations=600, learning_rate=0.06, depth=8,
            random_seed=42, verbose=100, thread_count=-1,
        )
    else:
        from xgboost import XGBRegressor
        params = dict(
            objective="reg:absoluteerror" if loss == "l1" else "reg:squarederror",
            n_estimators=600, learning_rate=0.06, max_depth=0, max_leaves=127,
            grow_policy="lossguide", tree_method="hist",
            min_child_weight=1, subsample=0.8, colsample_bytree=0.8,
            random_state=42, n_jobs=-1,
        )

    smp = pd.read_csv(ROOT / "train" / "smp.csv", usecols=["ts", "smp"])
    smp["ts"] = val.to_kst(smp["ts"])
    smp_series = smp.set_index("ts")["smp"]

    models = {}
    for r in rounds:
        df = base.features(fit, sites, fa, fb, None, r)
        df = df.loc[df.elev > 0]
        X = df[base.FEATS].astype("float32")
        y = (df.energy / df.cap).clip(0, 1.2).astype("float32")
        w = make_weight(df, smp_series, weight_type)
        print("round", r, "학습:", X.shape, "/ 모델:", model_type,
              "/ 손실:", loss, "/ 가중치:", weight_type)

        if model_type == "lgbm":
            model = lgb.LGBMRegressor(**params)
        elif model_type == "catboost":
            model = CatBoostRegressor(**params)
        else:
            model = XGBRegressor(**params)
        model.fit(X, y, sample_weight=w)
        models[r] = model
        del df, X, y, w
    return models, rounds, params


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", default="baseline",
                    choices=BASIC_VARIANTS + list(WEIGHT_VARIANTS.keys()))
    ap.add_argument("--split", default="year", choices=["year", "blocks"])
    args = ap.parse_args()
    variant = args.variant
    started = time.monotonic()

    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_time")
    folder = variant if args.split == "year" else variant + "_blocks"
    out = ROOT / "output" / "validation_timesplit" / folder
    out.mkdir(parents=True, exist_ok=True)
    print("실험:", variant, "/ 나누기:", args.split, "/ 저장 위치:", out)

    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]

    # =========================================
    # 1. 학습 / 검증 나누기
    # =========================================
    gen = pd.read_parquet(ROOT / "train" / "generation.parquet",
                          columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])

    if args.split == "year":
        fit, valid, group_actual, hold_actual = split_year(gen)
    else:
        fit, valid, group_actual, hold_actual = split_blocks(gen)
    del gen
    print("학습 행:", len(fit), " 검증 행:", len(valid))
    print("그룹 최적화 행:", len(group_actual), " 그룹 평가 행:", len(hold_actual))

    # =========================================
    # 2. 학습
    # =========================================
    fa, fb = val.load_weather(ROOT, base, fit["ts"].min())
    if variant in WEIGHT_VARIANTS:
        models, rounds, params = fit_models_weighted(base, sites, fit, fa, fb, variant)
    else:
        models, rounds, params = val.fit_models(base, sites, fit, fa, fb, variant)
    del fit

    # =========================================
    # 3. 검증 예측
    # =========================================
    pred = val.predict_eval(base, models, rounds, sites, valid, fa, fb)
    del models, fa, fb
    pred.to_parquet(out / "valid_site_predictions.parquet", index=False)

    init_mask = opt.initial_mask(sites)

    # =========================================
    # 4. 핵심 숫자: 검증 전체 (current_group 기준)
    # =========================================
    m_all = val.model_metrics(ROOT, valid, pred)
    mat_all, times_all, miss_all = val.residual_matrix(valid, pred, sites.site_id, "VALID_ALL")
    score_all = val.score_group(opt, ROOT, mat_all, times_all, init_mask, init_mask)

    # =========================================
    # 5. 그룹 최적화 -> 평가
    # =========================================
    pred_g = pred.merge(group_actual[["site_id", "ts"]], on=["site_id", "ts"])
    pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
    mat_g, times_g, _ = val.residual_matrix(group_actual, pred_g, sites.site_id, "GROUP_OPT")
    mat_h, times_h, _ = val.residual_matrix(hold_actual, pred_h, sites.site_id, "HOLDOUT")

    w_g = opt.time_weights(ROOT, times_g)
    optimized, meta, trace = opt.greedy_best_improvement(mat_g, w_g, sites, init_mask)
    score_g = val.score_group(opt, ROOT, mat_g, times_g, init_mask, optimized)
    score_h = val.score_group(opt, ROOT, mat_h, times_h, init_mask, optimized)

    # =========================================
    # 6. 저장 + 출력
    # =========================================
    pd.DataFrame({"site_id": sites.site_id,
                  "group": np.where(optimized, "G1", "G2")}).to_csv(out / "composition.csv", index=False)
    trace.to_csv(out / "greedy_trace.csv", index=False)
    summary = {
        "experiment": variant,
        "split": args.split,
        "model_params": params,
        "rounds": list(rounds),
        "model_metrics_valid": m_all,
        "valid_all": score_all,
        "group_opt": score_g,
        "group_eval": score_h,
        "valid_missing_site_hours": miss_all,
        "elapsed_seconds": time.monotonic() - started,
    }
    with (out / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, allow_nan=False)

    print("=" * 60)
    print("실험", variant, "| 나누기:", args.split)
    print("검증 가중 MAE        =", round(m_all["weighted_MAE_kwh"], 5))
    print("검증 초기 벌금       =", f"{score_all['W_initial_krw']:,.0f}")
    print("검증 하한            =", f"{score_all['W_lower_bound_krw']:,.0f}")
    print("그룹 최적화 초기     =", f"{score_g['W_initial_krw']:,.0f}")
    print("그룹 최적화 최적     =", f"{score_g['W_optimized_krw']:,.0f}")
    print("그룹 평가 초기       =", f"{score_h['W_initial_krw']:,.0f}")
    print("그룹 평가 최적       =", f"{score_h['W_optimized_krw']:,.0f}")
    print("그룹 평가 하한       =", f"{score_h['W_lower_bound_krw']:,.0f}")
    print("걸린 시간(초)        =", round(time.monotonic() - started))


if __name__ == "__main__":
    main()
