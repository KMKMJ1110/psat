"""제출용 1/3: No.53 트리 (feat_site 피처, LGBM 75 : CatBoost 25) 를 학습 기간 전체로 다시 학습 -> 평가 기간 예측.
위치: codes/test_tree.py
실행: python codes/test_tree.py           (CPU, 1시간 안팎) -> test_tree.parquet
      python codes/test_tree.py --gfs     GFS 피처 63개 추가 (gfs_tree.py 와 같음) -> test_tree_gfs.parquet
      python codes/test_tree.py --gfs --gfs2   + GFS 추가 변수 34개 (gfs2_tree.py 와 같음) -> test_tree_gfs2.parquet
      python codes/test_tree.py --gfs --gfs2 --ecmwf   + ECMWF (ecmwf_tree.py 와 같음) -> test_tree_ec.parquet
      python codes/test_tree.py --gfs --gfs2 --gefs    + GEFS (gefs_tree.py 와 같음) -> test_tree_gefs.parquet
      python codes/test_tree.py --gfs --gfs2 --asos    + ASOS 전날 관측 (asos_tree.py 와 같음) -> test_tree_asos.parquet
결과: output/submit_final/test_tree.parquet 또는 test_tree_gfs.parquet  (site_id, ts, kwh)

검증(No.53)과 다른 점: 학습 데이터만 '전체'로 바뀜. 피처·손실·가중치·하이퍼파라미터 동일.
발전소 평균 이용률 피처: 학습 행은 날짜 5등분 교차, 평가 기간 행은 학습 전체 평균 (검증과 같은 방식)
"""
import argparse

import numpy as np
import pandas as pd

import baseline_validation as val
import validation_timesplit as vt
import feat_site as fs
import submit_common as sc

WA = 0.75


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gfs", action="store_true", help="GFS 피처 추가")
    ap.add_argument("--gfs2", action="store_true", help="GFS 추가 변수도 추가 (--gfs 와 같이)")
    ap.add_argument("--ecmwf", action="store_true", help="ECMWF 도 추가 (--gfs --gfs2 와 같이)")
    ap.add_argument("--gefs", action="store_true", help="GEFS 도 추가 (--gfs --gfs2 와 같이)")
    ap.add_argument("--asos", action="store_true", help="ASOS 전날 관측도 추가 (--gfs --gfs2 와 같이)")
    args = ap.parse_args()
    sc.OUT.mkdir(parents=True, exist_ok=True)
    base = val.load_module(sc.ROOT / "baseline.py", "oibc_baseline_testtree")

    sites = sc.load_sites()
    gen = sc.load_gen_all()
    grid = sc.test_grid(sites)

    gfs = None
    gfs_cols = []
    if args.gfs:
        gfs = pd.read_parquet(sc.ROOT / "output" / "external" / "gfs_features.parquet")
        if args.gfs2:
            g2 = pd.read_parquet(sc.ROOT / "output" / "external" / "gfs2_features.parquet")
            gfs = gfs.merge(g2, on="ts", how="left")
        if args.ecmwf:
            ec = pd.read_parquet(sc.ROOT / "output" / "external" / "ecmwf_features.parquet")
            gfs = gfs.merge(ec, on="ts", how="left")
        if args.gefs:
            ge = pd.read_parquet(sc.ROOT / "output" / "external" / "gefs_features.parquet")
            gfs = gfs.merge(ge, on="ts", how="left")
        if args.asos:
            ao = pd.read_parquet(sc.ROOT / "output" / "external" / "asos_features.parquet")
            gfs = gfs.merge(ao, on="ts", how="left")
        if getattr(gen["ts"].dt, "tz", None) is not None:
            gfs["ts"] = gfs["ts"].dt.tz_localize(gen["ts"].dt.tz)
        gfs_cols = [c for c in gfs.columns if c != "ts"]
        missing = grid[["ts"]].drop_duplicates().merge(gfs[["ts", "gfs_mean"]], on="ts", how="left")
        print("GFS 피처", len(gfs_cols), "개 / 평가 기간 GFS 빈 시각:", int(missing["gfs_mean"].isna().sum()), "(0이어야 함)")
        if args.gefs:
            miss = grid[["ts"]].drop_duplicates().merge(gfs[["ts", "gefs_mean"]], on="ts", how="left")
            print("평가 기간 GEFS 빈 시각:", int(miss["gefs_mean"].isna().sum()))
        if args.asos:
            miss = grid[["ts"]].drop_duplicates().merge(gfs[["ts", "asos_solar_dm1"]], on="ts", how="left")
            print("평가 기간 ASOS 빈 시각:", int(miss["asos_solar_dm1"].isna().sum()), "(0이어야 함)")
    base.FEATS = list(base.FEATS) + sc.weather_feats() + fs.SITE_FEATS + gfs_cols
    print("피처 수:", len(base.FEATS))
    print("학습 행:", len(gen), "/ 평가 기간 행:", len(grid))

    site_table = fs.build_site_table(gen, grid, sites, base)
    original_features = base.features

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        n = len(d)
        d = d.merge(site_table, on=["site_id", "ts"], how="left")
        if gfs is not None:
            d = d.merge(gfs, on="ts", how="left")
        if len(d) != n:
            raise ValueError("발전소 평균 붙이다가 행 수가 바뀜")
        d["site_num"] = d["site_id"].str[2:].astype(int)
        return d

    base.features = features_plus

    # 학습
    fa, fb = sc.load_weather_train(base, gen["ts"].min())
    fa, fb = sc.weather_pipeline(fa, fb)
    models_a, rounds, _ = vt.fit_models_weighted(base, sites, gen, fa, fb, "l1_cap_smpk")
    models_b, _, _ = vt.fit_models_weighted(base, sites, gen, fa, fb, "cat_l1_cap_smpk")
    del fa, fb, gen

    # 평가 기간 예측
    fa_te, fb_te = sc.load_weather_test(base)
    fa_te, fb_te = sc.weather_pipeline(fa_te, fb_te)
    out = None
    for r in rounds:
        d = base.features(grid, sites, fa_te, fb_te, None, r)
        if len(d) != len(grid):
            raise ValueError("평가 기간 행 수가 바뀜")
        X = d[base.FEATS].astype("float32")
        cf = WA * models_a[r].predict(X) + (1 - WA) * models_b[r].predict(X)
        cf = np.where(d["elev"].to_numpy() > 0, cf, 0.0)
        cf = np.clip(cf, 0.0, 1.2)
        one = d[["site_id", "ts"]].copy()
        one["kwh_" + str(r)] = cf * d["cap"].to_numpy()
        if out is None:
            out = one
        else:
            out = out.merge(one, on=["site_id", "ts"])
        print("round", r, "예측 완료")

    out["kwh"] = (out["kwh_10"] + out["kwh_17"]) / 2
    out = out[["site_id", "ts", "kwh"]]
    if args.asos:
        name = "test_tree_asos.parquet"
    elif args.gefs:
        name = "test_tree_gefs.parquet"
    elif args.ecmwf:
        name = "test_tree_ec.parquet"
    elif args.gfs2:
        name = "test_tree_gfs2.parquet"
    elif args.gfs:
        name = "test_tree_gfs.parquet"
    else:
        name = "test_tree.parquet"
    out.to_parquet(sc.OUT / name, index=False)
    print("저장:", sc.OUT / name, len(out), "행 / 빈 값", int(out["kwh"].isna().sum()))


if __name__ == "__main__":
    main()
