"""제출용 3/3: 발전소별 TabPFN-2 -> 평가 기간 예측.
위치: codes/test_tabpfn.py
실행: python codes/test_tabpfn.py          (GPU, 10시간 이상. 꺼져도 다시 실행하면 끝난 발전소는 건너뜀) -> test_tabpfn.parquet
      python codes/test_tabpfn.py --gfs    GFS 15개 추가 (gfs_tabpfn.py, 65번과 같음) -> test_tabpfn_gfs.parquet
결과: output/submit_final/test_tabpfn.parquet 또는 test_tabpfn_gfs.parquet  (site_id, ts, kwh)

검증(site_tabpfn.py 큰 설정 random_big, No.60)과 같은 설정: 17시판 예보, 피처 64개, 발전소별 학습 최대 10,000행, n_estimators 8, 중앙값
다른 점: 학습 = 그 발전소의 학습 기간 '전체' 낮 시간 행에서 뽑음
TabPFN-2 고정 (Apache 2.0 + 출처 표기, "Built with PriorLabs-TabPFN"). 2.5 이상은 비상업이라 안 씀.
"""
import os
os.environ["TABPFN_DISABLE_TELEMETRY"] = "1"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL"] = "1"
os.environ["TABPFN_ALLOW_CPU_LARGE_DATASET"] = "1"

import argparse
import time
import numpy as np
import pandas as pd
import torch

import baseline_validation as val
import submit_common as sc

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_CTX = 10000
N_EST = 8
ROUND = 17
SITE_DIR = sc.OUT / "tabpfn_sites_big"
GFS_USE = ["gfs_mean", "gfs_std", "gfs_max"] + ["gfs_pc" + str(k) for k in range(1, 9)] + \
          ["gfs_mean_prev", "gfs_mean_next", "gfs_mean_daysum", "gfs_mean_daymax"]


def fit_predict_site(X_tr, y_tr, X_te):
    from tabpfn import TabPFNRegressor
    from tabpfn.constants import ModelVersion
    model = TabPFNRegressor.create_default_for_version(ModelVersion.V2, device=DEVICE,
                                                       random_state=42, n_estimators=N_EST)
    model.fit(X_tr, y_tr)
    preds = []
    for start in range(0, len(X_te), 500):
        preds.append(model.predict(X_te[start:start + 500], output_type="median"))
    return np.concatenate(preds)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gfs", action="store_true", help="GFS 15개 추가")
    args = ap.parse_args()
    if args.gfs:
        site_dir = sc.OUT / "tabpfn_sites_gfs"
        out_name = "test_tabpfn_gfs.parquet"
    else:
        site_dir = SITE_DIR
        out_name = "test_tabpfn.parquet"
    site_dir.mkdir(parents=True, exist_ok=True)
    print("장치:", DEVICE)
    base = val.load_module(sc.ROOT / "baseline.py", "oibc_baseline_testtabpfn")

    sites = sc.load_sites()
    gen = sc.load_gen_all()
    grid = sc.test_grid(sites)

    gfs = None
    feats = []
    for c in list(base.FEATS) + sc.weather_feats():
        if c not in ["lat", "lon", "cap"]:
            feats.append(c)
    if args.gfs:
        gfs = pd.read_parquet(sc.ROOT / "output" / "external" / "gfs_features.parquet", columns=["ts"] + GFS_USE)
        if getattr(gen["ts"].dt, "tz", None) is not None:
            gfs["ts"] = gfs["ts"].dt.tz_localize(gen["ts"].dt.tz)
        feats = feats + GFS_USE
    print("TabPFN 피처 수:", len(feats))
    original_features = base.features

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        if gfs is not None:
            n = len(d)
            d = d.merge(gfs, on="ts", how="left")
            if len(d) != n:
                raise ValueError("GFS 붙이다가 행 수가 바뀜")
        return d

    base.features = features_plus

    print("피처 만드는 중 ...")
    fa, fb = sc.load_weather_train(base, gen["ts"].min())
    fa, fb = sc.weather_pipeline(fa, fb)
    tr = base.features(gen, sites, fa, fb, None, ROUND)
    tr = tr[tr["elev"] > 0]
    tr = tr[["site_id", "energy", "cap"] + feats].copy()
    tr["y"] = (tr["energy"] / tr["cap"]).clip(0, 1.2)
    del fa, fb, gen

    fa_te, fb_te = sc.load_weather_test(base)
    fa_te, fb_te = sc.weather_pipeline(fa_te, fb_te)
    ev = base.features(grid, sites, fa_te, fb_te, None, ROUND)
    if len(ev) != len(grid):
        raise ValueError("평가 기간 행 수가 바뀜")
    ev_day = ev[ev["elev"] > 0][["site_id", "ts", "cap"] + feats].copy()
    print("학습 낮 행:", len(tr), "/ 평가 기간 낮 행:", len(ev_day))
    if args.gfs:
        print("평가 기간 낮 행 중 GFS 빈 값:", int(ev_day["gfs_mean"].isna().sum()), "(0이어야 함)")

    tr_groups = dict(list(tr.groupby("site_id")))
    ev_groups = dict(list(ev_day.groupby("site_id")))
    rng = np.random.default_rng(42)
    site_list = list(sites["site_id"])
    started = time.time()
    for i, site in enumerate(site_list):
        path = site_dir / (site + ".parquet")
        t = tr_groups.get(site)
        if len(t) > MAX_CTX:                       # 건너뛰어도 난수 순서가 같도록 항상 뽑음
            pick = np.sort(rng.choice(len(t), MAX_CTX, replace=False))
            t = t.iloc[pick]
        if path.exists():
            continue
        e = ev_groups[site]
        cf = fit_predict_site(t[feats].to_numpy(np.float32), t["y"].to_numpy(np.float32),
                              e[feats].to_numpy(np.float32))
        out = e[["site_id", "ts"]].copy()
        out["kwh"] = np.clip(cf, 0, 1.2) * e["cap"].to_numpy()
        out.to_parquet(path, index=False)
        print(f"[{i + 1}/{len(site_list)}] {site} 학습 {len(t):,}행 / 예측 {len(e):,}행 / 누적 {(time.time() - started) / 60:.1f}분")

    parts = []
    for site in site_list:
        parts.append(pd.read_parquet(site_dir / (site + ".parquet")))
    allp = ev[["site_id", "ts"]].merge(pd.concat(parts, ignore_index=True), on=["site_id", "ts"], how="left")
    allp["kwh"] = allp["kwh"].fillna(0.0)          # 밤 = 0
    allp.to_parquet(sc.OUT / out_name, index=False)
    print("저장:", sc.OUT / out_name, len(allp), "행")


if __name__ == "__main__":
    main()
