# CAMS 황사 예보 피처와 파일 안내

CAMS ADS의 550 nm 황사 광학두께(AOD) 예보에서 **시간별 피처 6개**를 만들고, 팀의 기존 GFS 피처 15개에 `ts`로 결합합니다. AOD는 대기 중 황사 입자가 빛을 얼마나 감쇠시키는지 나타내는 무차원 값입니다. 목표는 황사 정보와 그 시간 변화가 발전량 예측의 정산 오차를 줄이는지 검증하는 것입니다.

## 1. 공유할 파일과 저장 위치

**팀원에게 전달할 것은 코드 ZIP, 최종 피처 Parquet, 출처 JSON입니다.** Parquet과 JSON은 전체 다운로드와 피처 생성이 끝난 뒤 `output/external/`에서 가져옵니다.

| 파일 | 담긴 내용과 용도 |
|---|---|
| `cams_dataset_kit.zip` | 이 README, 지연 회차 목록 `cams_delay_exclusions.json`, CAMS 수집·가공과 모델 실행에 쓰는 Python 파일 4개입니다. |
| `output/external/cams_raw/cams_<시작일>_<종료일>.grib` | ADS에서 받은 고정 영역의 원본 황사 예보 격자입니다. 예보 초기화 월을 기준으로 묶어 저장하며, 파일명 날짜는 한국 시간 기준 발전 대상일 범위입니다. 재가공과 원본 확인에 씁니다. |
| `output/external/cams_features_final.parquet` | **모델 입력용 시간별 표**입니다. 한 시각에 한 행이며 열은 `ts`와 CAMS 피처 6개입니다. `ts`는 시간대 표기가 없는 한국 시간(KST)이며 한 시간 구간의 끝을 나타냅니다. |
| `output/external/cams_features_final.provenance.json` | 데이터 출처와 라이선스, 다운로드 조건, 예보 회차, 원본 파일 목록, 피처명과 시간 결합 규칙을 기록합니다. |

## 2. 코드 파일별 역할

| 코드 | CAMS 작업에서 하는 일 |
|---|---|
| `codes/build_gfs_cams.py` | ADS API로 황사 예보 GRIB를 받습니다. 한국 주변 격자를 시간별 평균·P90으로 요약하고 1시간 전·후 값을 붙여 최종 Parquet과 출처 JSON을 만듭니다. |
| `codes/gfs_tree.py` | `--compare-cams`로 GFS 15개에 CAMS 피처를 결합해 세 가지 입력 조합을 같은 검증 구간에서 비교합니다. 정산 오차가 낮은 조합을 기록합니다. |
| `codes/test_tree.py` | `--cams-selected`로 검증에서 선택된 입력 조합을 불러와 전체 학습 구간으로 트리 모델을 다시 학습하고 평가 기간의 발전소별 예측을 저장합니다. |
| `codes/make_submission.py` | `--tree gfs_cams_selected`로 선택된 조합의 평가 예측을 읽고 발전소 배정과 그룹별 발전량 제출 파일을 만듭니다. |

## 3. 최종 피처 6개

| 열 | 무엇을 나타내는지 | 추가한 이유 |
|---|---|---|
| `cams_dust_mean` | 현재 1시간의 영역 평균 AOD | 황사가 넓게 깔린 시간의 광감쇠 신호를 줍니다. |
| `cams_dust_p90` | 현재 1시간의 공간 90백분위수 | 일부 격자에 강한 황사대가 몰려 영역 평균이 낮게 나타나는 경우를 보완합니다. |
| `cams_dust_mean_prev` | 직전 1시간의 영역 평균 | 현재 평균과 함께 영역 전반의 황사 신호가 강해지는지 약해지는지 구분하는 데 씁니다. |
| `cams_dust_p90_prev` | 직전 1시간의 공간 90백분위수 | 강한 황사대가 직전 시간부터 이어졌는지 보여줍니다. |
| `cams_dust_mean_next` | 직후 1시간의 영역 평균 예보 | 황사 신호가 영역 전체에서 곧 커질지 줄어들지 예보된 흐름을 담습니다. |
| `cams_dust_p90_next` | 직후 1시간의 공간 90백분위수 예보 | 일부 구역에서 강한 황사대가 나타나거나 약해질 것으로 예보된 시간대를 구분하는 데 씁니다. |

원본 변수는 `dust_aerosol_optical_depth_550nm`이고, 위도 33–39°N, 경도 124–131.5°E의 고정 영역을 사용합니다. 각 격자에서 시간 구간 양끝의 예보를 평균한 뒤 영역 평균과 P90을 계산합니다. P90은 그 시간에 영역 격자들의 값을 작은 순서로 정렬했을 때 90% 지점에 해당하는 AOD입니다. 같은 시간에는 모든 발전소에 같은 CAMS 값을 붙입니다.

`13:00 KST` 행의 현재 값은 `12:00~13:00`, 직전 값은 `11:00~12:00`, 직후 값은 `13:00~14:00` 구간입니다. 셋 모두 동일한 운영 예보 회차에 들어 있는 값입니다. 대상일 첫 행인 `01:00`의 직전 값과 마지막 행인 다음 날 `00:00`의 직후 값은 의도적으로 비웁니다. 코드의 시간 커버리지 검사에서도 이 경계는 정상으로 처리합니다.

대상일 D에 대해 `D−2 12:00 UTC` 회차의 `+27~51시간`만 요청합니다. ECMWF 예정 배포 시각은 `D−1 07:00 KST`입니다. 날짜별 실제 공개 시각의 증빙은 운영진이 안내하는 기준을 따릅니다. ADS에는 대회 실측이나 발전소 좌표를 보내지 않습니다. [CAMS 공식 데이터셋](https://ads.atmosphere.copernicus.eu/datasets/cams-global-atmospheric-composition-forecasts?tab=overview) · [ECMWF 배포 문서](https://confluence.ecmwf.int/spaces/CKB/pages/116952716/SFTP-FTP-HTTPS%2Bdata%2Baccess%2Bto%2BCAMS%2Bglobal%2Bdata)

## 4. 실행 순서

### CAMS 수집과 피처 생성

ZIP의 `codes/` 폴더가 보이는 곳에서 PowerShell을 열고 실행합니다. ADS 계정의 `.cdsapirc` 설정과 CAMS 이용 조건 동의가 필요합니다. 이 단계는 팀 GFS나 대회 발전량 데이터 없이 실행할 수 있습니다.

```powershell
python codes/build_gfs_cams.py --download --cams-only --feature-set final --start 2021-01-19 --end 2026-05-31 --out output/external/cams_features_final.parquet
```

중간에 끊겼으면 같은 명령으로 저장된 GRIB 묶음을 재사용할 수 있습니다. 전체 GRIB를 이미 받았다면 `--download`를 `--cams output/external/cams_raw`로 바꿔 가공합니다.

### 배포 지연 회차를 제외한 피처 생성

`cams_delay_exclusions.json`은 UTC 초기화 날짜 기준으로 12 UTC 회차를 지정합니다. 2024-11-12 회차는 지연이 명시됐습니다. 2022-05-11 회차와 2026-05-12~05-29 회차는 ADS 공지에서 날짜별 12 UTC 지연이 확인되지 않아 보수적으로 제외합니다. 발전 대상일은 각각 2024-11-14, 2022-05-13, 2026-05-14~05-31입니다. 각 항목에 근거 URL과 확인 상태가 들어 있습니다.

키트 폴더에서 다음 명령을 실행합니다. `--cams`에는 이미 저장한 GRIB 폴더를 지정합니다. 원본 다운로드가 다른 폴더에 있다면 해당 경로를 넣으세요.

```powershell
python codes/build_gfs_cams.py --cams output/external/cams_raw --cams-only --feature-set final --start 2021-01-19 --end 2026-05-31 --exclude-file cams_delay_exclusions.json --out output/external/cams_features_final_screened.parquet
```

누락이 없는 최종 피처 Parquet을 재사용하려면 `--cams output/external/cams_raw --start 2021-01-19 --end 2026-05-31` 대신 `--cams output/external/cams_features_final.parquet`을 사용합니다. 이전 코드로 만든 파일에는 월별 GRIB 앞부분을 읽는 과정에서 생긴 빈 값이 있을 수 있습니다. 이 경우 위 GRIB 명령으로 다시 생성합니다. `--start`와 `--end`는 GRIB 처리에만 사용합니다.

제외일에는 01:00부터 다음 날 00:00까지 24개 시각의 CAMS 값이 비어 있고 `cams_excluded` 표시가 붙습니다. 이 표시는 모델 입력에 포함하지 않습니다. 전체 기간을 처리하면 제외 대상 20일의 CAMS 480시간이 비고, 해당 회차와 근거는 새 `.provenance.json`에 저장됩니다.

### 팀 프로젝트에서 검증과 제출

ZIP의 `codes/`에 있는 네 파일을 팀 프로젝트의 `codes/`에 복사합니다. 받은 데이터 두 파일은 `output/external/`에 둡니다. 같은 곳에 기존 `gfs_features.parquet`이 필요합니다. 코드 실행 위치는 `baseline.py`가 있는 폴더입니다.

```powershell
python codes/gfs_tree.py --compare-cams output/external/cams_features_final.parquet --w 1 0 0
python codes/test_tree.py --cams-selected
python codes/make_submission.py --name submit_cams_final --tree gfs_cams_selected --w 1 0 0
```

지연 회차를 제외한 경우 위 검증 명령에 `cams_features_final_screened.parquet`을 지정하세요. 검증과 평가에서 제외일의 트리 예측은 GFS 전용 모델의 예측으로 채웁니다. CAMS 조합이 선택됐고 평가 기간에 제외일이 있으면 `--cams-selected`가 GFS 전용 트리도 학습합니다.

## 5. CAMS 검증 결과 읽기

| 출력 파일 | 확인할 내용 |
|---|---|
| `output/feat_gfs_cams/search/<run_id>/result.csv` | `gfs`는 GFS 15개, `basic`은 GFS 15개 + 현재 평균·P90, `final`은 GFS 15개 + CAMS 6개입니다. `group_opt_optimized`가 낮을수록 정산 오차가 작습니다. `final`과 `basic`의 차이로 1시간 전·후 피처를 함께 추가한 효과를 봅니다. |
| `output/feat_gfs_cams/search/<run_id>/holdout.csv` | 기본 GFS 조합과 `group_opt`에서 선택된 조합을 별도 검증 구간에서 확인한 점수입니다. `optimized`와 `weighted_MAE`는 낮을수록 좋습니다. |
| `output/feat_gfs_cams/search/selection.json` | 선택된 조합, 실행 ID, 예측을 섞는 비율을 저장합니다. 후속 평가와 제출 코드가 사용합니다. |
| `output/submit_final/test_tree_gfs_cams_selected.parquet` | 선택된 조합으로 만든 평가 기간의 발전소별 예측입니다. |
| `output/submit_final/submit_cams_final/` | 위 명령으로 생성한 발전소 배정표 `composition.csv`와 그룹별 발전량 `forecast.csv`가 들어갑니다. |

`--w`는 트리 묶음, MLP, TabPFN 순입니다. 팀이 이미 만든 MLP·TabPFN 예측을 섞을 때는 비교와 제출에 같은 비율을 지정합니다. 선택이 달라져 최종 평가 예측을 다시 만들 때는 이전 `test_tree_gfs_cams_selected.parquet` 및 같은 이름의 `.features.sha256`을 다른 곳에 보관한 후 다시 실행하세요.
