# CAMS 황사 예보 최종 피처

CAMS ADS의 550 nm 황사 AOD 예보로 시간별 피처 6개를 만듭니다. 기존 팀 GFS 피처 15개와 같은 시각으로 결합합니다.

## 1. 전체 기간 데이터 만들기

ZIP의 `codes/` 폴더가 보이는 곳에서 PowerShell을 열고 실행합니다. ADS 계정의 `.cdsapirc` 설정과 CAMS 이용 조건 동의는 기존과 같습니다. 이 단계는 팀 GFS나 대회 발전량 데이터 없이 실행할 수 있습니다.

```powershell
python codes/build_gfs_cams.py --download --cams-only --feature-set final --start 2021-01-19 --end 2026-05-31 --out output/external/cams_features_final.parquet
```

원본은 `output/external/cams_raw/`에 월별 GRIB로 저장됩니다. 중간에 끊겼으면 같은 명령을 다시 실행하면 저장된 월을 재사용합니다. 이미 전체 GRIB를 받았다면 `--download` 대신 `--cams output/external/cams_raw`를 쓰면 됩니다. 기본 명령으로 돌리고 있는 이틀치 샘플은 평균·P90 결과를 확인하면 됩니다.

팀원에게 **최신 코드 ZIP, `output/external/cams_features_final.parquet`, `output/external/cams_features_final.provenance.json`**을 전달합니다. 출처 파일에는 공식 주소, 날짜, 변수, 영역, 회차와 시간 결합 규칙이 들어 있습니다.

## 2. 피처 목록

| 열 | 역할 |
|---|---|
| `cams_dust_mean` | 현재 한 시간의 영역 전체 평균. 광범위한 황사의 영향을 표현합니다. |
| `cams_dust_p90` | 현재 한 시간의 공간 90백분위수. 일부 영역의 강한 황사대가 평균에 묻히는 경우를 보완합니다. |
| `cams_dust_mean_prev` | 직전 한 시간의 평균. 현재 평균과 함께 넓은 황사 영향이 강해지는지 약해지는지 판단하는 데 씁니다. |
| `cams_dust_p90_prev` | 직전 한 시간의 P90. 직전부터 강한 황사대가 있었는지 보여줍니다. |
| `cams_dust_mean_next` | 직후 한 시간의 평균 예보. 넓은 영역의 황사가 유입되거나 빠져나갈 것으로 예상되는 시점을 구분하는 데 씁니다. |
| `cams_dust_p90_next` | 직후 한 시간의 P90 예보. 강한 황사대가 나타나거나 약해질 것으로 예상되는 경계 시간을 잡는 데 씁니다. |

위도 33–39°N, 경도 124–131.5°E의 고정 영역을 사용합니다. 시간 구간 양끝의 예보를 격자별로 평균한 다음 전체 평균과 P90을 계산합니다. 같은 시간에는 모든 발전소에 같은 값을 붙입니다.

`13:00 KST` 행의 현재 값은 `12:00~13:00`, 직전 값은 `11:00~12:00`, 직후 값은 `13:00~14:00` 구간입니다. 셋 모두 동일한 운영 예보 회차에 들어 있는 값입니다. 대상일 첫 행인 `01:00`의 직전 값과 마지막 행인 다음 날 `00:00`의 직후 값은 의도적으로 비웁니다. 코드의 시간 커버리지 검사에서도 이 경계는 정상으로 처리합니다.

대상일 D에 대해 `D−2 12:00 UTC` 회차의 `+27~51시간`만 요청합니다. ECMWF 예정 배포 시각은 `D−1 07:00 KST`입니다. 날짜별 실제 공개 시각의 증빙은 운영진이 안내하는 기준을 따릅니다. ADS에는 대회 실측이나 발전소 좌표를 보내지 않습니다. [CAMS 공식 데이터셋](https://ads.atmosphere.copernicus.eu/datasets/cams-global-atmospheric-composition-forecasts?tab=overview) · [ECMWF 배포 문서](https://confluence.ecmwf.int/spaces/CKB/pages/116952716/SFTP-FTP-HTTPS%2Bdata%2Baccess%2Bto%2BCAMS%2Bglobal%2Bdata)

## 3. 팀 프로젝트에서 비교와 제출

ZIP의 `codes/`에 있는 네 파일을 팀 프로젝트의 `codes/`에 복사합니다. 받은 데이터 두 파일은 `output/external/`에 둡니다. 같은 곳에 기존 `gfs_features.parquet`이 필요합니다. 코드 실행 위치는 `baseline.py`가 있는 폴더입니다.

```powershell
python codes/gfs_tree.py --compare-cams output/external/cams_features_final.parquet --w 1 0 0
python codes/test_tree.py --cams-selected
python codes/make_submission.py --name submit_cams_final --tree gfs_cams_selected --w 1 0 0
```

비교는 팀의 GFS 15개, GFS 15개 + 현재 평균·P90, GFS 15개 + 최종 6개를 같은 검증 날짜에서 학습합니다. `group_opt` 정산 오차가 낮은 조합을 선택한 뒤, holdout에서 기본 GFS와 선택된 조합의 점수를 비교합니다. 결과는 `output/feat_gfs_cams/search/`의 `result.csv`와 `holdout.csv`에 저장됩니다.

`--w`는 트리 묶음, MLP, TabPFN 순입니다. 팀이 이미 만든 MLP·TabPFN 예측을 섞을 때는 비교와 제출에 같은 비율을 지정합니다. 선택이 달라져 최종 평가 예측을 다시 만들 때는 이전 `test_tree_gfs_cams_selected.parquet` 및 같은 이름의 `.features.sha256`을 다른 곳에 보관한 후 다시 실행하세요.
