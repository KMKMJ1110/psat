"""제출 파일 만들기: 그룹(검증 group_opt 로 정함) + 평가 기간 예측 섞기 + 시간별 배율.
위치: codes/make_submission.py
실행:
  python codes/make_submission.py --name submit_60 --w 0.2 0.3 0.5    # No.60 트리 20 : MLP 30 : TabPFN(큰 설정) 50
  python codes/make_submission.py --name submit_56 --w 0.6 0.4 0.0    # No.56 트리 60 : MLP 40 (TabPFN 없음, 예비)
  python codes/make_submission.py --name submit_gfs --tree gfs --w 0.5 0.2 0.3   # GFS 트리 (gfs_tree.py + test_tree.py --gfs)
필요:
  검증 예측 (그룹·배율 정하기): output/feat_site/random/, output/sleeping_ranking_50/, output/site_tabpfn/random_big/ (큰 설정 1만 행·n_est 8)
  평가 기간 예측: output/submit_final/test_tree.parquet, test_mlp.parquet, test_tabpfn.parquet (TabPFN 비율 0이면 없어도 됨)
결과: output/submit_final/<name>/composition.csv, forecast.csv

순서 (검증 No.56·58 과 똑같이)
  1. 검증 group_opt 날짜: 세 예측을 같은 비율로 섞음 -> 시각별 배율 c(0~23시) 계산 -> 배율 곱한 오차로 그리디 -> 그룹
     (holdout 점수도 같이 출력 -> 시트 값과 같은지 확인용)
  2. 평가 기간: 세 예측을 같은 비율로 섞음 -> 밤 0 -> 같은 배율 c 곱함 -> 그룹별 합계
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs
import mix_all as mx
import submit_common as sc
from build_gfs_cams import (
    CAMS_FEATURES, CAMS_SELECTED, CAMS_SELECTED_TEST, CAMS_TEST, CAMS_TEST_STAMP,
    CAMS_VALIDATION, CAMS_VALIDATION_STAMP, feature_digest, selected_validation_folder,
)

opt.log = lambda message: None


def validation_folder(tree_kind):
    if tree_kind == "gfs_cams":
        return sc.ROOT / CAMS_VALIDATION
    if tree_kind == "gfs":
        return sc.ROOT / "output" / "feat_gfs" / "random"
    return mx.OURS


def validation_frame(use_tab, tree_kind, use_mlp=True, folder=None):
    folder = folder if folder is not None else validation_folder(tree_kind)
    pa = pd.read_parquet(folder / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(folder / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    d = both[["site_id", "ts"]].copy()
    d["tree"] = mx.WA * both["pred_kwh_a"] + (1 - mx.WA) * both["pred_kwh_b"]
    if use_mlp:
        mlp = mx.load_mlp()
        d = d.merge(mlp, on=["site_id", "ts"], how="left")
        d["mlp"] = d["mlp_kwh"].fillna(d["tree"])
    else:
        d["mlp"] = 0.0
    if use_tab:
        tab = pd.read_parquet(sc.ROOT / "output" / "site_tabpfn" / "random_big" / "tabpfn_eval_pred.parquet")
        tab = tab.rename(columns={"pred_kwh": "tab"})
        tab["ts"] = val.to_kst(tab["ts"])
        d = d.merge(tab, on=["site_id", "ts"], how="left")
        d["tab"] = d["tab"].fillna(d["tree"])
    else:
        d["tab"] = 0.0
    night = d["tree"] <= 0
    d.loc[night, "mlp"] = 0.0
    d.loc[night, "tab"] = 0.0
    return d


def test_frame(use_tab, tree_kind, use_mlp=True):
    names = {"old": "test_tree.parquet", "gfs": "test_tree_gfs.parquet", "gfs_cams": CAMS_TEST,
             CAMS_SELECTED: CAMS_SELECTED_TEST}
    name = names[tree_kind]
    d = pd.read_parquet(sc.OUT / name).rename(columns={"kwh": "tree"})
    if use_mlp:
        m = pd.read_parquet(sc.OUT / "test_mlp.parquet").rename(columns={"kwh": "mlp"})
        d = d.merge(m, on=["site_id", "ts"], how="left")
    else:
        d["mlp"] = 0.0
    if use_tab:
        t = pd.read_parquet(sc.OUT / "test_tabpfn.parquet").rename(columns={"kwh": "tab"})
        d = d.merge(t, on=["site_id", "ts"], how="left")
    else:
        d["tab"] = 0.0
    if d[["tree", "mlp", "tab"]].isna().any().any():
        raise ValueError("평가 기간 예측에 빈 값이 있음")
    night = d["tree"] <= 0
    d.loc[night, "mlp"] = 0.0
    d.loc[night, "tab"] = 0.0
    return d


def valid_weights(weights):
    if not np.isfinite(weights).all() or min(weights) < 0 or abs(sum(weights) - 1) > 1e-9:
        raise ValueError("모델 비율은 각각 0 이상이며 합이 1이어야 함")


def blended_validation(tree_kind, weights, folder=None):
    w_tree, w_mlp, w_tab = weights
    d = validation_frame(w_tab > 0, tree_kind, use_mlp=w_mlp > 0, folder=folder)
    pred = d[["site_id", "ts"]].copy()
    pred["pred_kwh"] = w_tree * d["tree"] + w_mlp * d["mlp"] + w_tab * d["tab"]
    return pred


def check_cams_outputs(tree_kind="gfs_cams", weights=None):
    if tree_kind == CAMS_SELECTED:
        folder = selected_validation_folder(sc.ROOT, weights)
        feature_path = folder / "features.parquet"
        test_stamp = Path(CAMS_SELECTED_TEST).with_suffix(".features.sha256")
    else:
        folder = validation_folder(tree_kind)
        feature_path, test_stamp = CAMS_FEATURES, CAMS_TEST_STAMP
    digest = feature_digest(sc.ROOT, feature_path)
    stamps = [folder / CAMS_VALIDATION_STAMP, sc.OUT / test_stamp]
    for stamp in stamps:
        if not stamp.exists() or stamp.read_text(encoding="utf-8").strip() != digest:
            raise ValueError(f"현재 CAMS 피처 파일에 맞는 검증·평가 예측이 필요함: {stamp}")
    return folder


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="submit_60")
    ap.add_argument("--w", nargs=3, type=float, default=[0.2, 0.3, 0.5], metavar=("TREE", "MLP", "TAB"))
    ap.add_argument("--tree", default="old", choices=["old", "gfs", "gfs_cams", CAMS_SELECTED],
                    help="old / GFS / GFS + CAMS / selected by --compare-cams")
    args = ap.parse_args()
    valid_weights(args.w)
    w_tree, w_mlp, w_tab = args.w
    folder = check_cams_outputs(args.tree, args.w) if args.tree in {"gfs_cams", CAMS_SELECTED} else None
    t = test_frame(w_tab > 0, args.tree, use_mlp=w_mlp > 0)
    out_dir = sc.OUT / args.name
    out_dir.mkdir(parents=True, exist_ok=True)
    print("트리:", args.tree, "/ 비율 트리:MLP:TabPFN =", w_tree, w_mlp, w_tab)

    base = val.load_module(sc.ROOT / "baseline.py", "oibc_baseline_makesub")
    sites = sc.load_sites()
    cap = sites.set_index("site_id")["capacity_kw"]

    # ---------- 1. 검증 날짜로 배율 + 그룹 ----------
    gen = sc.load_gen_all()
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    _, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    del gen, baseline_gen

    pred = blended_validation(args.tree, args.w, folder=folder)
    Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
    Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
    wg = opt.time_weights(sc.ROOT, tg)
    c_hour = {}
    for h in range(24):
        idx = (tg.hour == h)
        if idx.sum() == 0:
            c_hour[h] = 1.0
        else:
            c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])
    cg = np.array([c_hour[h] for h in tg.hour])[:, None]
    ch = np.array([c_hour[h] for h in th.hour])[:, None]
    init_mask = opt.initial_mask(sites)
    optimized, meta, trace = opt.greedy_best_improvement(cg * Pg - Yg, wg, sites, init_mask)
    opt.check_capacity(optimized, sites.capacity_kw.to_numpy(np.float64))
    score_h = val.score_group(opt, sc.ROOT, ch * Ph - Yh, th, init_mask, optimized)
    print("검증 holdout 최적:", f"{round(score_h['W_optimized_krw']):,}", "(시트 값과 같아야 함)")
    pd.Series(c_hour, name="c").rename_axis("hour").to_csv(out_dir / "hour_scale.csv")

    group_of = pd.Series(np.where(optimized, "G1", "G2"), index=sites.site_id)
    comp = pd.DataFrame({"site_id": sites.site_id, "group": group_of.values})
    comp.to_csv(out_dir / "composition.csv", index=False)
    print("그룹: G1", int(optimized.sum()), "개", round(sites.capacity_kw[optimized].sum(), 1), "kW / G2",
          int((~optimized).sum()), "개", round(sites.capacity_kw[~optimized].sum(), 1), "kW")

    # ---------- 2. 평가 기간 예측 ----------
    t["kwh"] = w_tree * t["tree"] + w_mlp * t["mlp"] + w_tab * t["tab"]
    t["kwh"] = t["kwh"] * t["ts"].dt.hour.map(c_hour).to_numpy()
    t["kwh"] = np.clip(t["kwh"].to_numpy(), 0, t["site_id"].map(cap).to_numpy())
    t[["site_id", "ts", "kwh"]].to_parquet(out_dir / "site_predictions.parquet", index=False)

    t["group"] = t["site_id"].map(group_of)
    fc = t.groupby(["group", "ts"], as_index=False)["kwh"].sum()
    fc = fc.rename(columns={"kwh": "forecast_kwh"}).sort_values(["group", "ts"])
    fc.to_csv(out_dir / "forecast.csv", index=False)

    print("=" * 60)
    print("composition.csv :", len(comp) + 1, "행 (헤더 포함, 정답 254)")
    print("forecast.csv    :", len(fc) + 1, "행 (헤더 포함, 정답 17,521)")
    print("음수 / 빈 값    :", int((fc["forecast_kwh"] < 0).sum()), "/", int(fc["forecast_kwh"].isna().sum()), "(정답 0 / 0)")
    print("그룹별 1년 합계 (GWh):", (fc.groupby("group")["forecast_kwh"].sum() / 1e6).round(2).to_dict())
    print("저장 위치:", out_dir)


if __name__ == "__main__":
    main()
