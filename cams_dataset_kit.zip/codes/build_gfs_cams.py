"""Download and prepare hourly CAMS dust forecasts for the team's GFS table."""

import argparse
from calendar import monthrange
from datetime import date, datetime, time, timedelta, timezone
import hashlib
import json
from pathlib import Path
from uuid import uuid4

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent.parent
ADS_API = "https://ads.atmosphere.copernicus.eu/api"
DATASET = "cams-global-atmospheric-composition-forecasts"
SOURCE = f"https://ads.atmosphere.copernicus.eu/datasets/{DATASET}"
VARIABLE = "dust_aerosol_optical_depth_550nm"
GFS_FEATURES = Path("output/external/gfs_features.parquet")
RAW_CAMS = Path("output/external/cams_raw")
HOURLY_CAMS = Path("output/external/cams_features.parquet")
CAMS_FEATURES = Path("output/external/gfs_cams_features.parquet")
CAMS_VALIDATION = Path("output/feat_gfs_cams/random")
CAMS_TEST = "test_tree_gfs_cams.parquet"
CAMS_TEST_STAMP = "test_tree_gfs_cams.features.sha256"
CAMS_VALIDATION_STAMP = "features.sha256"
CAMS_SEARCH = Path("output/feat_gfs_cams/search")
CAMS_RUN_ID_LEN = 16
CAMS_SELECTED = "gfs_cams_selected"
CAMS_SELECTED_TEST = "test_tree_gfs_cams_selected.parquet"
CAMS_COLS = ["cams_dust_mean", "cams_dust_p90"]
CAMS_PREV_COLS = [f"{col}_prev" for col in CAMS_COLS]
CAMS_NEXT_COLS = [f"{col}_next" for col in CAMS_COLS]
CAMS_FINAL_COLS = [*CAMS_COLS, *CAMS_PREV_COLS, *CAMS_NEXT_COLS]
CAMS_CHANGE = "cams_dust_change_1h"
CAMS_EXPANDED_COLS = [
    *CAMS_COLS, "cams_dust_std", "cams_dust_nw_mean", "cams_dust_ne_mean",
    "cams_dust_sw_mean", "cams_dust_se_mean", CAMS_CHANGE,
]
CAMS_TAIL = "cams_dust_p90_minus_p50"
CAMS_WEST_EAST = "cams_dust_west_minus_east"
CAMS_NORTH_SOUTH = "cams_dust_north_minus_south"
CAMS_WEST_CHANGE = "cams_dust_west_change_1h"
CAMS_CANDIDATE_COLS = [*CAMS_EXPANDED_COLS, CAMS_TAIL, CAMS_WEST_EAST, CAMS_NORTH_SOUTH, CAMS_WEST_CHANGE]
CAMS_ALL_COLS = [*CAMS_CANDIDATE_COLS, *CAMS_PREV_COLS, *CAMS_NEXT_COLS]
SIGNED_CAMS = {CAMS_CHANGE, CAMS_WEST_EAST, CAMS_NORTH_SOUTH, CAMS_WEST_CHANGE}
FEATURE_SETS = {"basic": CAMS_COLS, "final": CAMS_FINAL_COLS, "expanded": CAMS_EXPANDED_COLS,
                "candidates": CAMS_CANDIDATE_COLS}
KST = "Asia/Seoul"
PARAM_ID = 210209  # CAMS dust aerosol optical depth at 550 nm
AREA = [39.0, 124.0, 33.0, 131.5]  # north, west, south, east
LEADS = range(27, 52)
ONE_DAY = timedelta(days=1)
GRIB_SUFFIXES = {".grib", ".grib1", ".grib2", ".grb", ".grb2"}


def naive_kst(ts, input_zone=KST):
    """Return the timezone-naive KST representation used by the team's GFS table."""
    parsed = pd.to_datetime(ts, errors="raise")
    if parsed.dt.tz is None:
        parsed = parsed.dt.tz_localize(input_zone)
    return parsed.dt.tz_convert(KST).dt.tz_localize(None)


def checked_hourly(frame, label, input_zone=KST):
    frame = frame.copy()
    frame["ts"] = naive_kst(frame["ts"], input_zone)
    ts = frame["ts"]
    if frame.empty or ts.isna().any() or ts.duplicated().any() or (ts != ts.dt.floor("h")).any():
        raise ValueError(f"{label}: ts must be nonempty, unique and on the hour")
    return frame


def cams_columns(columns, feature_set=None):
    if feature_set is not None:
        return FEATURE_SETS[feature_set]
    return [col for col in CAMS_ALL_COLS if col in columns]


def missing_cams_hours(frame, cols):
    missing = frame[cols].isna()
    # Right-closed KST hours: 01:00 is the first and next midnight is the last.
    for edge_cols, hour in ((CAMS_PREV_COLS, 1), (CAMS_NEXT_COLS, 0)):
        present = missing.columns.intersection(edge_cols)
        missing.loc[frame["ts"].dt.hour.eq(hour), present] = False
    return missing.any(axis=1)


def checked_cams(cams, cams_timezone, feature_set=None):
    cols = cams_columns(cams.columns, feature_set)
    required = CAMS_COLS if feature_set is None else cols
    missing_cols = set(["ts", *required]) - set(cams.columns)
    if missing_cols:
        raise ValueError(f"Missing CAMS columns: {sorted(missing_cols)}")
    cams = checked_hourly(cams[["ts", *cols]], "CAMS", cams_timezone)
    for col in cols:
        cams[col] = pd.to_numeric(cams[col], errors="raise").astype("float32")
        if np.isinf(cams[col]).any() or (col not in SIGNED_CAMS and (cams[col] < 0).any()):
            raise ValueError(f"Invalid AOD values in {col}")
    if missing_cams_hours(cams, cols).all():
        raise ValueError("No hour has all selected CAMS features")
    return cams


def combine(gfs, cams, cams_timezone=KST, feature_set=None):
    gfs = checked_hourly(gfs, "GFS")
    if "gfs_mean" not in gfs or set(CAMS_ALL_COLS) & set(gfs.columns):
        raise ValueError("Use the original gfs_features.parquet as the GFS input")
    cams = checked_cams(cams, cams_timezone, feature_set)
    # A day with missing GFS can still have valid CAMS, and vice versa.
    return gfs.merge(cams, on="ts", how="outer", validate="one_to_one").sort_values("ts").reset_index(drop=True)


def init_for(day):
    return datetime.combine(day - 2 * ONE_DAY, time(12), timezone.utc)


def request_for(first, last):
    return {
        "variable": [VARIABLE],
        "date": [f"{init_for(first).date()}/{init_for(last).date()}"],
        "time": ["12:00"],
        "leadtime_hour": [str(lead) for lead in LEADS],
        "type": ["forecast"],
        "area": AREA,
        "data_format": "grib",
    }


def monthly_batches(first, end):
    while first <= end:
        init_day = init_for(first).date()
        last_init = init_day.replace(day=monthrange(init_day.year, init_day.month)[1])
        last = min(end, last_init + 2 * ONE_DAY)
        yield first, last
        first = last + ONE_DAY


def download_grib(root, batches):
    import cdsapi

    client = cdsapi.Client(url=ADS_API)
    raw_dir = root / RAW_CAMS
    raw_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for first, last in batches:
        target = raw_dir / f"cams_{first:%Y%m%d}_{last:%Y%m%d}.grib"
        if target.exists():
            print(f"Using cached {target.name}", flush=True)
        else:
            print(f"Requesting CAMS for delivery days {first} to {last}", flush=True)
            partial = target.with_suffix(f".{uuid4().hex}.part")
            try:
                client.retrieve(DATASET, request_for(first, last)).download(str(partial))
                with partial.open("rb") as handle:
                    if handle.read(4) != b"GRIB":
                        raise ValueError("ADS response was not an uncompressed GRIB file")
                partial.replace(target)
            finally:
                partial.unlink(missing_ok=True)
        files.append(target)
    return files


def grib_time(eccodes, message, date_key, time_key):
    ymd = eccodes.codes_get_long(message, date_key)
    hm = eccodes.codes_get_long(message, time_key)
    return datetime.strptime(f"{ymd:08d}{hm:04d}", "%Y%m%d%H%M").replace(tzinfo=timezone.utc)


def read_grib_fields(files, start, end):
    import eccodes

    fields = {}
    grids = {}
    north, west, south, east = AREA
    for path in files:
        with path.open("rb") as handle:
            if handle.read(4) != b"GRIB":
                raise ValueError(f"Expected an uncompressed GRIB file: {path}")
            handle.seek(0)
            while (message := eccodes.codes_grib_new_from_file(handle)) is not None:
                try:
                    if eccodes.codes_get_long(message, "paramId") != PARAM_ID:
                        continue
                    init = grib_time(eccodes, message, "dataDate", "dataTime")
                    day = init.date() + 2 * ONE_DAY
                    if init != init_for(day) or not start <= day <= end:
                        continue
                    valid = grib_time(eccodes, message, "validityDate", "validityTime")
                    lead = (valid - init).total_seconds() / 3600
                    if lead not in LEADS:
                        continue
                    lat = eccodes.codes_get_array(message, "latitudes")
                    lon = eccodes.codes_get_array(message, "longitudes")
                    keep = (lat >= south) & (lat <= north) & (lon >= west) & (lon <= east)
                    if not keep.any():
                        raise ValueError(f"No grid cells in the fixed Korea area: {path}")
                    lat, lon = lat[keep], lon[keep]
                    order = np.lexsort((lon, lat))
                    grid = np.column_stack((lat[order], lon[order]))
                    if day in grids and not np.array_equal(grids[day], grid):
                        raise ValueError(f"Grid differs across hours: {day}")
                    grids[day] = grid
                    values = eccodes.codes_get_values(message)[keep][order].astype("float32")
                    missing = eccodes.codes_get_double(message, "missingValue")
                    values[~np.isfinite(values) | (values < 0) | (values == missing)] = np.nan
                    key = (day, int(lead))
                    if key in fields and not np.allclose(fields[key], values, equal_nan=True):
                        raise ValueError(f"Conflicting forecasts for delivery day {day}, lead {lead:g}h")
                    fields[key] = values
                finally:
                    eccodes.codes_release(message)
    return fields, grids


def region_masks(grid):
    north, west, south, east = AREA
    northern = grid[:, 0] >= (north + south) / 2
    western = grid[:, 1] < (west + east) / 2
    return northern & western, northern & ~western, ~northern & western, ~northern & ~western


def masked_mean(values, mask):
    return values[mask].mean() if mask.any() else np.nan


def add_cams_neighbors(hourly):
    hourly = hourly.copy()
    hour = pd.Timedelta(hours=1)
    delivery_day = (hourly["ts"] - hour).dt.normalize()
    lookup = hourly.set_index("ts")
    for delta, cols in ((-hour, CAMS_PREV_COLS), (hour, CAMS_NEXT_COLS)):
        neighbor_ts = hourly["ts"] + delta
        same_day = (neighbor_ts - hour).dt.normalize().eq(delivery_day)
        for source, target in zip(CAMS_COLS, cols):
            hourly[target] = neighbor_ts.map(lookup[source]).where(same_day)
    return hourly


def summarize_grib(fields, start, end, grids=None, feature_set="basic"):
    cols = CAMS_COLS if feature_set == "final" else FEATURE_SETS[feature_set]
    rows = []
    day = start
    while day <= end:
        masks = region_masks(grids[day]) if grids is not None and day in grids else ()
        for lead in range(28, 52):
            ts = pd.Timestamp(init_for(day) + timedelta(hours=lead)).tz_convert(KST).tz_localize(None)
            left, right = fields.get((day, lead - 1)), fields.get((day, lead))
            stats = [np.nan] * len(cols)
            if left is not None and right is not None:
                hourly = (left + right) / 2
                valid = np.isfinite(hourly)
                aod = hourly[valid]
                if aod.size:
                    stats[:2] = [aod.mean(), np.quantile(aod, 0.9)]
                    if masks and feature_set in {"expanded", "candidates"}:
                        change = right - left
                        regional_means = [masked_mean(hourly, mask & valid) for mask in masks]
                        stats[2:8] = [aod.std(), *regional_means, change[valid].mean()]
                        if feature_set == "candidates":
                            nw, ne, sw, se = masks
                            west, east = valid & (nw | sw), valid & (ne | se)
                            north, south = valid & (nw | ne), valid & (sw | se)
                            stats[8:] = [stats[1] - np.median(aod),
                                         masked_mean(hourly, west) - masked_mean(hourly, east),
                                         masked_mean(hourly, north) - masked_mean(hourly, south),
                                         masked_mean(change, west)]
            rows.append((ts, *stats))
        day += ONE_DAY
    hourly = pd.DataFrame(rows, columns=["ts", *cols])
    return add_cams_neighbors(hourly) if feature_set == "final" else hourly


def check_cams_hours(features, ts, label, require_complete=False):
    keys = pd.DataFrame({"ts": naive_kst(ts.drop_duplicates())})
    cols = cams_columns(features.columns)
    if not cols:
        raise ValueError(f"No CAMS features in {label}")
    hourly = features[["ts", *cols]].assign(ts=naive_kst(features["ts"]))
    joined = keys.merge(hourly, on="ts", how="left", validate="one_to_one")
    missing = int(missing_cams_hours(joined, cols).sum())
    print(f"{label}: CAMS {len(joined) - missing:,}/{len(joined):,} hours")
    if joined.empty or missing == len(joined) or (require_complete and missing):
        raise ValueError(f"Insufficient CAMS coverage for {label}: {missing:,} missing hours")


def selected_validation_folder(root, weights=None):
    path = root / CAMS_SEARCH / "selection.json"
    selection = json.loads(path.read_text(encoding="utf-8"))
    winner, run_id = selection["winner"], selection["run_id"]
    if winner not in {"gfs", "basic", "low_corr", "final"} or len(run_id) != CAMS_RUN_ID_LEN or not set(run_id) <= set("0123456789abcdef"):
        raise ValueError(f"Invalid CAMS selection file: {path}")
    if weights is not None and not np.allclose(weights, selection["weights"], rtol=0, atol=1e-9):
        raise ValueError("Use the same --w values as the CAMS feature comparison")
    return root / CAMS_SEARCH / run_id / winner


def feature_digest(root, feature_path=CAMS_FEATURES):
    return hashlib.sha256((root / feature_path).read_bytes()).hexdigest()


def bind_features(root, stamp, outputs, feature_path=CAMS_FEATURES):
    digest = feature_digest(root, feature_path)
    if stamp.exists():
        if stamp.read_text(encoding="utf-8").strip() != digest:
            raise ValueError(f"CAMS feature file changed. Move the earlier experiment outputs first: {stamp.parent}")
    elif any(path.exists() for path in outputs):
        raise ValueError(f"Existing outputs have no CAMS feature stamp: {stamp.parent}")
    else:
        stamp.parent.mkdir(parents=True, exist_ok=True)
        stamp.write_text(digest + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--cams", type=Path, help="Hourly CSV/Parquet or raw GRIB file/folder")
    inputs.add_argument("--download", action="store_true", help="Download archived CAMS forecasts from ADS")
    parser.add_argument("--cams-only", action="store_true", help="Save the standalone CAMS table without GFS")
    parser.add_argument("--feature-set", choices=FEATURE_SETS,
                        help="final = mean/P90 with same-day previous and next hours; GRIB default is basic")
    parser.add_argument("--out", type=Path, help="Custom standalone CAMS Parquet path")
    parser.add_argument("--dry-run", action="store_true", help="Print ADS request details without contacting ADS")
    parser.add_argument("--root", type=Path, default=ROOT, help="Team project directory")
    parser.add_argument("--cams-tz", choices=[KST, "UTC"], default=KST, help="Timezone of naive input table timestamps")
    parser.add_argument("--start", type=date.fromisoformat, help="First delivery day for GRIB, KST")
    parser.add_argument("--end", type=date.fromisoformat, help="Last delivery day for GRIB, KST, inclusive")
    args = parser.parse_args()

    if args.out and (not args.cams_only or args.out.suffix.lower() != ".parquet"):
        parser.error("--out requires --cams-only and a .parquet file path")
    if args.dry_run and not args.download:
        parser.error("--dry-run requires --download")
    if args.start and args.end and args.end < args.start:
        parser.error("--end must be on or after --start")
    if args.download:
        if not (args.start and args.end):
            parser.error("--download requires --start and --end")
        batches = list(monthly_batches(args.start, args.end))
        if args.dry_run:
            print(json.dumps({"dataset": DATASET, "batches": len(batches), "first_request": request_for(*batches[0])}, indent=2))
            return

    gfs = None if args.cams_only else checked_hourly(pd.read_parquet(args.root / GFS_FEATURES), "GFS")
    path = args.cams
    raw_input = args.download or path.is_dir() or path.suffix.lower() in GRIB_SUFFIXES
    if raw_input:
        if args.cams_only and not (args.start and args.end):
            parser.error("Standalone GRIB conversion requires --start and --end")
        delivery_days = None if gfs is None else gfs["ts"] - pd.Timedelta(hours=1)
        start = args.start or delivery_days.min().date()
        end = args.end or delivery_days.max().date()
        if end < start:
            parser.error("--end must be on or after --start")
        if args.download:
            files = download_grib(args.root, batches)
        elif path.is_dir():
            files = sorted(p for p in path.iterdir() if p.is_file() and p.suffix.lower() in GRIB_SUFFIXES)
        else:
            files = [path]
        if not files:
            raise FileNotFoundError(f"No CAMS GRIB files in {path}")
        fields, grids = read_grib_fields(files, start, end)
        feature_set = args.feature_set or "basic"
        cams = summarize_grib(fields, start, end, grids if feature_set in {"expanded", "candidates"} else None,
                              feature_set)
        cams_zone = KST
    else:
        if args.start or args.end:
            parser.error("--start and --end apply to GRIB inputs")
        if path.suffix.lower() == ".csv":
            cams = pd.read_csv(path)
        elif path.suffix.lower() == ".parquet":
            cams = pd.read_parquet(path)
        else:
            parser.error("CAMS input must be an hourly CSV/Parquet table or raw GRIB")
        cams_zone = args.cams_tz
        if args.feature_set == "final":
            cams = add_cams_neighbors(checked_cams(cams, cams_zone, "basic"))
            cams_zone = KST

    if args.cams_only:
        result = checked_cams(cams, cams_zone, args.feature_set).sort_values("ts")
        target = args.out or args.root / HOURLY_CAMS
    else:
        result = combine(gfs, cams, cams_zone, args.feature_set)
        target = args.root / CAMS_FEATURES
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_suffix(f".{uuid4().hex}.tmp")
    try:
        result.to_parquet(partial, index=False)
        partial.replace(target)
    finally:
        partial.unlink(missing_ok=True)
    cols = cams_columns(result.columns)
    count = len(result) - int(missing_cams_hours(result, cols).sum())
    if raw_input:
        provenance = {
            "source": SOURCE,
            "doi": "10.24381/04a0b097",
            "license": "CC BY 4.0",
            "attribution": "Contains modified Copernicus Atmosphere Monitoring Service information",
            "request_parameters": request_for(start, end),
            "cycle": "D-2 12:00 UTC; scheduled dissemination D-2 22:00 UTC",
            "timestamp": "KST, hour ending; mean of the two forecast endpoints at each grid cell",
            "feature_columns": cols,
            "raw_files": [file.name for file in files],
            "complete_cams_hours": count,
        }
        if args.feature_set in {"expanded", "candidates"}:
            north, west, south, east = AREA
            provenance["regional_split_lat_lon"] = [(north + south) / 2, (west + east) / 2]
            provenance[CAMS_CHANGE] = "Mean of the forecast end minus start AOD over valid cells in the hour"
        if args.feature_set == "final":
            provenance["neighbor_policy"] = "Previous and next one-hour summaries from the same delivery-day forecast cycle; day-edge neighbors left null"
        target.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    print(f"Saved {target}: {len(result):,} hours, CAMS complete on {count:,} hours")


if __name__ == "__main__":
    main()
