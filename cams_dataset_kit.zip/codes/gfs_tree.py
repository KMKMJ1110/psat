"""검증: 트리(feat_site, No.53) + GFS 피처 63개 -> 점수 비교.
위치: codes/gfs_tree.py
실행: python codes/gfs_tree.py       (CPU, 1시간 안팎. 다시 실행하면 저장된 트리 예측을 불러옴)
필요: output/external/gfs_features.parquet (gfs_features.py 결과)
      output/feat_site/random/ (기존 트리), output/sleeping_ranking_50/ (명준 MLP),
      output/site_tabpfn/random_big/tabpfn_eval_pred.parquet (TabPFN 큰 설정)
결과: output/feat_gfs/random/{l1_cap_smpk,cat_l1_cap_smpk}_eval_pred.parquet, result.csv

비교 (모두 시간별 배율, 비율은 group_opt_optimized 로 고르기, holdout 은 확인용)
  - 트리만 (LGBM 75 : Cat 25): 기존 vs GFS
  - 트리 20 : MLP 30 : TabPFN 50: 기존 (= No.60 56,886,019) vs GFS 트리
  - GFS 트리로 비율 다시 찾기: TabPFN 0~40, MLP 10~30, 나머지 트리 (트리 30 이상)
학습·검증 날짜, 손실, 가중치, 하이퍼파라미터는 No.53 과 같음. 피처만 GFS 63개 추가.
"""
import argparse
import hashlib
import json
from pathlib import Path
from uuid import uuid4

import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs
import mix_all as mx
from build_gfs_cams import (
    CAMS_CANDIDATE_COLS, CAMS_COLS, CAMS_EXCLUDED, CAMS_FEATURES, CAMS_FINAL_COLS, CAMS_RUN_ID_LEN, CAMS_SEARCH, CAMS_VALIDATION,
    CAMS_VALIDATION_STAMP, bind_features, check_cams_hours, combine, feature_digest, naive_kst,
)

ROOT = val.DEFAULT_ROOT
opt.log = lambda message: None
GFS_PATH = ROOT / "output" / "external" / "gfs_features.parquet"
TAB_BIG = ROOT / "output" / "site_tabpfn" / "random_big" / "tabpfn_eval_pred.parquet"
FOLDER = ROOT / "output" / "feat_gfs" / "random"
WA = 0.75
TEAM_GFS_COLS = [
    "gfs_mean", "gfs_std", "gfs_max",
    *(f"gfs_pc{i}" for i in range(1, 9)),
    "gfs_mean_prev", "gfs_mean_next", "gfs_mean_daysum", "gfs_mean_daymax",
]
MAX_GFS_CORR = 0.75
MAX_CAMS_CORR = 0.90
MIN_CORR_HOURS = 168


def load_gfs(like_ts, feature_path=GFS_PATH):
    g = pd.read_parquet(feature_path)
    if getattr(like_ts.dt, "tz", None) is not None:
        g["ts"] = g["ts"].dt.tz_localize(like_ts.dt.tz)
    return g


def team_gfs_frame(frame):
    cols = ["ts", *TEAM_GFS_COLS]
    missing = [col for col in cols if col not in frame]
    if missing:
        raise ValueError(f"Missing team GFS features: {', '.join(missing)}")
    return frame[cols]


def score(pred, sites, group_actual, hold_actual=None):
    """시간별 배율 -> 그리디 -> holdout 점수"""
    Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
    wg = opt.time_weights(ROOT, tg)
    c_hour = {}
    for h in range(24):
        idx = (tg.hour == h)
        if idx.sum() == 0:
            c_hour[h] = 1.0
        else:
            c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])
    cg = np.array([c_hour[h] for h in tg.hour])[:, None]
    init_mask = opt.initial_mask(sites)
    optimized, meta, trace = opt.greedy_best_improvement(cg * Pg - Yg, wg, sites, init_mask)
    sg = val.score_group(opt, ROOT, cg * Pg - Yg, tg, init_mask, optimized)
    if hold_actual is None:
        return {"group_opt_optimized": sg["W_optimized_krw"]}
    Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
    ch = np.array([c_hour[h] for h in th.hour])[:, None]
    sh = val.score_group(opt, ROOT, ch * Ph - Yh, th, init_mask, optimized)
    pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
    pred_h["pred_kwh"] = pred_h["pred_kwh"] * pred_h["ts"].dt.hour.map(c_hour)
    m_h = val.model_metrics(ROOT, hold_actual, pred_h)
    return {"weighted_MAE": round(m_h["weighted_MAE_kwh"], 5),
            "group_opt_optimized": round(sg["W_optimized_krw"]),
            "initial": round(sh["W_initial_krw"]),
            "optimized": round(sh["W_optimized_krw"]),
            "lower_bound": round(sh["W_lower_bound_krw"])}


def tree_of(folder):
    pa = pd.read_parquet(folder / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(folder / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    d = both[["site_id", "ts"]].copy()
    d["tree"] = WA * both["pred_kwh_a"] + (1 - WA) * both["pred_kwh_b"]
    return d


def screen_cams(hourly, gfs_cols, fit_ts):
    """Screen rank correlations using only observed daylight hours in model_fit."""
    fit = hourly["ts"].isin(naive_kst(fit_ts.drop_duplicates())) & (hourly["gfs_mean"] > 1)
    train = hourly.loc[fit, [*gfs_cols, *CAMS_CANDIDATE_COLS]].replace([np.inf, -np.inf], np.nan)
    train = train.dropna(subset=gfs_cols)
    min_overlap = max(MIN_CORR_HOURS, int(np.ceil(0.8 * len(train))))
    if len(train) < min_overlap:
        raise ValueError(f"Need at least {MIN_CORR_HOURS} model_fit daylight hours with all GFS features")
    varying_gfs = [col for col in gfs_cols if train[col].nunique() > 1]
    if not varying_gfs:
        raise ValueError("No varying GFS columns in the correlation sample")
    cols = [*varying_gfs, *CAMS_CANDIDATE_COLS]
    corr = train[cols].corr(method="spearman", min_periods=min_overlap).abs()
    against_gfs = corr.loc[CAMS_CANDIDATE_COLS, varying_gfs]
    report = pd.DataFrame({
        "overlap_hours": train[CAMS_CANDIDATE_COLS].notna().sum(),
        "closest_gfs": against_gfs.fillna(-1).idxmax(axis=1).where(against_gfs.notna().any(axis=1)),
        "max_abs_gfs_spearman": against_gfs.max(axis=1),
    })
    report["status"] = "insufficient_or_constant"
    selected = []
    for col, row in report.sort_values("max_abs_gfs_spearman", kind="stable").iterrows():
        similarity = row["max_abs_gfs_spearman"]
        if pd.isna(similarity):
            continue
        if similarity > MAX_GFS_CORR:
            report.loc[col, "status"] = "correlated_with_gfs"
        elif (corr.loc[col, selected] > MAX_CAMS_CORR).any():
            report.loc[col, "status"] = "redundant_with_selected_cams"
        else:
            report.loc[col, "status"] = "selected"
            selected.append(col)
    return selected, report.rename_axis("feature").reset_index()


def fit_gfs_predictions(base, sites, model_fit, eval_actual, gfs, folder):
    original_features, original_cols = base.features, base.FEATS
    gfs_cols = [col for col in gfs.columns if col not in {"ts", CAMS_EXCLUDED}]
    gfs = gfs[["ts", *gfs_cols]]
    new_feats = [col + suffix for col in fs.A_COLS + fs.B_COLS for suffix in ("_prev", "_next", "_daymean")]
    base.FEATS = list(original_cols) + new_feats + ["cloud_diff"] + fs.NAT_FEATS + fs.F3_FEATS + fs.SITE_FEATS + gfs_cols
    print("피처 수:", len(base.FEATS), "/ 외부 피처:", len(gfs_cols))

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        n = len(d)
        d = d.merge(site_table, on=["site_id", "ts"], how="left")
        d = d.merge(gfs, on="ts", how="left", validate="many_to_one")
        if len(d) != n:
            raise ValueError("피처 붙이다가 행 수가 바뀜")
        d["site_num"] = d["site_id"].str[2:].astype(int)
        return d

    try:
        site_table = fs.build_site_table(model_fit, eval_actual, sites, base)
        base.features = features_plus
        fs.get_predictions(fs.MODEL_A, base, sites, model_fit, eval_actual, folder)
        fs.get_predictions(fs.MODEL_B, base, sites, model_fit, eval_actual, folder)
    finally:
        base.features, base.FEATS = original_features, original_cols


def compare_cams(cams_path, weights, base, sites, model_fit, group_actual, hold_actual, eval_actual):
    from make_submission import blended_validation

    gfs = team_gfs_frame(pd.read_parquet(GFS_PATH))
    gfs_cols = TEAM_GFS_COLS
    cams = pd.read_parquet(cams_path)
    is_final = any(col in cams for col in CAMS_FINAL_COLS if col not in CAMS_COLS)
    feature_set = "final" if is_final else "candidates"
    hourly = combine(gfs, cams, feature_set=feature_set)
    metadata = [CAMS_EXCLUDED] if CAMS_EXCLUDED in hourly else []
    report = None
    if is_final:
        selected = CAMS_FINAL_COLS
    else:
        selected, report = screen_cams(hourly, gfs_cols, model_fit["ts"])
        print(report.to_string(index=False), flush=True)

    # Separate prediction caches by data, split, and the features in each model.
    run_inputs = [feature_digest(ROOT, GFS_PATH), feature_digest(ROOT, cams_path), str(base.TRAIN_FROM),
                  str(val.SEED), ",".join(gfs_cols), ",".join(selected)]
    if is_final:
        run_inputs.append(feature_set)
    run_id = hashlib.sha256("\n".join(run_inputs).encode()).hexdigest()[:CAMS_RUN_ID_LEN]
    search = ROOT / CAMS_SEARCH
    run = search / run_id
    run.mkdir(parents=True, exist_ok=True)
    if report is not None:
        report.to_csv(run / "correlations.csv", index=False)
    variants = {"gfs": [], "basic": CAMS_COLS}
    if selected and set(selected) != set(CAMS_COLS):
        variants["final" if is_final else "low_corr"] = selected

    rows = []
    for name, cols in variants.items():
        print(f"Validating {name}: {', '.join(cols) if cols else 'GFS only'}", flush=True)
        folder = run / name
        folder.mkdir(exist_ok=True)
        feature_path = folder / "features.parquet"
        if not feature_path.exists():
            frame = hourly[["ts", *gfs_cols, *cols, *metadata]] if cols else gfs
            temp = feature_path.with_suffix(f".{uuid4().hex}.tmp")
            try:
                frame.to_parquet(temp, index=False)
                temp.replace(feature_path)
            finally:
                temp.unlink(missing_ok=True)
        features = load_gfs(model_fit["ts"], feature_path)
        if cols:
            check_cams_hours(features, model_fit["ts"], "model_fit")
            check_cams_hours(features, group_actual["ts"], "group_opt")
        bind_features(ROOT, folder / CAMS_VALIDATION_STAMP, folder.glob("*_eval_pred.parquet"), feature_path)
        fit_gfs_predictions(base, sites, model_fit, eval_actual, features, folder)
        pred = blended_validation("gfs_cams", weights, folder=folder)
        rows.append({"variant": name, "cams_features": ",".join(cols), **score(pred, sites, group_actual)})

    table = pd.DataFrame(rows)
    winner = table.loc[table["group_opt_optimized"].idxmin(), "variant"]
    table.to_csv(run / "result.csv", index=False)
    # Score the fixed GFS reference and the chosen model after the winner is fixed.
    holdout_rows = []
    for name in dict.fromkeys(["gfs", winner]):
        pred = blended_validation("gfs_cams", weights, folder=run / name)
        holdout_rows.append({"variant": name, **score(pred, sites, group_actual, hold_actual)})
    holdout_table = pd.DataFrame(holdout_rows)
    holdout_table.to_csv(run / "holdout.csv", index=False)
    selection = {"winner": winner, "run_id": run_id, "weights": weights}
    if not is_final:
        selection.update(max_gfs_spearman=MAX_GFS_CORR, max_cams_spearman=MAX_CAMS_CORR)
    temp = search / f"selection.{uuid4().hex}.tmp"
    try:
        temp.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
        temp.replace(search / "selection.json")
    finally:
        temp.unlink(missing_ok=True)
    print(table.to_string(index=False))
    print(holdout_table.to_string(index=False))
    print("Selected:", winner, "/ reports:", run)


def main():
    ap = argparse.ArgumentParser()
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--cams", action="store_true", help="GFS + CAMS 피처 트리 검증")
    mode.add_argument("--compare-cams", type=Path, help="Compare GFS, basic CAMS and the selected CAMS table mode")
    ap.add_argument("--w", nargs=3, type=float, metavar=("TREE", "MLP", "TAB"), help="CAMS 검증 비율 (기본 1 0 0)")
    args = ap.parse_args()
    if args.w is not None and not (args.cams or args.compare_cams):
        ap.error("--w requires --cams or --compare-cams")
    folder = ROOT / CAMS_VALIDATION if args.cams else FOLDER
    weights = args.w if args.w is not None else [1.0, 0.0, 0.0]
    if args.cams or args.compare_cams:
        from make_submission import blended_validation, valid_weights

        valid_weights(weights)
    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_gfstree")

    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]
    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    model_fit, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    model_fit = pd.concat([gen[gen["ts"] < base.TRAIN_FROM], model_fit], ignore_index=True)
    eval_actual = pd.concat([group_actual, hold_actual], ignore_index=True)
    del gen, baseline_gen

    if args.compare_cams:
        compare_cams(ROOT / args.compare_cams, weights, base, sites, model_fit, group_actual, hold_actual, eval_actual)
        return

    folder.mkdir(parents=True, exist_ok=True)
    gfs = load_gfs(model_fit["ts"], ROOT / CAMS_FEATURES if args.cams else GFS_PATH)
    if args.cams:
        if CAMS_EXCLUDED in gfs and gfs[CAMS_EXCLUDED].eq(True).any():
            ap.error("CAMS exclusions require --compare-cams with the standalone CAMS table")
        check_cams_hours(gfs, model_fit["ts"], "model_fit")
        check_cams_hours(gfs, group_actual["ts"], "group_opt")
        check_cams_hours(gfs, hold_actual["ts"], "holdout")
        bind_features(ROOT, folder / CAMS_VALIDATION_STAMP, folder.glob("*_eval_pred.parquet"))
    gfs_cols = [c for c in gfs.columns if c != "ts"]
    feature_label = "GFS + CAMS" if args.cams else "GFS"
    print(feature_label, "피처:", len(gfs_cols), "개 /", len(gfs), "시각")

    fit_gfs_predictions(base, sites, model_fit, eval_actual, gfs, folder)
    del model_fit

    if args.cams:
        kinds = ["gfs_cams"]
        if all((FOLDER / name).exists() for name in ("l1_cap_smpk_eval_pred.parquet", "cat_l1_cap_smpk_eval_pred.parquet")):
            kinds.insert(0, "gfs")
        rows = []
        for kind in kinds:
            pred = blended_validation(kind, weights)
            rows.append({"tree": kind, "w_tree": weights[0], "w_mlp": weights[1], "w_tab": weights[2],
                         **score(pred, sites, group_actual, hold_actual)})
        table = pd.DataFrame(rows)
        table.to_csv(folder / "result.csv", index=False)
        print(table.to_string(index=False))
        return

    # ---------- 2. 섞기 비교 ----------
    old = tree_of(mx.OURS).rename(columns={"tree": "tree_old"})
    new = tree_of(FOLDER).rename(columns={"tree": "tree_gfs"})
    d = old.merge(new, on=["site_id", "ts"])
    tab = pd.read_parquet(TAB_BIG).rename(columns={"pred_kwh": "tab"})
    tab["ts"] = val.to_kst(tab["ts"])
    d = d.merge(tab, on=["site_id", "ts"], how="left")
    d = d.merge(mx.load_mlp(), on=["site_id", "ts"], how="left")
    d["tab"] = d["tab"].fillna(d["tree_old"])
    d["mlp"] = d["mlp_kwh"].fillna(d["tree_old"])
    night = d["tree_old"] <= 0
    d.loc[night, ["tab", "mlp", "tree_gfs"]] = 0.0

    cands = [("기존 트리만", "tree_old", 1.0, 0.0, 0.0),
             ("GFS 트리만", "tree_gfs", 1.0, 0.0, 0.0),
             ("기존 트리 20 : MLP 30 : TabPFN 50 (No.60)", "tree_old", 0.2, 0.3, 0.5)]
    for w_tab in [0.0, 0.1, 0.2, 0.3, 0.4]:
        for w_mlp in [0.1, 0.2, 0.3]:
            w_tree = round(1 - w_tab - w_mlp, 2)
            if w_tree < 0.3:
                continue
            label = ("GFS 트리 " + str(int(w_tree * 100)) + " : MLP " + str(int(w_mlp * 100))
                     + " : TabPFN " + str(int(w_tab * 100)))
            cands.append((label, "tree_gfs", w_tree, w_mlp, w_tab))

    rows = []
    for label, tcol, w_tree, w_mlp, w_tab in cands:
        pred = d[["site_id", "ts"]].copy()
        pred["pred_kwh"] = w_tree * d[tcol] + w_mlp * d["mlp"] + w_tab * d["tab"]
        r = {"blend": label, **score(pred, sites, group_actual, hold_actual)}
        rows.append(r)
        print(label, "| 최적", f"{r['optimized']:,}", "| group_opt", f"{r['group_opt_optimized']:,}")

    table = pd.DataFrame(rows)
    table.to_csv(FOLDER / "result.csv", index=False)
    gfs_rows = table[table["blend"].str.startswith("GFS 트리 ")]
    best = gfs_rows.loc[gfs_rows["group_opt_optimized"].idxmin()]
    print("=" * 70)
    print("비교 기준 No.60 (기존 트리 20 : MLP 30 : TabPFN 50) holdout 56,886,019")
    print(table.to_string(index=False))
    print("-" * 70)
    print("GFS 섞기 중 group_opt 기준 최선:", best["blend"], "-> holdout 최적", f"{best['optimized']:,}")


if __name__ == "__main__":
    main()
