"""No.56: 53번 트리(feat_site) + 54번 명준 MLP(하루 24시간 출력) 섞기.
채택: 트리 60 : MLP 40 + 시간별 배율 (group_opt 기준 최선)
위치: codes/mix_mlp.py
실행: python3 codes/mix_mlp.py
필요:
  output/feat_site/random/            (feat_site.py --split random 결과)
  output/sleeping_ranking_50/_baseline_cache/group_opt_predictions.parquet, holdout_predictions.parquet
  output/sleeping_ranking_50/new_cand_17_tide_day_curve/candidate_group_opt_predictions.parquet,
                                                         candidate_holdout_predictions.parquet
  (명준 코드 new_cand_17_tide_day_curve.py 를 돌리면 생기는 파일들)

명준 결과 = 0.6 x 명준 28번 + 0.4 x MLP 라서
  MLP = (명준 결과 - 0.6 x 명준 28번) / 0.4  로 MLP 예측만 다시 뽑음
그다음 우리 트리(LGBM 75 : Cat 25) 와 MLP 를 비율별로 섞고, 시간 배율 보정 있음/없음 비교.
재학습 없음. 분할(seed 42, 60/20/20)은 명준 코드와 같음.
"""
import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs

ROOT = val.DEFAULT_ROOT
opt.log = lambda message: None
OURS = ROOT / "output" / "feat_site" / "random"
MJ = ROOT / "output" / "sleeping_ranking_50"
WA = 0.75                              # 우리 트리: LGBM 75 : Cat 25
MLP_LIST = [0.0, 0.2, 0.3, 0.4, 0.5]   # MLP 비율


def load_mlp():
    parts = []
    for part in ["group_opt", "holdout"]:
        base28 = pd.read_parquet(MJ / "_baseline_cache" / (part + "_predictions.parquet"),
                                 columns=["site_id", "ts", "pred_kwh"])
        cand = pd.read_parquet(MJ / "new_cand_17_tide_day_curve" / ("candidate_" + part + "_predictions.parquet"))
        d = base28.merge(cand, on=["site_id", "ts"], suffixes=("_28", "_cand"))
        d["mlp_kwh"] = (d["pred_kwh_cand"] - 0.6 * d["pred_kwh_28"]) / 0.4
        d["mlp_kwh"] = d["mlp_kwh"].clip(lower=0)
        parts.append(d[["site_id", "ts", "mlp_kwh"]])
    mlp = pd.concat(parts, ignore_index=True)
    mlp["ts"] = val.to_kst(mlp["ts"])
    return mlp


def main():
    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_mixmlp")
    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]

    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    model_fit, group_actual, hold_actual, day_split = val.split_602020(baseline_gen, val.SEED)
    del gen, baseline_gen, model_fit

    # 우리 트리 예측
    pa = pd.read_parquet(OURS / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(OURS / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    tree = both[["site_id", "ts"]].copy()
    tree["tree_kwh"] = WA * both["pred_kwh_a"] + (1 - WA) * both["pred_kwh_b"]

    # 명준 MLP 예측 붙이기
    mlp = load_mlp()
    d = tree.merge(mlp, on=["site_id", "ts"], how="left")
    n_eval = len(group_actual) + len(hold_actual)
    print("우리 예측 행:", len(tree), "/ MLP 붙은 행:", int(d["mlp_kwh"].notna().sum()), "/ 평가 행:", n_eval)
    if d["mlp_kwh"].notna().sum() < 0.99 * n_eval:
        raise ValueError("MLP 예측이 평가 행과 거의 안 맞음 -> 분할이 다른지 확인")
    d["mlp_kwh"] = d["mlp_kwh"].fillna(d["tree_kwh"])
    # 밤(트리 예측 0)은 MLP 도 0
    d.loc[d["tree_kwh"] <= 0, "mlp_kwh"] = 0.0

    init_mask = opt.initial_mask(sites)
    rows = []
    for m in MLP_LIST:
        pred = d[["site_id", "ts"]].copy()
        pred["pred_kwh"] = (1 - m) * d["tree_kwh"] + m * d["mlp_kwh"]
        label = "트리 " + str(int(round((1 - m) * 100))) + " : MLP " + str(int(round(m * 100)))

        Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
        Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
        wg = opt.time_weights(ROOT, tg)

        c_hour = {}
        for h in range(24):
            idx = (tg.hour == h)
            if idx.sum() == 0:
                c_hour[h] = 1.0
            else:
                c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])

        for how in ["보정 없음", "시간별 배율"]:
            pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
            if how == "보정 없음":
                cg, ch = 1.0, 1.0
            else:
                cg = np.array([c_hour[h] for h in tg.hour])[:, None]
                ch = np.array([c_hour[h] for h in th.hour])[:, None]
                pred_h["pred_kwh"] = pred_h["pred_kwh"] * pred_h["ts"].dt.hour.map(c_hour)
            m_h = val.model_metrics(ROOT, hold_actual, pred_h)

            mat_g = cg * Pg - Yg
            mat_h = ch * Ph - Yh
            optimized, meta, trace = opt.greedy_best_improvement(mat_g, wg, sites, init_mask)
            score_g = val.score_group(opt, ROOT, mat_g, tg, init_mask, optimized)
            score_h = val.score_group(opt, ROOT, mat_h, th, init_mask, optimized)

            row = {
                "blend": label,
                "fix": how,
                "weighted_MAE": round(m_h["weighted_MAE_kwh"], 5),
                "group_opt_optimized": round(score_g["W_optimized_krw"]),
                "initial": round(score_h["W_initial_krw"]),
                "optimized": round(score_h["W_optimized_krw"]),
                "lower_bound": round(score_h["W_lower_bound_krw"]),
            }
            rows.append(row)
            print(label, how, "| 초기", f"{row['initial']:,}", "| 최적", f"{row['optimized']:,}",
                  "| 하한", f"{row['lower_bound']:,}")

    table = pd.DataFrame(rows)
    table.to_csv(OURS / "mix_mlp_result.csv", index=False)
    print("=" * 70)
    print("비교: No.53 (트리만 + 시간 배율) 최적 61,811,306")
    print("비율은 group_opt_optimized 가 제일 낮은 걸로 고르기")
    print(table.to_string(index=False))


if __name__ == "__main__":
    main()
