# No.56 ~ 58 코드 (세준)

검증: No.2 (랜덤 60/20/20, seed 42). 모든 비율·보정은 group_opt 날짜로 정하고 holdout 은 평가에만 사용.

| No. | 내용 | 비율 | Optimized (holdout) |
|---|---|---|---|
| 56 | 53 + 54(MLP) 앙상블 + 시간 배율 | 트리 60 : MLP 40 | 58,096,215 |
| 57 | 56 + 발전소별 TabPFN | 트리 40 : MLP 30 : TabPFN 30 | 57,365,924 |
| 58 | 57 + 앙상블 비율 변경 | 트리 20 : MLP 30 : TabPFN 50 | 56,999,728 |

- 트리 = No.53 (`feat_site.py`, LGBM 75 : Cat 25)
- MLP = No.54 명준 코드 (`new_cand_17_tide_day_curve.py`) 결과에서 MLP 부분만 다시 뽑아서 사용
  (명준 결과 = 0.6 × No.28 + 0.4 × MLP 이므로 MLP = (결과 − 0.6 × No.28) / 0.4)
- 시간 배율 = 시각(0~23시)마다 배율 1개, group_opt 날짜의 가중 오차가 제일 작은 값

## 파일

| 파일 | 하는 일 |
|---|---|
| `feat_site.py` | No.51~53 트리 (재학습). 결과: `output/feat_site/random/` |
| `mix_mlp.py` | No.56 트리 + MLP 섞기 (재학습 없음) |
| `site_tabpfn.py` | 발전소별 TabPFN 예측. 결과: `output/site_tabpfn/random/tabpfn_eval_pred.parquet` |
| `mix_all.py` | No.57·58 트리 + MLP + TabPFN 섞기 (재학습 없음) |

필요한 기존 파일 (codes 폴더): `baseline_validation.py`, `baseline_optimizer.py`, `validation_timesplit.py`, 명준 No.54 코드 (`_core.py` 등)

## 실행 순서

```
python codes/feat_site.py --split random          # 1. 트리 (CPU, 수십 분)
python codes/new_cand_17_tide_day_curve.py        # 2. 명준 MLP (CPU) -> output/sleeping_ranking_50/
python codes/mix_mlp.py                           # 3. No.56
python codes/site_tabpfn.py                       # 4. TabPFN (GPU 약 2시간)
python codes/mix_all.py --only 0.4 0.3 0.3        # 5. No.57
python codes/mix_all.py --only 0.2 0.3 0.5        # 6. No.58
```

`--only 트리 MLP TabPFN` 으로 비율 하나만 계산. 빼면 후보 전부 (오래 걸림).

## TabPFN 설정

- 모델: **TabPFN-2 회귀** (`Prior-Labs/TabPFN-v2-reg`, Prior Labs License = Apache 2.0 + 출처 표기)
  - 코드에서 v2 로 고정. TabPFN-2.5 이상은 비상업 라이선스라 사용 안 함
  - 공개 배포 시 "Built with PriorLabs-TabPFN" 표기 필요
  - 사용 가능 여부 주최측 문의 중
- 발전소 253개 각각 따로: 그 발전소의 학습 날짜 낮 시간 행 (최대 5,000행, 넘으면 무작위 추출) 으로 맥락 구성 -> 평가 날짜 예측
- 입력 64개 = No.28 피처 + 구름 패턴 16개 (발전소마다 같은 값인 lat, lon, cap 제외), 17시판 예보만 사용
- 출력: 이용률 중앙값(median) × 용량, 밤 = 0
- n_estimators = 4, 미세조정 없음, 대회 데이터 외부 전송 없음 (사용 기록 전송도 끔)
- 단독 holdout Weighted MAE 8.303 (No.53 트리 8.331)

## 환경

- 집 PC: Ryzen 5 9600X + Radeon RX 9060 XT 16GB, Windows 11
- Python 3.12, PyTorch 2.9.1 + ROCm 7.2.1 (AMD 공식 Windows 빌드), tabpfn, lightgbm, catboost
- AMD GPU 는 `site_tabpfn.py` 안에서 `TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL=1` 설정 (안 하면 GPU 메모리 부족)
- GPU 없으면 CPU 로 돌지만 매우 느림 (발전소당 수 분)
- 최신 pandas 에서 명준 `_core.py` 135번 줄 `.to_numpy(float)` 뒤에 `.copy()` 필요 (읽기 전용 배열 에러)
