"""발전소마다 TabPFN-2 따로 돌리기 (집 GPU용, 랜덤 검증).
위치: codes/site_tabpfn.py  (feat_site.py 와 같은 폴더)
실행: python codes/site_tabpfn.py
      집 PC (RX 9060 XT 16GB, ROCm PyTorch) 기준 약 2시간
      (중간에 꺼져도 다시 실행하면 끝난 발전소는 건너뜀)

방법
  발전소 1개씩:
    학습 = 그 발전소의 학습 날짜 낮 시간 행 (최대 10,000행, 넘으면 무작위로 뽑음)
    입력 = 17시판 예보 + 피처3탄까지 (발전소마다 같은 값인 lat, lon, cap 은 뺌)
    정답 = 이용률 (0 ~ 1.2)
    예측 = 그 발전소의 평가 날짜(group_opt + holdout) 낮 시간 -> 중앙값(median) 으로
  밤은 0
  평가 날짜는 학습에 안 들어감 -> 누수 없음
TabPFN-2 고정 (Apache 2.0 + 출처 표기). 2.5 이상은 비상업 라이선스라 못 씀.

결과: output/site_tabpfn/random/tabpfn_eval_pred.parquet  (site_id, ts, pred_kwh)
"""
import os
os.environ["TABPFN_DISABLE_TELEMETRY"] = "1"                 # 사용 기록 전송 끔 (데이터 외부 전송 없음)
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"                  # 윈도우에서 LightGBM + torch 같이 쓸 때 충돌 방지
os.environ["TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL"] = "1"  # AMD GPU: 메모리 아끼는 attention 켜기 (안 켜면 메모리 부족)
os.environ["TABPFN_ALLOW_CPU_LARGE_DATASET"] = "1"           # GPU 없을 때 CPU 로도 돌게 (매우 느림)

import time
import numpy as np
import pandas as pd

import baseline_validation as val
import feat_site as fs

ROOT = val.DEFAULT_ROOT
OUT = ROOT / "output" / "site_tabpfn" / "random"
SITE_DIR = OUT / "sites"
import torch
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"   # AMD ROCm PyTorch 도 이름은 cuda
MAX_CTX = 5000           # 57·58번에 쓴 값 (발전소별 학습 최대 행)
N_EST = 4                # 57·58번에 쓴 값
ROUND = 17


def make_model():
    from tabpfn import TabPFNRegressor
    from tabpfn.constants import ModelVersion
    return TabPFNRegressor.create_default_for_version(ModelVersion.V2, device=DEVICE,
                                                      random_state=42, n_estimators=N_EST)


def fit_predict_site(X_tr, y_tr, X_te):
    model = make_model()
    model.fit(X_tr, y_tr)
    preds = []
    for start in range(0, len(X_te), 500):     # 500행씩 (한 번에 하면 GPU 메모리 부족)
        preds.append(model.predict(X_te[start:start + 500], output_type="median"))
    return np.concatenate(preds)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    SITE_DIR.mkdir(parents=True, exist_ok=True)
    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_sitetabpfn")

    # 피처 = 피처3탄까지 (발전소별 피처는 발전소 안에서 거의 상수라 뺌)
    new_feats = []
    for c in fs.A_COLS + fs.B_COLS:
        new_feats = new_feats + [c + "_prev", c + "_next", c + "_daymean"]
    new_feats.append("cloud_diff")
    new_feats = new_feats + fs.NAT_FEATS + fs.F3_FEATS
    feats = []
    for c in list(base.FEATS) + new_feats:
        if c not in ["lat", "lon", "cap"]:
            feats.append(c)
    print("TabPFN 피처 수:", len(feats))

    original_features = base.features

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        return d

    base.features = features_plus

    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]

    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    model_fit, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    old = gen[gen["ts"] < base.TRAIN_FROM].copy()
    model_fit = pd.concat([old, model_fit], ignore_index=True)
    del gen, baseline_gen, old
    eval_actual = pd.concat([group_actual, hold_actual], ignore_index=True)

    # 날씨 피처 (feat_site 와 같음)
    fa, fb = val.load_weather(ROOT, base, model_fit["ts"].min())
    fa, _ = fs.add_time_feats(fa, "wa_station", fs.A_COLS)
    fb, _ = fs.add_time_feats(fb, "wb_station", fs.B_COLS)
    fa = fs.drop_next_at_midnight(fa, fs.A_COLS)
    fb = fs.drop_next_at_midnight(fb, fs.B_COLS)
    fa, fb = fs.add_national(fa, fb)
    fa = fs.add_feat3(fa, "wa_station", "wa_cloud")
    fb = fs.add_feat3(fb, "wb_station", "wb_cloud")

    print("피처 만드는 중 ...")
    tr = base.features(model_fit, sites, fa, fb, None, ROUND)
    tr = tr[tr["elev"] > 0]
    tr = tr[["site_id", "energy", "cap"] + feats].copy()
    tr["y"] = (tr["energy"] / tr["cap"]).clip(0, 1.2)
    ev = base.features(eval_actual, sites, fa, fb, None, ROUND)
    if len(ev) != len(eval_actual):
        raise ValueError("평가 행 수가 바뀜")
    ev_day = ev[ev["elev"] > 0][["site_id", "ts", "cap"] + feats].copy()
    del fa, fb, model_fit
    print("학습 낮 행:", len(tr), "/ 평가 낮 행:", len(ev_day))

    tr_groups = dict(list(tr.groupby("site_id")))
    ev_groups = dict(list(ev_day.groupby("site_id")))
    rng = np.random.default_rng(42)

    site_list = list(sites["site_id"])
    started = time.time()
    for i, site in enumerate(site_list):
        path = SITE_DIR / (site + ".parquet")
        if path.exists():
            continue
        if site not in ev_groups:
            continue
        t = tr_groups.get(site)
        e = ev_groups[site]
        if t is None or len(t) < 200:
            print(site, ": 학습 행이 너무 적어서 건너뜀 ->", 0 if t is None else len(t))
            continue
        if len(t) > MAX_CTX:
            pick = rng.choice(len(t), MAX_CTX, replace=False)
            t = t.iloc[np.sort(pick)]

        X_tr = t[feats].to_numpy(np.float32)
        y_tr = t["y"].to_numpy(np.float32)
        X_te = e[feats].to_numpy(np.float32)
        cf = fit_predict_site(X_tr, y_tr, X_te)
        cf = np.clip(cf, 0, 1.2)

        out = e[["site_id", "ts"]].copy()
        out["pred_kwh"] = cf * e["cap"].to_numpy()
        out.to_parquet(path, index=False)

        spent = time.time() - started
        print(f"[{i + 1}/{len(site_list)}] {site} 학습 {len(t):,}행 / 예측 {len(e):,}행 / 누적 {spent / 60:.1f}분")

    # 모으기: 평가 전체 행 (밤 = 0, 학습 행 부족으로 건너뛴 발전소도 0)
    parts = []
    for site in site_list:
        path = SITE_DIR / (site + ".parquet")
        if path.exists():
            parts.append(pd.read_parquet(path))
    day_pred = pd.concat(parts, ignore_index=True)
    allp = ev[["site_id", "ts"]].merge(day_pred, on=["site_id", "ts"], how="left")
    print("TabPFN 예측 없는 낮 행 (0으로 채움):",
          int(allp["pred_kwh"].isna().sum() - (ev["elev"] <= 0).sum()))
    allp["pred_kwh"] = allp["pred_kwh"].fillna(0.0)
    allp.to_parquet(OUT / "tabpfn_eval_pred.parquet", index=False)

    pred_h = allp.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
    m_h = val.model_metrics(ROOT, hold_actual, pred_h)
    print("=" * 60)
    print("TabPFN 단독 holdout Weighted MAE:", round(m_h["weighted_MAE_kwh"], 5),
          "(비교: 41번 트리 8.33100)")
    print("저장:", OUT / "tabpfn_eval_pred.parquet")


if __name__ == "__main__":
    main()
