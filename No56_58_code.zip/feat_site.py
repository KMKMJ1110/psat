"""피처 3탄(67개) + 발전소별 피처 5개.
위치: codes/feat_site.py
실행:
  python3 codes/feat_site.py --split random
  python3 codes/feat_site.py --split time

발전소별 피처 (명준님 아이디어 + 규민님 site_id)
  site_cf_all    : 이 발전소의 평균 이용률 (낮 시간)
  site_cf_season : 이 발전소의 같은 계절 평균 이용률
  site_cf_hour   : 이 발전소의 같은 시각 평균 이용률
  site_cf_ampm   : 이 발전소의 오전/오후 평균 이용률
  site_num       : 발전소 번호 (PV001 -> 1)
누수 방지: 평균은 '학습 날짜'로만 계산.
  학습 행은 5등분 교차 (자기 날짜를 뺀 나머지로 계산한 평균을 붙임)
  평가 행은 학습 날짜 전체 평균을 붙임
"""
import argparse

import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import validation_timesplit as vt

ROOT = val.DEFAULT_ROOT
opt.log = lambda message: None

MODEL_A = "l1_cap_smpk"
MODEL_B = "cat_l1_cap_smpk"
WEIGHTS_A = [1.0, 0.75, 0.5, 0.25, 0.0]
GRID = np.arange(0.85, 1.2001, 0.005)

A_COLS = ["wa_cloud", "wa_rain", "wa_humidity"]
B_COLS = ["wb_cloud", "wb_uv_idx", "wb_total_liq"]


def add_time_feats(f, station, cols):
    """관측소 + 회차별로 1시간 전/후 값, 그날 평균 붙이기"""
    f = f.sort_values([station, "round", "ts"]).copy()
    g = f.groupby([station, "round"])
    new_cols = []
    for c in cols:
        f[c + "_prev"] = g[c].shift(1)
        f[c + "_next"] = g[c].shift(-1)
        new_cols.append(c + "_prev")
        new_cols.append(c + "_next")

    f["_day"] = (f["ts"] - pd.Timedelta(hours=1)).dt.normalize()
    g2 = f.groupby([station, "round", "_day"])
    for c in cols:
        f[c + "_daymean"] = g2[c].transform("mean")
        new_cols.append(c + "_daymean")
    f = f.drop(columns="_day")
    return f, new_cols


def add_national(fa, fb):
    """시각 + 회차마다 전국 관측소 요약을 붙이고, 내 관측소 - 전국 평균 차이도 계산"""
    na = fa.groupby(["round", "ts"]).agg(a_nat_cloud_mean=("wa_cloud", "mean"),
                                         a_nat_cloud_std=("wa_cloud", "std"),
                                         a_nat_rain_mean=("wa_rain", "mean")).reset_index()
    nb = fb.groupby(["round", "ts"]).agg(b_nat_cloud_mean=("wb_cloud", "mean"),
                                         b_nat_cloud_std=("wb_cloud", "std"),
                                         b_nat_uv_mean=("wb_uv_idx", "mean")).reset_index()
    fa = fa.merge(na, on=["round", "ts"], how="left")
    fb = fb.merge(nb, on=["round", "ts"], how="left")
    fa["a_cloud_dev"] = fa["wa_cloud"] - fa["a_nat_cloud_mean"]
    fb["b_cloud_dev"] = fb["wb_cloud"] - fb["b_nat_cloud_mean"]
    return fa, fb


F3_COLS = ["wa_cloud", "wb_cloud"]


def add_feat3(f, station, col):
    """그날(같은 회차) 안에서 창 평균, 최소/최대, 9/12/15시 값 + 17시판-10시판 차이"""
    f = f.sort_values([station, "round", "ts"]).reset_index(drop=True)
    f["_day"] = (f["ts"] - pd.Timedelta(hours=1)).dt.normalize()
    g = f.groupby([station, "round", "_day"])[col]

    # 앞뒤 k시간 평균 (그날 안에서만, 없는 칸은 빼고 평균)
    shifted = {}
    for k in range(-3, 4):
        shifted[k] = g.shift(k)
    win5 = pd.concat([shifted[k] for k in range(-2, 3)], axis=1)
    win7 = pd.concat([shifted[k] for k in range(-3, 4)], axis=1)
    f[col + "_win5"] = win5.mean(axis=1)
    f[col + "_win7"] = win7.mean(axis=1)

    f[col + "_daymin"] = g.transform("min")
    f[col + "_daymax"] = g.transform("max")

    hour = f["ts"].dt.hour.to_numpy()
    for h in [9, 12, 15]:
        part = f.loc[hour == h, [station, "round", "_day", col]]
        part = part.rename(columns={col: col + "_at" + str(h)})
        f = f.merge(part, on=[station, "round", "_day"], how="left")

    r10 = f.loc[f["round"] == 10, [station, "ts", col]].rename(columns={col: "_r10"})
    r17 = f.loc[f["round"] == 17, [station, "ts", col]].rename(columns={col: "_r17"})
    f = f.merge(r10, on=[station, "ts"], how="left")
    f = f.merge(r17, on=[station, "ts"], how="left")
    f[col + "_rdiff"] = f["_r17"] - f["_r10"]
    f = f.drop(columns=["_day", "_r10", "_r17"])
    return f


F3_FEATS = []
for _c in F3_COLS:
    for _s in ["_win5", "_win7", "_daymin", "_daymax", "_at9", "_at12", "_at15", "_rdiff"]:
        F3_FEATS.append(_c + _s)


def drop_next_at_midnight(f, cols):
    """ts 00:00(=24시)의 '1시간 후' 값은 다음날 발행분 -> 비움"""
    midnight = f["ts"].dt.hour == 0
    for c in cols:
        f.loc[midnight, c + "_next"] = np.nan
    return f


SITE_FEATS = ["site_cf_all", "site_cf_season", "site_cf_hour", "site_cf_ampm", "site_num"]


def daylight_cf(rows, sites, base):
    """낮 시간 행만 남기고 이용률, 계절, 시각, 오전/오후, 날짜 붙이기"""
    d = rows[["site_id", "ts", "energy"]].merge(
        sites[["site_id", "capacity_kw", "lat", "lon"]], on="site_id", how="left")
    elev, _, _ = base.solar(pd.DatetimeIndex(d["ts"]), d["lat"].to_numpy(), d["lon"].to_numpy())
    d = d[elev > 0].copy()
    d["cf"] = (d["energy"] / d["capacity_kw"]).clip(0, 1.2)
    month = d["ts"].dt.month
    d["season"] = (month % 12) // 3          # 0 겨울, 1 봄, 2 여름, 3 가을
    d["hour"] = d["ts"].dt.hour
    d["ampm"] = (d["hour"] > 12).astype(int)  # 0 오전(~12시), 1 오후
    d["day"] = (d["ts"] - pd.Timedelta(hours=1)).dt.normalize()
    return d[["site_id", "ts", "cf", "season", "hour", "ampm", "day"]]


def attach_site_stats(target, source):
    """source 로 계산한 발전소별 평균을 target 행에 붙임"""
    out = target[["site_id", "ts", "season", "hour", "ampm"]].copy()
    t_all = source.groupby("site_id")["cf"].mean().rename("site_cf_all").reset_index()
    t_sea = source.groupby(["site_id", "season"])["cf"].mean().rename("site_cf_season").reset_index()
    t_hr = source.groupby(["site_id", "hour"])["cf"].mean().rename("site_cf_hour").reset_index()
    t_ap = source.groupby(["site_id", "ampm"])["cf"].mean().rename("site_cf_ampm").reset_index()
    out = out.merge(t_all, on="site_id", how="left")
    out = out.merge(t_sea, on=["site_id", "season"], how="left")
    out = out.merge(t_hr, on=["site_id", "hour"], how="left")
    out = out.merge(t_ap, on=["site_id", "ampm"], how="left")
    return out[["site_id", "ts", "site_cf_all", "site_cf_season", "site_cf_hour", "site_cf_ampm"]]


def build_site_table(model_fit, eval_actual, sites, base, n_folds=5):
    """학습 행: 5등분 교차 평균 / 평가 행: 학습 전체 평균"""
    tr = daylight_cf(model_fit, sites, base)
    ev = daylight_cf(eval_actual, sites, base)

    day_list = sorted(tr["day"].unique())
    fold_of_day = {}
    for i, d in enumerate(day_list):
        fold_of_day[d] = i % n_folds
    fold = tr["day"].map(fold_of_day).to_numpy()

    parts = []
    for f in range(n_folds):
        parts.append(attach_site_stats(tr[fold == f], tr[fold != f]))
    parts.append(attach_site_stats(ev, tr))
    table = pd.concat(parts, ignore_index=True)
    print("발전소 평균 표:", len(table), "행 (학습", len(tr), "+ 평가", len(ev), ")")
    return table


NAT_FEATS = ["a_nat_cloud_mean", "a_nat_cloud_std", "a_nat_rain_mean", "a_cloud_dev",
             "b_nat_cloud_mean", "b_nat_cloud_std", "b_nat_uv_mean", "b_cloud_dev"]


def get_predictions(variant, base, sites, model_fit, eval_actual, folder):
    path = folder / (variant + "_eval_pred.parquet")
    if path.exists():
        print(variant, ": 저장된 예측 불러옴")
        return pd.read_parquet(path)

    print(variant, ": 학습 시작")
    fa, fb = val.load_weather(ROOT, base, model_fit["ts"].min())
    fa, _ = add_time_feats(fa, "wa_station", A_COLS)
    fb, _ = add_time_feats(fb, "wb_station", B_COLS)
    fa = drop_next_at_midnight(fa, A_COLS)
    fb = drop_next_at_midnight(fb, B_COLS)
    fa, fb = add_national(fa, fb)
    fa = add_feat3(fa, "wa_station", "wa_cloud")
    fb = add_feat3(fb, "wb_station", "wb_cloud")
    models, rounds, params = vt.fit_models_weighted(base, sites, model_fit, fa, fb, variant)
    pred = val.predict_eval(base, models, rounds, sites, eval_actual, fa, fb)
    pred.to_parquet(path, index=False)
    print(variant, ": 예측 저장 ->", path)
    return pred


def to_mats(actual, pred, site_ids):
    df = actual[["site_id", "ts", "energy"]].merge(pred, on=["site_id", "ts"])
    P = df.pivot(index="ts", columns="site_id", values="pred_kwh").reindex(columns=list(site_ids)).sort_index()
    Y = df.pivot(index="ts", columns="site_id", values="energy").reindex(columns=list(site_ids)).sort_index()
    return P.fillna(0).to_numpy(), Y.fillna(0).to_numpy(), pd.DatetimeIndex(P.index)


def best_c(P, Y, w):
    ps = P.sum(axis=1)
    ys = Y.sum(axis=1)
    best, best_loss = 1.0, None
    for c in GRID:
        loss = np.sum(w * np.abs(c * ps - ys))
        if best_loss is None or loss < best_loss:
            best, best_loss = c, loss
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="random", choices=["random", "time"])
    args = ap.parse_args()

    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_featsite")

    # 피처 목록에 새 피처 추가 + A-B 구름 차이
    new_feats = []
    for c in A_COLS + B_COLS:
        new_feats = new_feats + [c + "_prev", c + "_next", c + "_daymean"]
    new_feats.append("cloud_diff")
    new_feats = new_feats + NAT_FEATS + F3_FEATS + SITE_FEATS
    base.FEATS = list(base.FEATS) + new_feats

    print("피처 수:", len(base.FEATS))

    folder = ROOT / "output" / "feat_site" / args.split
    folder.mkdir(parents=True, exist_ok=True)
    print("저장 위치:", folder)

    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]

    gen = pd.read_parquet(ROOT / "train" / "generation.parquet",
                          columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    if args.split == "random":
        baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
        model_fit, group_actual, hold_actual, day_split = val.split_602020(baseline_gen, val.SEED)
        old = gen[gen["ts"] < base.TRAIN_FROM].copy()
        model_fit = pd.concat([old, model_fit], ignore_index=True)
        print("이전 데이터 추가:", len(old), "행")
        del baseline_gen
    else:
        model_fit, valid, group_actual, hold_actual = vt.split_year(gen)
    del gen

    eval_actual = pd.concat([group_actual, hold_actual], ignore_index=True)
    print("학습 행:", len(model_fit), " 평가 행:", len(eval_actual))

    # 발전소별 평균 (누수 없이) -> features 에서 붙임
    site_table = build_site_table(model_fit, eval_actual, sites, base)
    original_features = base.features

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        n = len(d)
        d = d.merge(site_table, on=["site_id", "ts"], how="left")
        if len(d) != n:
            raise ValueError("발전소 평균 붙이다가 행 수가 바뀜")
        d["site_num"] = d["site_id"].str[2:].astype(int)
        return d

    base.features = features_plus

    pred_a = get_predictions(MODEL_A, base, sites, model_fit, eval_actual, folder)
    pred_b = get_predictions(MODEL_B, base, sites, model_fit, eval_actual, folder)
    del model_fit

    both = pred_a.merge(pred_b, on=["site_id", "ts"], suffixes=("_a", "_b"))
    init_mask = opt.initial_mask(sites)
    rows = []
    for wa in WEIGHTS_A:
        pred = both[["site_id", "ts"]].copy()
        pred["pred_kwh"] = wa * both["pred_kwh_a"] + (1 - wa) * both["pred_kwh_b"]
        label = "LGBM " + str(int(wa * 100)) + "% + Cat " + str(int((1 - wa) * 100)) + "%"

        pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
        m_h = val.model_metrics(ROOT, hold_actual, pred_h)   # random: holdout / time: 홀수 주

        Pg, Yg, tg = to_mats(group_actual, pred, sites.site_id)
        Ph, Yh, th = to_mats(hold_actual, pred, sites.site_id)
        wg = opt.time_weights(ROOT, tg)

        c_hour = {}
        for h in range(24):
            idx = (tg.hour == h)
            if idx.sum() == 0:
                c_hour[h] = 1.0
            else:
                c_hour[h] = best_c(Pg[idx], Yg[idx], wg[idx])

        for how in ["보정 없음", "시간별 배율"]:
            if how == "보정 없음":
                cg, ch = 1.0, 1.0
            else:
                cg = np.array([c_hour[h] for h in tg.hour])[:, None]
                ch = np.array([c_hour[h] for h in th.hour])[:, None]
            mat_g = cg * Pg - Yg
            mat_h = ch * Ph - Yh
            optimized, meta, trace = opt.greedy_best_improvement(mat_g, wg, sites, init_mask)
            score_h = val.score_group(opt, ROOT, mat_h, th, init_mask, optimized)

            row = {
                "blend": label,
                "fix": how,
                "weighted_MAE": round(m_h["weighted_MAE_kwh"], 5) if how == "보정 없음" else None,
                "initial": round(score_h["W_initial_krw"]),
                "optimized": round(score_h["W_optimized_krw"]),
                "lower_bound": round(score_h["W_lower_bound_krw"]),
            }
            rows.append(row)
            print(label, how, "| 초기", f"{row['initial']:,}", "| 최적", f"{row['optimized']:,}",
                  "| 하한", f"{row['lower_bound']:,}")

    table = pd.DataFrame(rows)
    table.to_csv(folder / "result.csv", index=False)
    print("=" * 70)
    if args.split == "random":
        print("HOLDOUT 결과  비교 피처3탄 (50:50 보정 없음): 초기 64,142,637 / 최적 63,142,976 / 하한 62,515,326")
    else:
        print("그룹 평가(홀수 주) 결과  비교 피처3탄: 50:50 최적 95,409,747 / 75:25 최적 95,178,531")
    print(table.to_string(index=False))


if __name__ == "__main__":
    main()
