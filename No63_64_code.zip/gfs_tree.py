"""검증: 트리(feat_site, No.53) + GFS 피처 63개 -> 점수 비교.
위치: codes/gfs_tree.py
실행: python codes/gfs_tree.py       (CPU, 1시간 안팎. 다시 실행하면 저장된 트리 예측을 불러옴)
필요: output/external/gfs_features.parquet (gfs_features.py 결과)
      output/feat_site/random/ (기존 트리), output/sleeping_ranking_50/ (명준 MLP),
      output/site_tabpfn/random_big/tabpfn_eval_pred.parquet (TabPFN 큰 설정)
결과: output/feat_gfs/random/{l1_cap_smpk,cat_l1_cap_smpk}_eval_pred.parquet, result.csv

비교 (모두 시간별 배율, 비율은 group_opt_optimized 로 고르기, holdout 은 확인용)
  - 트리만 (LGBM 75 : Cat 25): 기존 vs GFS
  - 트리 20 : MLP 30 : TabPFN 50: 기존 (= No.60 56,886,019) vs GFS 트리
  - GFS 트리로 비율 다시 찾기: TabPFN 0~40, MLP 10~30, 나머지 트리 (트리 30 이상)
학습·검증 날짜, 손실, 가중치, 하이퍼파라미터는 No.53 과 같음. 피처만 GFS 63개 추가.
"""
import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs
import mix_all as mx

ROOT = val.DEFAULT_ROOT
opt.log = lambda message: None
GFS_PATH = ROOT / "output" / "external" / "gfs_features.parquet"
TAB_BIG = ROOT / "output" / "site_tabpfn" / "random_big" / "tabpfn_eval_pred.parquet"
FOLDER = ROOT / "output" / "feat_gfs" / "random"
WA = 0.75


def load_gfs(like_ts):
    g = pd.read_parquet(GFS_PATH)
    if getattr(like_ts.dt, "tz", None) is not None:
        g["ts"] = g["ts"].dt.tz_localize(like_ts.dt.tz)
    return g


def score(pred, sites, group_actual, hold_actual):
    """시간별 배율 -> 그리디 -> holdout 점수"""
    Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
    Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
    wg = opt.time_weights(ROOT, tg)
    c_hour = {}
    for h in range(24):
        idx = (tg.hour == h)
        if idx.sum() == 0:
            c_hour[h] = 1.0
        else:
            c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])
    cg = np.array([c_hour[h] for h in tg.hour])[:, None]
    ch = np.array([c_hour[h] for h in th.hour])[:, None]
    init_mask = opt.initial_mask(sites)
    optimized, meta, trace = opt.greedy_best_improvement(cg * Pg - Yg, wg, sites, init_mask)
    sg = val.score_group(opt, ROOT, cg * Pg - Yg, tg, init_mask, optimized)
    sh = val.score_group(opt, ROOT, ch * Ph - Yh, th, init_mask, optimized)
    pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
    pred_h["pred_kwh"] = pred_h["pred_kwh"] * pred_h["ts"].dt.hour.map(c_hour)
    m_h = val.model_metrics(ROOT, hold_actual, pred_h)
    return {"weighted_MAE": round(m_h["weighted_MAE_kwh"], 5),
            "group_opt_optimized": round(sg["W_optimized_krw"]),
            "initial": round(sh["W_initial_krw"]),
            "optimized": round(sh["W_optimized_krw"]),
            "lower_bound": round(sh["W_lower_bound_krw"])}


def tree_of(folder):
    pa = pd.read_parquet(folder / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(folder / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    d = both[["site_id", "ts"]].copy()
    d["tree"] = WA * both["pred_kwh_a"] + (1 - WA) * both["pred_kwh_b"]
    return d


def main():
    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_gfstree")
    FOLDER.mkdir(parents=True, exist_ok=True)

    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]
    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    model_fit, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    model_fit = pd.concat([gen[gen["ts"] < base.TRAIN_FROM], model_fit], ignore_index=True)
    eval_actual = pd.concat([group_actual, hold_actual], ignore_index=True)
    del gen, baseline_gen

    gfs = load_gfs(model_fit["ts"])
    gfs_cols = [c for c in gfs.columns if c != "ts"]
    print("GFS 피처:", len(gfs_cols), "개 /", len(gfs), "시각")

    # ---------- 1. 트리 학습 (feat_site 와 같은데 GFS 피처만 추가) ----------
    new_feats = []
    for c in fs.A_COLS + fs.B_COLS:
        new_feats = new_feats + [c + "_prev", c + "_next", c + "_daymean"]
    new_feats.append("cloud_diff")
    new_feats = new_feats + fs.NAT_FEATS + fs.F3_FEATS + fs.SITE_FEATS + gfs_cols
    base.FEATS = list(base.FEATS) + new_feats
    print("피처 수:", len(base.FEATS), "(기존 72 + GFS", len(gfs_cols), ")")

    site_table = fs.build_site_table(model_fit, eval_actual, sites, base)
    original_features = base.features

    def features_plus(*a, **k):
        d = original_features(*a, **k)
        d["cloud_diff"] = d["wa_cloud"] - d["wb_cloud"]
        n = len(d)
        d = d.merge(site_table, on=["site_id", "ts"], how="left")
        d = d.merge(gfs, on="ts", how="left")
        if len(d) != n:
            raise ValueError("피처 붙이다가 행 수가 바뀜")
        d["site_num"] = d["site_id"].str[2:].astype(int)
        return d

    base.features = features_plus
    fs.get_predictions(fs.MODEL_A, base, sites, model_fit, eval_actual, FOLDER)
    fs.get_predictions(fs.MODEL_B, base, sites, model_fit, eval_actual, FOLDER)
    del model_fit

    # ---------- 2. 섞기 비교 ----------
    old = tree_of(mx.OURS).rename(columns={"tree": "tree_old"})
    new = tree_of(FOLDER).rename(columns={"tree": "tree_gfs"})
    d = old.merge(new, on=["site_id", "ts"])
    tab = pd.read_parquet(TAB_BIG).rename(columns={"pred_kwh": "tab"})
    tab["ts"] = val.to_kst(tab["ts"])
    d = d.merge(tab, on=["site_id", "ts"], how="left")
    d = d.merge(mx.load_mlp(), on=["site_id", "ts"], how="left")
    d["tab"] = d["tab"].fillna(d["tree_old"])
    d["mlp"] = d["mlp_kwh"].fillna(d["tree_old"])
    night = d["tree_old"] <= 0
    d.loc[night, ["tab", "mlp", "tree_gfs"]] = 0.0

    cands = [("기존 트리만", "tree_old", 1.0, 0.0, 0.0),
             ("GFS 트리만", "tree_gfs", 1.0, 0.0, 0.0),
             ("기존 트리 20 : MLP 30 : TabPFN 50 (No.60)", "tree_old", 0.2, 0.3, 0.5)]
    for w_tab in [0.0, 0.1, 0.2, 0.3, 0.4]:
        for w_mlp in [0.1, 0.2, 0.3]:
            w_tree = round(1 - w_tab - w_mlp, 2)
            if w_tree < 0.3:
                continue
            label = ("GFS 트리 " + str(int(w_tree * 100)) + " : MLP " + str(int(w_mlp * 100))
                     + " : TabPFN " + str(int(w_tab * 100)))
            cands.append((label, "tree_gfs", w_tree, w_mlp, w_tab))

    rows = []
    for label, tcol, w_tree, w_mlp, w_tab in cands:
        pred = d[["site_id", "ts"]].copy()
        pred["pred_kwh"] = w_tree * d[tcol] + w_mlp * d["mlp"] + w_tab * d["tab"]
        r = {"blend": label, **score(pred, sites, group_actual, hold_actual)}
        rows.append(r)
        print(label, "| 최적", f"{r['optimized']:,}", "| group_opt", f"{r['group_opt_optimized']:,}")

    table = pd.DataFrame(rows)
    table.to_csv(FOLDER / "result.csv", index=False)
    gfs_rows = table[table["blend"].str.startswith("GFS 트리 ")]
    best = gfs_rows.loc[gfs_rows["group_opt_optimized"].idxmin()]
    print("=" * 70)
    print("비교 기준 No.60 (기존 트리 20 : MLP 30 : TabPFN 50) holdout 56,886,019")
    print(table.to_string(index=False))
    print("-" * 70)
    print("GFS 섞기 중 group_opt 기준 최선:", best["blend"], "-> holdout 최적", f"{best['optimized']:,}")


if __name__ == "__main__":
    main()
