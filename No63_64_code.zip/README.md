# No.63 · 64 — GFS 일사량 예보 추가 (세준)

`codes` 폴더에 넣고 데이터 폴더(baseline.py 있는 곳)에서 실행.
기존 파일 필요: `baseline_validation.py`, `baseline_optimizer.py`, `validation_timesplit.py`, `feat_site.py`, `mix_all.py`

## 1. GFS 받기 (한 번만)
```
pip install herbie-data eccodes
python codes\gfs_download.py --start 2025-06-01 --end 2026-06-01 --workers 8    # 평가 기간 먼저
python codes\gfs_download.py --start 2021-01-19 --end 2026-06-01 --workers 8    # 학습 기간 (밤새, 받은 날은 건너뜀)
python codes\check_gfs_time.py                                                  # 공개 시각 확인
```
- NOAA GFS 0.25도, AWS 공개 저장소 `noaa-gfs-bdp-pds` (무료, 상업 이용 가능, 같은 주소에서 다시 받기 가능, 인증키 없음)
- 대상일 D 는 **D-1 00 UTC(= D-1 09시 KST) 실행분**의 16~39시간 뒤 예보 = D 01~24시 KST
- 지표 일사량 DSWRF (6시간 누적 평균 -> 1시간 평균으로 변환), 한국 상자(위도 33~39, 경도 124~131.5)만 저장
- 결과: `output/external/gfs/YYYYMMDD.npz`, `download_log.csv` (받은 주소 + 파일 공개 시각)
- 공개 시각 확인(`publish_check.csv`): 1,920일 전부 D-1 17:00 KST 전 공개, 평가 기간 최소 2.3시간 / 보통 4.2시간 여유 (보통 D-1 12:45 KST 공개)
- 빠진 날: 2021-01-19 ~ 02-26 (AWS 에 자료 없음), 2022-12-01 (원본 파일 문제) -> 피처 빈 값
- 윈도우: eccodes 가 스레드 동시 실행에서 죽어서 프로세스로 동시 실행

## 2. 피처 만들기
```
python codes\gfs_features.py
```
-> `output/external/gfs_features.parquet` (ts + 63개). **모든 발전소에 같은 값** (규칙 7: 좌표로 격자 고르기 안 함)
- 상자 전체 평균 / 표준편차 / 최대 (3)
- 미리 정한 1도 x 1도 칸 평균 48개 (발전소 위치와 무관한 고정 칸)
- 격자 전체 PCA 8개 (학습 기간 2025-06 이전 낮 시간으로만 맞춤)
- 전국 평균의 1시간 전/후, 그날 합계, 그날 최대 (4)

## 3. 검증 (63, 64번)
```
python codes\gfs_tree.py
```
- 63번: No.53 트리(피처 72개, LGBM 75 : Cat 25, L1, 용량·SMP·k 가중치)에 GFS 63개만 추가 -> 135개. 학습·검증 날짜 No.2 와 같음
- 64번: 63번 트리 + MLP(No.54, 명준) + 발전소별 TabPFN(No.60 큰 설정). 비율은 group_opt 기준으로 고름 -> 트리 60 : MLP 20 : TabPFN 20
- 결과: `output/feat_gfs/random/result.csv`

| | Weighted MAE | Initial | Optimized | Lower Bound |
|---|---|---|---|---|
| 63 | 7.84639 | 55,484,560 | 54,851,709 | 54,058,013 |
| 64 | 7.78671 | 54,055,170 | 53,310,798 | 52,515,659 |

참고: 64번을 제출 코드(make_submission)로 계산하면 53,347,718.
MLP·TabPFN 예측이 빈 칸을 gfs_tree 는 기존 트리로, make_submission 은 GFS 트리로 채워서 조금 다름. 제출 기준 값은 53,347,718.

## 4. 제출물
```
python codes\test_tree.py --gfs                                                    # GFS 트리 전체 재학습 -> test_tree_gfs.parquet
python codes\make_submission.py --name submit_gfs --tree gfs --w 0.6 0.2 0.2       # + test_mlp, test_tabpfn (No.60 과 같은 파일)
```
-> `output/submit_final/submit_gfs/composition.csv`, `forecast.csv`

TabPFN: TabPFN-2 (Apache 2.0, "Built with PriorLabs-TabPFN")
