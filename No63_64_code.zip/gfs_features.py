"""GFS 일사량 -> 시간별 피처 표 (모든 발전소에 같은 값).
위치: codes/gfs_features.py
실행: python codes/gfs_features.py        (몇 분)
입력: output/external/gfs/YYYYMMDD.npz      (gfs_download.py 결과)
결과: output/external/gfs_features.parquet  (ts + 피처 63개)

규칙 7 (외부 기상은 모든 발전소에 같은 값, 좌표로 격자 고르기 금지) 지키는 방법
  - 한국 상자(위도 33~39, 경도 124~131.5) 전체 요약: 평균, 표준편차, 최대
  - 미리 정한 1도 x 1도 칸 48개 평균 (발전소 위치와 상관없이 고정된 칸)
  - 격자 전체 PCA 8개 (학습 기간 2025-06 이전 낮 시간으로만 맞춤)
  - 전국 평균의 1시간 전/후, 그날 합계, 그날 최대
  어느 칸이 중요한지는 모델이 학습 (발전소 좌표로 칸을 고르지 않음)

시각: npz 의 i번째(0~23) = 대상일 D 의 (i+1)시 KST, 즉 ts = D + (i+1)시간 (우측 닫힘, ts 13:00 = 12~13시)
"""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

ROOT = Path(__file__).resolve().parent.parent
GFS = ROOT / "output" / "external" / "gfs"
OUT = ROOT / "output" / "external" / "gfs_features.parquet"
EVAL_START = pd.Timestamp("2025-06-01 01:00")
N_PCA = 8


def main():
    files = sorted(GFS.glob("*.npz"))
    print("GFS 파일:", len(files), "일")

    # 1. 전부 읽어서 (시간, 위도, 경도) 로 쌓기
    cubes = []
    ts_list = []
    lats = None
    lons = None
    for p in files:
        z = np.load(p)
        day = pd.Timestamp(p.stem)
        cubes.append(z["dswrf"])
        for i in range(24):
            ts_list.append(day + pd.Timedelta(hours=i + 1))
        if lats is None:
            lats = z["lats"]
            lons = z["lons"]
    cube = np.concatenate(cubes, axis=0).astype("float32")
    ts = pd.DatetimeIndex(ts_list)
    n_t, n_lat, n_lon = cube.shape
    print("모양:", cube.shape)

    feats = pd.DataFrame({"ts": ts})

    # 2. 상자 전체 요약
    flat = cube.reshape(n_t, n_lat * n_lon)
    feats["gfs_mean"] = flat.mean(axis=1)
    feats["gfs_std"] = flat.std(axis=1)
    feats["gfs_max"] = flat.max(axis=1)

    # 3. 고정 1도 칸 (위도 33~38 6줄 x 경도 124~131 8칸 = 48개)
    lat_bin = np.clip(np.floor(lats).astype(int), 33, 38)
    lon_bin = np.clip(np.floor(lons).astype(int), 124, 131)
    for la in range(33, 39):
        for lo in range(124, 132):
            rows = np.where(lat_bin == la)[0]
            cols = np.where(lon_bin == lo)[0]
            part = cube[:, rows][:, :, cols]
            feats["gfs_t" + str(la) + "_" + str(lo)] = part.reshape(n_t, -1).mean(axis=1)

    # 4. PCA (학습 기간 낮 시간으로만 맞춤)
    fit_rows = (ts < EVAL_START) & (feats["gfs_mean"].to_numpy() > 1)
    pca = PCA(n_components=N_PCA, random_state=42)
    pca.fit(flat[fit_rows])
    print("PCA 설명 비율:", np.round(pca.explained_variance_ratio_, 3).tolist())
    comp = pca.transform(flat)
    for k in range(N_PCA):
        feats["gfs_pc" + str(k + 1)] = comp[:, k]

    # 5. 전국 평균의 시간 모양 (같은 날 안에서만)
    feats["_day"] = (feats["ts"] - pd.Timedelta(hours=1)).dt.normalize()
    g = feats.groupby("_day")["gfs_mean"]
    feats["gfs_mean_prev"] = g.shift(1)
    feats["gfs_mean_next"] = g.shift(-1)       # 24시의 다음 값은 그날 파일에 없음 -> 자동으로 빈 값
    feats["gfs_mean_daysum"] = g.transform("sum")
    feats["gfs_mean_daymax"] = g.transform("max")
    feats = feats.drop(columns="_day")

    feats.to_parquet(OUT, index=False)
    print("저장:", OUT, len(feats), "행 /", feats.shape[1] - 1, "피처")
    print("기간:", feats["ts"].min(), "~", feats["ts"].max())
    noon = feats[feats["ts"].dt.hour == 13]
    print("13시 전국 평균 (W/m2) 월별:", noon.groupby(noon["ts"].dt.month)["gfs_mean"].mean().round(0).to_dict())


if __name__ == "__main__":
    main()
