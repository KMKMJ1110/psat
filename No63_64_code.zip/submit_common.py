"""제출용 공통 함수 (test_tree / test_mlp / test_tabpfn / make_submission 이 같이 씀).
위치: codes/submit_common.py
"""
import numpy as np
import pandas as pd

import baseline_validation as val
import feat_site as fs

ROOT = val.DEFAULT_ROOT
OUT = ROOT / "output" / "submit_final"


def load_sites():
    return pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]


def load_gen_all():
    """학습 기간 발전량 전부 (2021-01 ~ 2025-05)"""
    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    gen["energy"] = gen["energy"].clip(lower=0)
    return gen


def test_index():
    """제출 시각 8,760개 (smp.csv 기준)"""
    smp = pd.read_csv(ROOT / "smp.csv")
    return pd.DatetimeIndex(val.to_kst(smp["ts"]))


def test_grid(sites):
    """발전소 253개 x 제출 시각 (energy 는 없음)"""
    idx = test_index()
    g = pd.MultiIndex.from_product([sites["site_id"], idx], names=["site_id", "ts"]).to_frame(index=False)
    g["energy"] = np.nan
    return g


def load_weather_train(base, start):
    return val.load_weather(ROOT, base, start)


def load_weather_test(base):
    folder = ROOT / "output" / "preprocessed" / "test"
    a = pd.read_parquet(folder / "forecast_wa.parquet", columns=["wa_station", "round", "ts"] + list(base.WA_COLS))
    b = pd.read_parquet(folder / "forecast_wb.parquet", columns=["wb_station", "round", "ts"] + list(base.WB_COLS))
    a["ts"] = val.to_kst(a["ts"])
    b["ts"] = val.to_kst(b["ts"])
    print("평가 기간 예보 A", len(a), "/ B", len(b))
    return a, b


def weather_pipeline(fa, fb):
    """feat_site 와 같은 날씨 피처 (앞뒤 1시간·하루 평균, 24시 다음값 비움, 전국, 구름 패턴)"""
    fa, _ = fs.add_time_feats(fa, "wa_station", fs.A_COLS)
    fb, _ = fs.add_time_feats(fb, "wb_station", fs.B_COLS)
    fa = fs.drop_next_at_midnight(fa, fs.A_COLS)
    fb = fs.drop_next_at_midnight(fb, fs.B_COLS)
    fa, fb = fs.add_national(fa, fb)
    fa = fs.add_feat3(fa, "wa_station", "wa_cloud")
    fb = fs.add_feat3(fb, "wb_station", "wb_cloud")
    return fa, fb


def weather_feats():
    """feat_site 의 날씨 피처 이름 (발전소 피처 제외)"""
    new_feats = []
    for c in fs.A_COLS + fs.B_COLS:
        new_feats = new_feats + [c + "_prev", c + "_next", c + "_daymean"]
    new_feats.append("cloud_diff")
    return new_feats + fs.NAT_FEATS + fs.F3_FEATS
