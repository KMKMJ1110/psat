"""외부 예보: NOAA GFS 지표 일사량(DSWRF) 받기 -> 한국 영역만 잘라 저장.
위치: codes/gfs_download.py
설치: pip install herbie-data eccodes
실행:
  python codes/gfs_download.py --start 2024-06-01 --end 2024-06-03      # 시험 (3일)
  python codes/gfs_download.py --start 2021-01-19 --end 2026-06-01      # 전체 (밤새)
  중간에 꺼져도 다시 실행하면 받은 날은 건너뜀
결과: output/external/gfs/YYYYMMDD.npz   (대상일 하루, 01~24시 KST 시간 평균 일사량 W/m2, 한국 격자)
      output/external/gfs/download_log.csv  (받은 주소, 파일 올라온 시각 = 공개 시각 근거)

규칙 확인
  - 데이터: NOAA GFS 0.25도, AWS 공개 저장소 noaa-gfs-bdp-pds (누구나 같은 주소에서 받음, 상업 이용 가능)
  - 예측시점(전날 17:00 KST) 전에 나온 예보만: 대상일 D 는 전날(D-1) 00시 UTC 실행분(= D-1 09시 KST 실행,
    보통 D-1 오후 1~2시 KST 공개) 의 16~39시간 뒤 예보를 씀  -> 16시간 뒤 = D 01:00 KST, 39시간 뒤 = D 24:00 KST
  - 좌표는 격자(약 25km) 칸 고르기에만 씀 (발전소 위치를 특정하지 않음)

GFS 일사량은 '6시간 구간 시작부터 지금까지 평균' 으로 저장돼 있어서 1시간 평균으로 바꿔 씀:
  1시간 평균(n) = (n - b) x 평균(b~n) - (n - 1 - b) x 평균(b~n-1),  b = 그 6시간 구간 시작
"""
import argparse
import csv
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "output" / "external" / "gfs"
TMP = OUT / "_tmp"
LAT_MIN, LAT_MAX = 33.0, 39.0          # 한국 영역 (여유 포함)
LON_MIN, LON_MAX = 124.0, 131.5
LEADS = list(range(13, 40))            # 16~39 를 1시간 평균으로 바꾸려면 13부터 필요
SEARCH = ":DSWRF:surface:"


def one_lead(run, n):
    """한 실행분의 n 시간 뒤 DSWRF -> (2차원 배열, 위도, 경도, 주소, 공개시각)"""
    from herbie import Herbie
    import requests
    H = Herbie(run, model="gfs", product="pgrb2.0p25", fxx=n, priority=["aws"],
               save_dir=TMP, verbose=False)
    ds = H.xarray(SEARCH, remove_grib=True)
    if isinstance(ds, list):
        ds = ds[0]
    var = list(ds.data_vars)[0]
    da = ds[var].sel(latitude=slice(LAT_MAX, LAT_MIN), longitude=slice(LON_MIN, LON_MAX))
    arr = da.values.astype("float32")
    lats = da["latitude"].values
    lons = da["longitude"].values
    last_mod = ""
    try:
        last_mod = requests.head(str(H.grib), timeout=30).headers.get("Last-Modified", "")
    except Exception:
        pass
    return arr, lats, lons, str(H.grib), last_mod


def one_day(target_day):
    """대상일 D (KST) 하루치: D-1 00시 UTC 실행분 사용"""
    path = OUT / (target_day.strftime("%Y%m%d") + ".npz")
    if path.exists():
        return None
    run = (target_day - pd.Timedelta(days=1)).strftime("%Y-%m-%d 00:00")
    avg = {}
    info = None
    for n in LEADS:
        for attempt in range(3):
            try:
                arr, lats, lons, url, last_mod = one_lead(run, n)
                avg[n] = arr
                if n == 39:
                    info = (url, last_mod)
                break
            except Exception as e:
                if attempt == 2:
                    return (target_day.strftime("%Y-%m-%d"), run, "실패 fxx=" + str(n) + " " + str(e)[:80], "")
                time.sleep(5)

    hourly = []
    for n in range(16, 40):
        b = 6 * ((n - 1) // 6)
        if n - 1 > b:
            h = (n - b) * avg[n] - (n - 1 - b) * avg[n - 1]
        else:
            h = avg[n]
        hourly.append(np.maximum(h, 0))
    np.savez_compressed(path, dswrf=np.stack(hourly).astype("float32"), lats=lats, lons=lons, run=run)
    return (target_day.strftime("%Y-%m-%d"), run, info[0], info[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", required=True, help="대상일 시작 (KST), 예 2021-01-19")
    ap.add_argument("--end", required=True, help="대상일 끝 (KST), 예 2026-06-01")
    ap.add_argument("--workers", type=int, default=6)
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    TMP.mkdir(parents=True, exist_ok=True)

    days = pd.date_range(args.start, args.end, freq="D")
    todo = [d for d in days if not (OUT / (d.strftime("%Y%m%d") + ".npz")).exists()]
    print("대상일", len(days), "일 / 남은 날", len(todo), "일")
    log_path = OUT / "download_log.csv"
    new_file = not log_path.exists()
    started = time.time()
    done = 0
    with open(log_path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(["target_day_kst", "gfs_run_utc", "source_url_f039", "last_modified"])
        with ProcessPoolExecutor(max_workers=args.workers) as ex:
            for res in ex.map(one_day, todo):
                done += 1
                if res is not None:
                    w.writerow(res)
                    f.flush()
                    if "실패" in str(res[2]):
                        print("  !!", res[0], res[2])
                if done % 10 == 0 or done == len(todo):
                    spent = (time.time() - started) / 60
                    print(f"{done}/{len(todo)}일 완료 / {spent:.1f}분 / 남은 예상 {spent / done * (len(todo) - done):.0f}분")

    # 시험용 확인 출력
    files = sorted(OUT.glob("*.npz"))
    if files:
        z = np.load(files[-1])
        print("확인:", files[-1].name, "모양(시간, 위도, 경도) =", z["dswrf"].shape,
              "/ 낮 최대 W/m2 =", round(float(z["dswrf"].max()), 1),
              "/ 시간별 한국 평균 =", np.round(z["dswrf"].mean(axis=(1, 2)), 0).tolist())


if __name__ == "__main__":
    main()
