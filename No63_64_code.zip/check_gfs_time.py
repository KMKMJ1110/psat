"""GFS 공개 시각 확인: 쓴 예보 파일이 전부 '전날 17:00 KST' 전에 올라왔는지 (규칙 6).
위치: codes/check_gfs_time.py
실행: python codes/check_gfs_time.py
입력: output/external/gfs/download_log.csv  (gfs_download.py 가 남긴 받은 주소 + 파일 올라온 시각)
결과: output/external/gfs/publish_check.csv  (날짜별 공개 시각, 마감까지 남은 시간)

대상일 D 의 마감 = D-1 17:00 KST = D-1 08:00 UTC
확인하는 파일 = 그날 쓴 것 중 가장 늦게 나오는 f039 (39시간 뒤 예보)
"""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
GFS = ROOT / "output" / "external" / "gfs"


def main():
    log = pd.read_csv(GFS / "download_log.csv")
    log = log[log["last_modified"].notna() & (log["last_modified"].astype(str).str.len() > 5)].copy()
    log = log.drop_duplicates("target_day_kst", keep="last")
    log["target_day"] = pd.to_datetime(log["target_day_kst"])
    log["published_utc"] = pd.to_datetime(log["last_modified"], format="%a, %d %b %Y %H:%M:%S GMT")
    log["deadline_utc"] = log["target_day"] - pd.Timedelta(days=1) + pd.Timedelta(hours=8)
    log["published_kst"] = log["published_utc"] + pd.Timedelta(hours=9)
    log["margin_h"] = (log["deadline_utc"] - log["published_utc"]).dt.total_seconds() / 3600
    log["ok"] = log["margin_h"] > 0

    evalp = log[log["target_day"] >= "2025-06-01"]
    for name, part in [("평가 기간 (2025-06 ~ 2026-06)", evalp), ("전체", log)]:
        print(name, ":", len(part), "일 / 마감 전 공개", int(part["ok"].sum()), "일 / 마감 후",
              int((~part["ok"]).sum()), "일")
        if len(part):
            print("   마감까지 남은 시간(시간): 최소", round(part["margin_h"].min(), 1),
                  "/ 중앙값", round(part["margin_h"].median(), 1))
            print("   공개 시각(KST) 예:", part["published_kst"].iloc[-1], "-> 대상일", part["target_day_kst"].iloc[-1])

    late = log[~log["ok"]]
    if len(late):
        print("\n마감 후 공개된 날 (앞 20개):")
        print(late[["target_day_kst", "gfs_run_utc", "published_kst", "margin_h"]].head(20).to_string(index=False))
    log[["target_day_kst", "gfs_run_utc", "source_url_f039", "published_kst", "margin_h", "ok"]].to_csv(
        GFS / "publish_check.csv", index=False)
    print("\n저장:", GFS / "publish_check.csv")


if __name__ == "__main__":
    main()
