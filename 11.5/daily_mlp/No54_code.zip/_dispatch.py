"""Entry point and resumable evaluation for 1..20 one-factor OIBC experiments."""
from __future__ import annotations
import argparse
import json
import traceback
import shutil
from pathlib import Path
import pandas as pd
from _core import Workspace,prepare_baseline,read_sites,load_labeled_frames,evaluate,log
from _optimizer import atomic_json

VARIANT_NAMES={
 1:'group_sign_logistic',2:'sign_ridge_moe',3:'logistic_correction_gate',
 4:'oof_w_simplex',5:'privileged_weather_teacher_student',6:'dynamic_model_selection',
 7:'panel_orientation_proxy',8:'five_state_error_classifier',9:'hourly_solar_integral',
 10:'weather_bayesian_averaging',11:'film_site_conditioning',12:'robust_target_downweight',
 13:'beta_calibrated_sign',14:'weather_conditional_residual',15:'weather_group_dro',
 16:'site_temperature_coefficient',17:'tide_day_curve',18:'weather_set_transformer',
 19:'rh_cloud_kernel_residual',20:'daytime_hurdle'
}


def _calculate(rank,ws,opt,hold,sites):
    if rank in (11,17,18):
        import _neural
        method=getattr(_neural,f'rank_{rank}')
    else:
        import _variants
        method=getattr(_variants,f'rank_{rank}')
    result=method(ws,opt,hold,sites)
    if not isinstance(result,tuple) or len(result)!=3:
        raise ValueError('Candidate method must return (opt_pred, hold_pred, manifest)')
    po,ph,metadata=result
    if len(po)!=len(opt) or len(ph)!=len(hold):
        raise ValueError('Candidate prediction length mismatch')
    opt['pred_kwh']=po;hold['pred_kwh']=ph
    if opt.pred_kwh.isna().any() or hold.pred_kwh.isna().any():raise ValueError('NaN candidate prediction')
    return opt,hold,metadata


def main(rank):
    if rank not in VARIANT_NAMES:raise ValueError('Unsupported rank')
    base_dir=Path(__file__).resolve().parent
    default_root=next((p for p in (base_dir.parent, base_dir.parent.parent) if (p/'sites.csv').is_file()), base_dir.parent)
    ap=argparse.ArgumentParser(description=f'OIBC new candidate rank {rank}: {VARIANT_NAMES[rank]}')
    ap.add_argument('--data-dir',type=Path,default=default_root,help='OIBC data/ directory (NOT codes/)')
    ap.add_argument('--output-dir',type=Path,default=None,help='Base output folder; default data/output/sleeping_ranking_50')
    ap.add_argument('--force',action='store_true',help='Delete only current candidate output, then start over (shared baseline retained)')
    ap.add_argument('--max-neural-train',type=int,default=160000)
    ap.add_argument('--max-residual-train',type=int,default=160000)
    ap.add_argument('--neural-epochs',type=int,default=8)
    ap.add_argument('--greedy-max-iter',type=int,default=0,help='0: until no further improvement')
    ap.add_argument('--greedy-batch',type=int,default=128)
    args=ap.parse_args()
    root=args.data_dir.expanduser().resolve()
    if not (root/'sites.csv').is_file():ap.error(f'Cannot find data root sites.csv: {root}')
    if args.max_neural_train<10 or args.max_residual_train<100:ap.error('Training caps too small')
    outbase=args.output_dir.expanduser().resolve() if args.output_dir else root/'output'/'sleeping_ranking_50'
    folder=f'new_cand_{rank}_{VARIANT_NAMES[rank]}'
    dest=outbase/folder
    if args.force and dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True,exist_ok=True)
    shared=outbase/'_baseline_cache'
    ws=Workspace(root=root,out=dest,shared=shared,rank=rank,resume=not args.force,
        max_neural_train=args.max_neural_train,neural_epochs=args.neural_epochs,
        max_residual_train=args.max_residual_train,greedy_max_iter=args.greedy_max_iter,greedy_batch=args.greedy_batch)
    meta=dest/'summary.json'
    if meta.exists():
        info=json.loads(meta.read_text())
        print(f'[RANK {rank}] Completed run already saved. Resume skips it: {meta}\n'
              f'Weighted MAE={info["weighted_MAE_kwh"]:.5f}\n'
              f'Initial W={info["initial_penalty_W_krw"]:,.2f}\n'
              f'Optimized W={info["optimized_penalty_W_krw"]:,.2f}\n'
              f'Theoretical LB={info["theoretical_lower_bound_W_krw"]:,.2f}',flush=True)
        return
    atomic_json(dest/'run_config.json',vars(args)|{'rank':rank,'variant':VARIANT_NAMES[rank],
        'data_root':str(root),'folder':str(dest),'python_file':f'new_cand_{rank}_{VARIANT_NAMES[rank]}.py'})
    try:
        prepare_baseline(root,shared)
        sites,fit,opt,hold=load_labeled_frames(ws)
        del fit # data reloaded within training variants only
        ck_opt=dest/'candidate_group_opt_predictions.parquet'
        ck_hold=dest/'candidate_holdout_predictions.parquet'
        if ck_opt.exists() and ck_hold.exists():
            log('Resume candidate predictions checkpoint; skip model fitting')
            part_opt=pd.read_parquet(ck_opt)
            part_hold=pd.read_parquet(ck_hold)
            opt=opt.drop(columns='pred_kwh').merge(part_opt,on=['site_id','ts'],how='left',validate='one_to_one')
            hold=hold.drop(columns='pred_kwh').merge(part_hold,on=['site_id','ts'],how='left',validate='one_to_one')
            manifest=json.loads((dest/'method_manifest.json').read_text())
        else:
            opt,hold,manifest=_calculate(rank,ws,opt,hold,sites)
            opt[['site_id','ts','pred_kwh']].to_parquet(ck_opt,index=False)
            hold[['site_id','ts','pred_kwh']].to_parquet(ck_hold,index=False)
            atomic_json(dest/'method_manifest.json',manifest)
            log(f'Rank {rank} prediction checkpoint saved; resume may skip model fitting')
        evaluate(ws,sites,opt,hold,manifest)
    except Exception as e:
        atomic_json(dest/'last_failure.json',{'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),
            'help':'Fix dependencies/input data and re-run same command to resume checkpoints.'})
        raise

