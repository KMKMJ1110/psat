#!/usr/bin/env python3
"""Consolidate ONLY finished holdout summaries, sorted by achieved Optimized W."""
import argparse
import json
from pathlib import Path
import pandas as pd

def main():
    base_dir=Path(__file__).resolve().parent
    default_root=next((p for p in (base_dir.parent, base_dir.parent.parent) if (p/'sites.csv').is_file()), base_dir.parent)
    parser=argparse.ArgumentParser();parser.add_argument('--data-dir',type=Path,default=default_root);args=parser.parse_args()
    root=args.data_dir.expanduser().resolve();folder=root/'output'/'sleeping_ranking_50'; folder.mkdir(parents=True,exist_ok=True)
    rows=[]
    for f in sorted(folder.glob('new_cand_*_*/summary.json')):
        d=json.loads(f.read_text())
        rows.append({'Rank':d['rank'],'Variant':f.parent.name,'Weighted MAE':d['weighted_MAE_kwh'],
             'Initial Penalty W':d['initial_penalty_W_krw'],'Optimized Penalty W':d['optimized_penalty_W_krw'],
             'Theoretical Lower Bound':d['theoretical_lower_bound_W_krw'],'Improvable Cost':d['improvable_cost_W_krw'],
             'Independent Holdout Hours':d['holdout_hours'],'Output':str(f.parent)})
    cols=['Rank','Variant','Weighted MAE','Initial Penalty W','Optimized Penalty W','Theoretical Lower Bound','Improvable Cost','Independent Holdout Hours','Output']
    frame=pd.DataFrame(rows,columns=cols)
    if len(frame):frame=frame.sort_values('Optimized Penalty W').reset_index(drop=True)
    frame.to_csv(folder/'ranking_results.csv',index=False)
    print(f'Wrote {folder/"ranking_results.csv"}, completed={len(frame)}')
    if len(frame):print(frame[cols[:-1]].to_string(index=False))

if __name__=='__main__':main()
