Rank 17 (C1) experiment files for the OIBC data/codes/ directory.

Extract THIS zip directly into your existing data/codes/ directory.
The Python files should end up in data/codes/, not data/codes/codes/.

Required existing local files (not included):
  data/sites.csv
  data/train/generation.parquet
  data/train/smp.csv
  data/output/preprocessed/train/forecast_wa.parquet
  data/output/preprocessed/train/forecast_wb.parquet
  data/baseline.py OR data/codes/baseline.py

From the data/ directory:
  python3 codes/new_cand_17_tide_day_curve.py
  python3 codes/aggregate_results.py

Other Python packages such as numpy/pandas, torch, sklearn, and project model dependencies are required.
Do not overwrite unrelated existing files with the same name without checking them.
