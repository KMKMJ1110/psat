"""Standalone, checkpointed PyTorch candidate architectures (no pretrained external weights)."""
from __future__ import annotations
import json
import gc
from pathlib import Path
import numpy as np
import pandas as pd
from _core import (log,read_generation,split_frames,read_sites,import_baseline,augmented_baseline,
                   weather_features,df_features,frame_xy,days,clip_predictions)
from _variants import _subsample,_train_retrained,_attach_prediction


def _torch():
    try:import torch;return torch
    except ImportError as e:raise RuntimeError('pip install torch to run this neural experiment') from e


def _prepare(ws):
    sites=read_sites(ws.root);gen=read_generation(ws.root);fit,op,ho,_=split_frames(gen);del gen
    bas=augmented_baseline(import_baseline(ws.root));wa,wb=weather_features(ws.root,bas)
    return sites,fit,op,ho,bas,wa,wb


def _train_torch(ws,model,X,Y,sites,ckpt,lr=.001,epoch_override=None):
    torch=_torch();import torch.nn.functional as F
    device='cpu' # predictable RAM / no MPS C++ crashes
    torch.set_num_threads(min(4,torch.get_num_threads()))
    model.to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    ck=ws.path(ckpt);start=0
    if ck.exists():
        obj=torch.load(ck,map_location='cpu',weights_only=False)
        model.load_state_dict(obj['model']);opt.load_state_dict(obj['optimizer']);start=obj['epoch']+1
        log(f'Torch resume {ckpt} epoch={start}')
    n_epochs=epoch_override or ws.neural_epochs
    ds=torch.utils.data.TensorDataset(torch.tensor(X,dtype=torch.float32),torch.tensor(Y,dtype=torch.float32),torch.tensor(sites,dtype=torch.long))
    loader=torch.utils.data.DataLoader(ds,batch_size=512,shuffle=True,num_workers=0)
    for e in range(start,n_epochs):
        model.train();losses=[]
        for xb,yb,ib in loader:
            opt.zero_grad();yp=model(xb,ib)
            loss=F.smooth_l1_loss(yp,yb,beta=.05)
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
            opt.step();losses.append(float(loss.detach()))
        torch.save({'model':model.cpu().state_dict(),'optimizer':opt.state_dict(),'epoch':e,'n_epochs':n_epochs},ck)
        log(f'Rank {ws.rank} {ckpt}: epoch {e+1}/{n_epochs} mean_smoothL1={np.mean(losses):.6f}')
    return model


def rank_11(ws,opt,hold,sites):
    """B2: FiLM conditional network trained only on fit, blended as new 40% expert."""
    torch=_torch();from torch import nn
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
    sites,fit,_,_,base,fa,fb=_prepare(ws)
    fit=_subsample(fit,ws.max_neural_train)
    train=df_features(base,fit,sites,fa,fb,17)
    train=train[train.elev>0].copy()
    fcols=list(base.FEATS)
    X,y=frame_xy(train,fcols)
    imp=SimpleImputer(strategy='median');sc=StandardScaler()
    X=sc.fit_transform(imp.fit_transform(X)).astype('float32')
    mapping={str(v):i for i,v in enumerate(sites.site_id)}
    sid=train.site_id.map(lambda z:mapping[str(z)]).to_numpy('int64')
    import joblib
    joblib.dump({'imputer':imp,'scaler':sc,'features':fcols,'site_mapping':mapping},ws.path('film_preprocessor.joblib'))
    class FiLM(nn.Module):
        def __init__(self,nf,nsite):
            super().__init__();self.encoder=nn.Sequential(nn.Linear(nf,96),nn.ReLU(),nn.Linear(96,96))
            self.emb=nn.Embedding(nsite,16)
            self.mod=nn.Linear(16,192)
            self.output=nn.Sequential(nn.ReLU(),nn.Linear(96,48),nn.ReLU(),nn.Linear(48,1))
        def forward(self,x,idx):
            h=self.encoder(x);gamma,beta=self.mod(self.emb(idx)).chunk(2,dim=1)
            return self.output(h*(1+.1*torch.tanh(gamma))+.1*beta).squeeze(1)
    model=FiLM(X.shape[1],len(mapping))
    model=_train_torch(ws,model,X,y.to_numpy(float),sid,'film_epoch.pt')
    ck=ws.path('film_final.pt');torch.save({'state':model.state_dict(),'site_mapping':mapping,'features':fcols},ck)
    del X,y,train
    out=[]
    model.eval()
    with torch.no_grad():
        for d in (opt,hold):
            feat=df_features(base,d[['site_id','ts']],sites,fa,fb,17)
            F=feat[fcols].astype('float32')
            Xt=sc.transform(imp.transform(F)).astype('float32')
            index=feat.site_id.map(lambda z:mapping[str(z)]).to_numpy('int64')
            preds=[]
            for start in range(0,len(Xt),32768):
                px=model(torch.tensor(Xt[start:start+32768]),torch.tensor(index[start:start+32768])).numpy()
                preds.append(px)
            nncf=np.clip(np.concatenate(preds),0,1.2)
            candidate=.6*d.pred_kwh.to_numpy(float)+.4*nncf*d.cap.to_numpy(float)
            out.append(clip_predictions(d,candidate))
    return out[0],out[1],{'algorithm':'B2 actual FiLM site embedding conditioned weather model','neural_blend':.4,'epochs':ws.neural_epochs}


def rank_17(ws,opt,hold,sites):
    """C1: dense day-ahead multioutput day-24 curve regressor (TiDE-inspired)."""
    torch=_torch();from torch import nn
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
    sites,fit,_,_,base,fa,fb=_prepare(ws)
    # Time vector is 01:00,...,00:00 (right-closed delivery day)
    fcols=['wa_cloud','wb_cloud','wa_temp','wb_temp','wb_uv_idx','elev','cosz','cap']
    sample=_subsample(fit,10**9)
    xtr=df_features(base,sample,sites,fa,fb,17)
    def pack(d,required_y):
        d=d.copy();d['_delivery_day']=days(d.ts)
        d=d.sort_values(['site_id','_delivery_day','ts'])
        length=d.groupby(['site_id','_delivery_day'],sort=False).ts.transform('size').eq(24)
        d=d[length]
        groups=list(d.groupby(['site_id','_delivery_day'],sort=False))
        xx=np.stack([x[fcols].to_numpy('float32').reshape(-1) for _,x in groups]) if groups else np.empty((0,24*len(fcols)),dtype='float32')
        yy=np.stack([(x.energy/x.cap).clip(0,1.2).to_numpy('float32') for _,x in groups]) if groups and required_y else np.zeros((len(groups),24),dtype='float32')
        site_ids=[str(k[0]) for k,x in groups]
        return groups,xx,yy,site_ids
    gr,X,Y,sids=pack(xtr,True)
    if len(X)<100:raise ValueError('Too few complete 24-hour day/site curves')
    if len(X)>ws.max_neural_train:
        rng=np.random.default_rng(42);ix=rng.choice(len(X),ws.max_neural_train,replace=False)
        X=X[ix];Y=Y[ix];sids=[sids[i] for i in ix]
    im=SimpleImputer(strategy='median');sc=StandardScaler()
    X=sc.fit_transform(im.fit_transform(X)).astype('float32')
    mapping={str(v):i for i,v in enumerate(sites.site_id)}
    idx=np.array([mapping[z] for z in sids],dtype='int64')
    import joblib
    joblib.dump({'imputer':im,'scaler':sc,'features':fcols,'site_mapping':mapping},ws.path('tide_preprocessor.joblib'))
    class DayDense(nn.Module):
        def __init__(self,nf,nsite):
            super().__init__();self.emb=nn.Embedding(nsite,12)
            self.mlp=nn.Sequential(nn.Linear(nf+12,256),nn.ReLU(),nn.Dropout(.1),nn.Linear(256,128),nn.ReLU(),nn.Linear(128,24))
        def forward(self,x,i):return self.mlp(torch.cat([x,self.emb(i)],dim=1))
    model=DayDense(X.shape[1],len(mapping))
    model=_train_torch(ws,model,X,Y,idx,'tide_epoch.pt')
    torch.save({'state':model.state_dict(),'model':'TiDE-inspired day vector dense encoder','features':fcols},ws.path('tide_final.pt'))
    del xtr,gr,X,Y,sids
    model.eval();outputs=[]
    with torch.no_grad():
        for d in (opt,hold):
            xte=df_features(base,d[['site_id','ts']],sites,fa,fb,17)
            gr,XX,YY,sids=pack(xte,False)
            prediction_map={}
            if len(XX):
                XX=sc.transform(im.transform(XX)).astype('float32')
                ids=np.array([mapping[z] for z in sids],dtype='int64')
                preds=[]
                for p in range(0,len(XX),4096):
                    preds.append(model(torch.tensor(XX[p:p+4096]),torch.tensor(ids[p:p+4096])).numpy())
                vals=np.vstack(preds)
                for (_,rows),row in zip(gr,vals):
                    for key,v in zip(zip(rows.site_id,rows.ts),row):prediction_map[key]=max(float(v),0.)
            learned=np.array([prediction_map.get((si,ts),np.nan) for si,ts in zip(d.site_id,d.ts)],dtype=float)
            y=np.where(np.isfinite(learned),.6*d.pred_kwh.to_numpy(float)+.4*learned*d.cap.to_numpy(float),d.pred_kwh.to_numpy(float))
            outputs.append(clip_predictions(d,y))
    return outputs[0],outputs[1],{'algorithm':'C1 TiDE-inspired 24-output dense time-series forecaster','neural_blend':.4,'note':'no historical inference-time generation is used; known day-ahead NWP only'}


def rank_18(ws,opt,hold,sites):
    """B1: supervised permutation-invariant Set Self-Attention pooling across WA weather stations."""
    torch=_torch();from torch import nn
    sites,fit,_,_,base,fa,fb=_prepare(ws)
    fcols=['wa_cloud','wa_rain','wa_humidity']
    stations=sorted(fa.wa_station.astype(str).unique())
    stationmap={x:i for i,x in enumerate(stations)}
    # Generate per-round station cloud/rain/humidity tensor of known forecast values.
    unique_times=pd.DatetimeIndex(fa.ts.drop_duplicates().sort_values())
    frames={}; tensors={}
    for r in (10,17):
        d=fa[fa['round']==r][['wa_station','ts']+fcols].copy()
        d['index']=d.wa_station.astype(str).map(stationmap).astype(int)
        tsidx=pd.Index(unique_times).get_indexer(d.ts)
        a=np.zeros((len(unique_times),len(stations),len(fcols)),dtype='float32')
        valid=np.zeros((len(unique_times),len(stations)),dtype='bool')
        x=d[fcols].to_numpy('float32')
        finite=np.isfinite(x).all(axis=1)&(tsidx>=0)
        a[tsidx[finite],d['index'].to_numpy()[finite],:]=x[finite]
        valid[tsidx[finite],d['index'].to_numpy()[finite]]=True
        a=np.nan_to_num(a,nan=0.,posinf=0.,neginf=0.)
        # Cloud, rain, humidity scaled to comparable physical magnitudes.
        a[...,0]/=100.;a[...,1]/=10.;a[...,2]/=100.
        tensors[r]=a;frames[r]=valid
    # Fit-only aggregated observed target per timestamp.
    capmap=sites.set_index('site_id').capacity_kw
    fit=fit.copy();fit['cap']=fit.site_id.map(capmap)
    target=(fit.groupby('ts').energy.sum()/fit.groupby('ts').cap.sum()).clip(0,1.2)
    idx=pd.Index(unique_times).get_indexer(target.index)
    keep=idx>=0;ind=idx[keep]; y=target.to_numpy(float)[keep]
    if len(ind)>ws.max_neural_train:
        rng=np.random.default_rng(42);sel=rng.choice(len(ind),ws.max_neural_train,replace=False);ind=ind[sel];y=y[sel]
    class AttentionSet(nn.Module):
        def __init__(self):
            super().__init__();self.inp=nn.Linear(3,32)
            self.self_att=nn.MultiheadAttention(32,4,batch_first=True)
            self.hidden=nn.Sequential(nn.LayerNorm(32),nn.Linear(32,8),nn.Tanh())
            self.out=nn.Linear(8,1)
        def features(self,x,mask):
            h=torch.relu(self.inp(x))
            h,_=self.self_att(h,h,h,key_padding_mask=~mask,need_weights=False)
            h=self.hidden(h)
            return (h*mask.unsqueeze(-1)).sum(dim=1)/mask.sum(dim=1,keepdim=True).clamp_min(1)
        def forward(self,x,mask):return self.out(self.features(x,mask)).squeeze(-1)
    model=AttentionSet();optim=torch.optim.AdamW(model.parameters(),lr=.001)
    cpath=ws.path('set_attention_epoch.pt');start=0
    if cpath.exists():
        saved=torch.load(cpath,map_location='cpu',weights_only=False);model.load_state_dict(saved['model']);optim.load_state_dict(saved['optimizer']);start=saved['epoch']+1
    torch.set_num_threads(min(4,torch.get_num_threads()))
    for epoch in range(start,ws.neural_epochs):
        perm=np.random.default_rng(42+epoch).permutation(len(ind));losses=[]
        for a in range(0,len(ind),192):
            take=ind[perm[a:a+192]];z=torch.tensor(tensors[17][take]);mask=torch.tensor(frames[17][take]);actual=torch.tensor(y[perm[a:a+192]],dtype=torch.float32)
            # Drop hours that have no available station forecasts.
            good=mask.any(dim=1)
            if not good.any():continue
            yp=model(z[good],mask[good]);loss=torch.nn.functional.smooth_l1_loss(yp,actual[good])
            optim.zero_grad();loss.backward();optim.step();losses.append(float(loss.detach()))
        torch.save({'model':model.state_dict(),'optimizer':optim.state_dict(),'epoch':epoch},cpath)
        log(f'[B1] attention epoch {epoch+1} loss {np.mean(losses):.6f}')
    torch.save({'model':model.state_dict(),'stations':stations,'weather_columns':fcols},ws.path('set_attention_final.pt'))
    embedding={}
    model.eval()
    with torch.no_grad():
        for r in (10,17):
            embs=[]
            for a in range(0,len(unique_times),512):
                x=torch.tensor(tensors[r][a:a+512]);m=torch.tensor(frames[r][a:a+512]);good=m.any(dim=1)
                feat=torch.zeros((len(x),8))
                if good.any():feat[good]=model.features(x[good],m[good])
                embs.append(feat.numpy())
            feat=np.vstack(embs)
            embedding[r]=pd.DataFrame({'ts':unique_times,**{f'weather_set_{j}':feat[:,j] for j in range(8)}}).set_index('ts')
            embedding[r].to_pickle(ws.path(f'set_attention_embeddings_r{r}.pkl'))
    def fe(d,r):
        for j in range(8):d[f'weather_set_{j}']=d.ts.map(embedding[r][f'weather_set_{j}']).astype('float32')
        return d
    res=_train_retrained(ws,'set_attention',fe,feature_cols=[f'weather_set_{j}' for j in range(8)])
    pp,hh=_attach_prediction(opt,hold,res)
    return pp,hh,{'algorithm':'B1 supervised self-attention weather-station set representation -> 8 new features','n_stations':len(stations)}
