"""Checkpointable best-improvement move/swap optimizer. Score convention: baseline_optimizer.py."""
from __future__ import annotations
import json
import os
from pathlib import Path
import numpy as np
import pandas as pd

RATE = 0.10
MIN_CAP = 20_000.


def atomic_json(path, value):
    path = Path(path)
    t = path.with_suffix(path.suffix + '.tmp')
    with t.open('w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False, default=str)
    os.replace(t, path)


def residual_matrix(frame, sites):
    r = frame[['site_id', 'ts', 'energy', 'pred_kwh']].copy()
    if r.pred_kwh.isna().any() or r.energy.isna().any():
        raise ValueError('Missing known generation/prediction')
    r['err'] = r['pred_kwh'].to_numpy(float) - r.energy.to_numpy(float)
    pivot = r.pivot(index='ts', columns='site_id', values='err').reindex(columns=sites.site_id).sort_index()
    return pivot.fillna(0).to_numpy(float), pd.DatetimeIndex(pivot.index), int(pivot.isna().sum().sum())


def score(mat, w, mask):
    g1 = mat[:, mask].sum(axis=1)
    g2 = mat[:, ~mask].sum(axis=1)
    return float(RATE * np.dot(w, abs(g1) + abs(g2)))


def lb(mat, w):
    return float(RATE * np.dot(w, abs(mat.sum(axis=1))))


def greedy_resume(mat, w, sites, init, out, batch=128, max_iter=0):
    """Checkpoint every accepted move; no hidden holdout inputs. Restart via --resume."""
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    checkpoint = out / 'greedy_state.npz'
    journal = out / 'greedy_trace.csv'
    capacities = sites.capacity_kw.to_numpy(float)
    capsum = capacities.sum()
    if checkpoint.exists():
        saved = np.load(checkpoint)
        mask = saved['mask'].astype(bool)
        iteration = int(saved['iteration'])
        print(f'[resume] Greedy iteration {iteration}', flush=True)
    else:
        mask = np.asarray(init, bool).copy(); iteration = 0
    if min(capacities[mask].sum(), capacities[~mask].sum()) < MIN_CAP - 1e-7:
        raise ValueError('Invalid initial/grouped capacity')
    w = np.asarray(w, float)
    tot = mat.sum(axis=1)
    g1 = mat[:, mask].sum(axis=1)
    cur = float(RATE*np.dot(w, np.maximum(abs(tot), abs(2*g1-tot))))
    history = pd.read_csv(journal).to_dict('records') if journal.exists() else []

    def persist():
        tmp_npz = checkpoint.with_suffix('.tmp.npz')
        np.savez_compressed(tmp_npz, mask=mask.astype('uint8'), iteration=iteration)
        os.replace(tmp_npz, checkpoint)
        pd.DataFrame(history, columns=['iteration','type','site_a','site_b','W_krw','improvement']).to_csv(journal, index=False)

    persist()
    while max_iter == 0 or iteration < max_iter:
        members1 = np.where(mask)[0]; members2 = np.where(~mask)[0]
        cap1 = float(capacities[mask].sum()); old = cur
        best = cur - 1e-6; action = None
        proposals = []
        # Move 1->2, 2->1
        for ix in members1:
            if cap1 - capacities[ix] >= MIN_CAP - 1e-7:
                proposals.append(('move', int(ix), -1, -mat[:,ix]))
        for ix in members2:
            if capsum-cap1 - capacities[ix] >= MIN_CAP - 1e-7:
                proposals.append(('move', int(ix), -1, mat[:,ix]))
        # Swaps
        for ix in members1:
            for jx in members2:
                c1 = cap1 - capacities[ix] + capacities[jx]
                if min(c1, capsum-c1) >= MIN_CAP - 1e-7:
                    proposals.append(('swap', int(ix), int(jx), mat[:,jx]-mat[:,ix]))
        for start in range(0, len(proposals), batch):
            chunk = proposals[start:start+batch]
            change = np.column_stack([v[3] for v in chunk])
            cand = RATE * np.sum(w[:,None]*np.maximum(abs(tot[:,None]), abs(2*(g1[:,None]+change)-tot[:,None])), axis=0)
            idx = int(np.argmin(cand))
            if cand[idx] < best:
                best = float(cand[idx]); action = chunk[idx]
        if action is None:
            persist(); return mask, {'iterations':iteration,'local_minimum_reached':True,'W_opt':cur}, pd.DataFrame(history)
        kind,a,b,change = action
        if kind=='move': mask[a] = ~mask[a]
        else: mask[a] = False; mask[b] = True
        g1 += change; cur = best; iteration+=1
        history.append({'iteration':iteration,'type':kind,'site_a':str(sites.site_id.iloc[a]),'site_b':str(sites.site_id.iloc[b]) if b>=0 else '', 'W_krw':cur, 'improvement':old-cur})
        persist()
        print(f'[greedy] {iteration:03d} {kind} W={cur:,.2f} (-{old-cur:,.2f})', flush=True)
    return mask, {'iterations':iteration,'local_minimum_reached':False,'W_opt':cur}, pd.DataFrame(history)
