"""Shared strictly local OIBC No.28-like pipeline (Random delivery-day 60:20:20).

Reference implementations: data/baseline.py, codes/nat_feat.py, codes/baseline_validation.py,
codes/baseline_optimizer.py. No official contest inputs are redistributed.
"""
from __future__ import annotations
import os
import sys
import time
import json
import pickle
import hashlib
import importlib.util
from pathlib import Path
from dataclasses import dataclass

import numpy as np
import pandas as pd
from _optimizer import atomic_json, residual_matrix, greedy_resume, score, lb

SEED=42
SPLIT_START=pd.Timestamp('2023-06-01 01:00', tz='Asia/Seoul')
TRAIN_SUBDIR='output/preprocessed/train'
TIME_A=['wa_cloud','wa_rain','wa_humidity']
TIME_B=['wb_cloud','wb_uv_idx','wb_total_liq']
NAT_COLS=['a_nat_cloud_mean','a_nat_cloud_std','a_nat_rain_mean','a_cloud_dev','b_nat_cloud_mean','b_nat_cloud_std','b_nat_uv_mean','b_cloud_dev']


def log(s): print('[sleeping50] '+str(s), flush=True)


def to_kst(v):
    d=pd.to_datetime(v)
    return d.dt.tz_localize('Asia/Seoul') if d.dt.tz is None else d.dt.tz_convert('Asia/Seoul')


def days(s): return (s-pd.Timedelta(hours=1)).dt.normalize()


def import_baseline(root):
    for p in [root/'baseline.py',root/'codes'/'baseline.py']:
        if p.is_file():
            spec=importlib.util.spec_from_file_location('sleeping50_user_baseline',p)
            mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
            return mod
    raise FileNotFoundError('baseline.py is required at data/baseline.py or data/codes/baseline.py')


def time_features(f, station, cols):
    f=f.sort_values([station,'round','ts']).copy(); g=f.groupby([station,'round'],sort=False)
    for c in cols:
        f[c+'_prev']=g[c].shift(1)
        f[c+'_next']=g[c].shift(-1)
    # ts is right-closed: midnight is the end of delivery day, next row belongs to next day
    mid=f.ts.dt.hour.eq(0)
    for c in cols: f.loc[mid,c+'_next']=np.nan
    f['_d']=days(f.ts)
    for c in cols: f[c+'_daymean']=f.groupby([station,'round','_d'],sort=False)[c].transform('mean')
    return f.drop(columns=['_d'])


def weather_features(root,base):
    src=root/TRAIN_SUBDIR
    a=pd.read_parquet(src/'forecast_wa.parquet')
    b=pd.read_parquet(src/'forecast_wb.parquet')
    for f in (a,b):
        f['ts']=to_kst(f.ts)
        if f.duplicated([('wa_station' if 'wa_station' in f else 'wb_station'),'round','ts']).any():
            raise ValueError('Duplicate forecast station-round-ts keys')
    a=time_features(a,'wa_station',TIME_A)
    b=time_features(b,'wb_station',TIME_B)
    na=a.groupby(['round','ts'],sort=False).agg(a_nat_cloud_mean=('wa_cloud','mean'),a_nat_cloud_std=('wa_cloud','std'),a_nat_rain_mean=('wa_rain','mean')).reset_index()
    nb=b.groupby(['round','ts'],sort=False).agg(b_nat_cloud_mean=('wb_cloud','mean'),b_nat_cloud_std=('wb_cloud','std'),b_nat_uv_mean=('wb_uv_idx','mean')).reset_index()
    a=a.merge(na,on=['round','ts'],how='left',validate='many_to_one')
    b=b.merge(nb,on=['round','ts'],how='left',validate='many_to_one')
    a['a_cloud_dev']=a.wa_cloud-a.a_nat_cloud_mean
    b['b_cloud_dev']=b.wb_cloud-b.b_nat_cloud_mean
    return a,b


def augmented_baseline(base):
    if getattr(base,'_sleeping50_augmented',False): return base
    new=[]
    for c in TIME_A+TIME_B:
        new.extend([c+'_prev',c+'_next',c+'_daymean'])
    new.extend(['cloud_diff']+NAT_COLS)
    base.FEATS=list(dict.fromkeys(list(base.FEATS)+new))
    orig=base.features
    def f(*a,**kw):
        d=orig(*a,**kw);d['cloud_diff']=d['wa_cloud']-d['wb_cloud'];return d
    base.features=f; base._sleeping50_augmented=True
    return base


def read_sites(root):
    s=pd.read_csv(root/'sites.csv')
    req={'site_id','current_group','capacity_kw','lat','lon','wa_station','wb_station'}
    if not req.issubset(s):raise ValueError('sites.csv missing '+str(req-set(s)))
    if s.site_id.duplicated().any() or len(s)!=253:raise ValueError('Expected 253 distinct plants')
    return s


def read_generation(root):
    d=pd.read_parquet(root/'train'/'generation.parquet',columns=['site_id','ts','energy'])
    d['ts']=to_kst(d.ts)
    if d.duplicated(['site_id','ts']).any():raise ValueError('Duplicate generation rows')
    d['energy']=pd.to_numeric(d.energy,errors='coerce')
    if not np.isfinite(d.energy).all():raise ValueError('Generation contains nonfinite values')
    d['energy']=np.maximum(d.energy,0)
    return d


def split_frames(g):
    newer=g[g.ts>=SPLIT_START]
    ds=pd.DatetimeIndex(days(newer.ts).drop_duplicates().sort_values())
    rng=np.random.default_rng(SEED);p=rng.permutation(len(ds))
    nf=int(np.floor(len(ds)*.6)); ng=int(np.floor(len(ds)*.2))
    dm=pd.DataFrame({'day_kst':ds.strftime('%Y-%m-%d'), 'split':np.select([np.isin(np.arange(len(ds)),p[:nf]),np.isin(np.arange(len(ds)),p[nf:nf+ng])],['model_train','group_opt'],default='holdout')})
    # Historical data before train-from joins model_train only
    m=dm.set_index('day_kst')['split']
    x=days(g.ts).dt.strftime('%Y-%m-%d').map(m)
    fit=g[(x=='model_train') | (g.ts<SPLIT_START)].copy()
    opt=g[x=='group_opt'].copy(); hold=g[x=='holdout'].copy()
    assert len(set(dm[dm.split=='model_train'].day_kst)&set(dm[dm.split=='holdout'].day_kst))==0
    return fit,opt,hold,dm


def read_price(root):
    p=pd.read_csv(root/'train'/'smp.csv',usecols=['ts','smp']);p['ts']=to_kst(p.ts)
    if p.ts.duplicated().any():raise ValueError('Duplicate SMP ts')
    return p.set_index('ts').smp


def weight_for_rows(df,price,capacity=False):
    w=pd.to_numeric(df.ts.map(price),errors='coerce').to_numpy(float)
    if not np.isfinite(w).all() or (w<0).any():raise ValueError('Missing or negative SMP')
    w *= np.where(df.ts.dt.hour.between(11,15).to_numpy(),3.,1.)
    if capacity: w *= df.cap.to_numpy(float)
    return w


def time_weights(times,price):
    ts=pd.Series(times)
    w=ts.map(price).to_numpy(float)*np.where(ts.dt.hour.between(11,15),3.,1.)
    if not np.isfinite(w).all():raise ValueError('missing SMP for scored times')
    return w


def extra_cols(df):
    return [c for c in df.columns if c not in ('energy','site_id','ts','wa_station','wb_station','current_group') and pd.api.types.is_numeric_dtype(df[c])]


def df_features(base, gen, sites, wa, wb, r=17):
    # baseline.features accepts observed keys through its `gen` branch and expects
    # an energy column; inference rows have no label, so supply NaN (never used).
    if 'energy' not in gen.columns:
        gen=gen.copy(); gen['energy']=np.nan
    d=base.features(gen,sites,wa,wb,None,r)
    if len(d)!=len(gen):raise ValueError(f'Feature join changed row count for round {r} ({len(d)} vs {len(gen)})')
    return d


def save_model(model,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('wb') as f:pickle.dump(model,f,protocol=pickle.HIGHEST_PROTOCOL)


def load_model(path):
    with Path(path).open('rb') as f:return pickle.load(f)


def fit_model(model_kind,X,y,w):
    if model_kind=='lgb':
        from lightgbm import LGBMRegressor
        mod=LGBMRegressor(objective='regression_l1',n_estimators=600,learning_rate=.06,num_leaves=127,min_child_samples=200,subsample=.8,subsample_freq=1,colsample_bytree=.8,verbosity=-1,n_jobs=4,random_state=42)
    elif model_kind=='cat':
        from catboost import CatBoostRegressor
        mod=CatBoostRegressor(loss_function='MAE',iterations=600,learning_rate=.06,depth=8,random_seed=42,verbose=False,thread_count=4)
    else: raise ValueError(model_kind)
    mod.fit(X,y,sample_weight=w)
    return mod


def frame_xy(df,feats):
    X=df[feats].apply(pd.to_numeric,errors='coerce').astype('float32')
    X=X.replace([np.inf,-np.inf],np.nan)
    y=(df.energy/df.cap).clip(0,1.2).astype('float32') if 'energy' in df else None
    return X,y


def _train_base(root, out):
    base=augmented_baseline(import_baseline(root))
    sites=read_sites(root)
    g=read_generation(root)
    fit,opt,hold,daymap=split_frames(g)
    out.mkdir(parents=True,exist_ok=True)
    daymap.to_csv(out/'split_days.csv',index=False)
    del g
    log(f'Split: fit {len(fit):,}, groupopt {len(opt):,}, holdout {len(hold):,}')
    fa,fb=weather_features(root,base)
    price=read_price(root)
    # Build and save predictions for each model+round one at a time.
    for r in (10,17):
        ck={m:out/'models'/f'{m}_r{r}.pkl' for m in ('lgb','cat')}
        prediction_paths={p:out/f'{p}_r{r}.parquet' for p in ('group_opt','holdout')}
        missing_models=[m for m,path in ck.items() if not path.exists()]
        if missing_models:
            df=df_features(base,fit,sites,fa,fb,r)
            df=df[df.elev>0].copy()
            X,y=frame_xy(df,base.FEATS)
            w=weight_for_rows(df,price,capacity=True)
            w=w/max(float(np.mean(w)),1e-12)
            for m in missing_models:
                mod=fit_model(m,X,y,w)
                save_model(mod,ck[m]);log(f'Cached model {m} round={r}')
            del df,X,y,w
        if all(p.exists() for p in prediction_paths.values()):continue
        models={m:load_model(path) for m,path in ck.items()}
        for part,actual in [('group_opt',opt),('holdout',hold)]:
            if prediction_paths[part].exists():continue
            df=df_features(base,actual,sites,fa,fb,r)
            X,_=frame_xy(df,base.FEATS)
            one=df[['site_id','ts']].copy()
            for m,model in models.items():
                cf=np.asarray(model.predict(X),float)
                one[m]=np.maximum(np.where(df.elev.to_numpy()>0,cf,0.),0.)*df.cap.to_numpy(float)
            one.to_parquet(prediction_paths[part],index=False)
            log(f'Cached {part} round {r}: {len(one):,} site-hours')
            del df,X,one
        del models
    for part,actual in [('group_opt',opt),('holdout',hold)]:
        pred=None
        for r in (10,17):
            d=pd.read_parquet(out/f'{part}_r{r}.parquet')
            d=d.rename(columns={'lgb':f'lgb_{r}','cat':f'cat_{r}'})
            pred=d if pred is None else pred.merge(d,on=['site_id','ts'],validate='one_to_one')
        pred['pred_kwh']=.25*(pred.lgb_10+pred.lgb_17+pred.cat_10+pred.cat_17)
        pred.to_parquet(out/f'{part}_predictions.parquet',index=False)
        df=df_features(base,actual,sites,fa,fb,17)
        ctx_cols=['site_id','ts','cap','lat','lon','elev','azim','cosz','hour','doy_sin','doy_cos','wa_cloud','wb_cloud','wa_humidity','wb_rel_hum','wa_temp','wb_temp','wb_uv_idx','wb_dew_point','wa_wind_speed','wb_wind_speed','wa_rain','wb_total_liq','a_nat_cloud_mean','b_nat_cloud_mean','cloud_diff']
        cols=[c for c in ctx_cols if c in df.columns]
        df[cols].to_parquet(out/f'{part}_context.parquet',index=False)
        del df,pred
    meta={'complete':True,'seed':SEED,'split_from':str(SPLIT_START),'reference':'No.28-style 19 temporal/weather + 8 national, LGBM/CatBoost 50:50, 10/17 mean; no scaling, fixed pipeline','train_full_history':True,'feature_cols':base.FEATS,'model_cache':str(out/'models')}
    atomic_json(out/'manifest.json',meta)
    return meta


def prepare_baseline(root, out):
    out=Path(out); manifest=out/'manifest.json'
    if manifest.exists():
        m=json.loads(manifest.read_text())
        req=[out/f'{p}_predictions.parquet' for p in ('group_opt','holdout')]
        req += [out/f'{p}_context.parquet' for p in ('group_opt','holdout')]
        req += [out/'split_days.csv']
        if m.get('complete') and all(x.exists() for x in req):return m
    return _train_base(root,out)


@dataclass
class Workspace:
    root:Path
    out:Path
    shared:Path
    rank:int
    resume:bool
    max_neural_train:int
    neural_epochs:int
    max_residual_train:int
    greedy_max_iter:int
    greedy_batch:int
    def path(self, name):return self.out/name
    def state(self, name): return (self.out/name).exists()
    def checkpoint(self,name,data):atomic_json(self.out/name,data)


def get_frames(ws):
    sites=read_sites(ws.root)
    frames={}
    for part in ['group_opt','holdout']:
        pred=pd.read_parquet(ws.shared/f'{part}_predictions.parquet')
        context=pd.read_parquet(ws.shared/f'{part}_context.parquet')
        frames[part]=pred.merge(context,on=['site_id','ts'],validate='one_to_one')
    return sites,frames


def load_labeled_frames(ws):
    sites,frames=get_frames(ws)
    gen=read_generation(ws.root)
    fit,opt,hold,_=split_frames(gen)
    del gen
    opt=opt.merge(frames['group_opt'],on=['site_id','ts'],validate='one_to_one',how='left')
    hold=hold.merge(frames['holdout'],on=['site_id','ts'],validate='one_to_one',how='left')
    if opt.pred_kwh.isna().any() or hold.pred_kwh.isna().any():raise ValueError('Lost OOS base predictions')
    return sites,fit,opt,hold


def numeric_features(df):
    wanted=['pred_kwh','cap','hour','elev','cosz','doy_sin','doy_cos','wa_cloud','wb_cloud','wa_humidity','wb_rel_hum','wa_temp','wb_temp','wb_uv_idx','wb_dew_point','wa_wind_speed','wb_wind_speed','wa_rain','wb_total_liq','a_nat_cloud_mean','b_nat_cloud_mean','cloud_diff','lat','lon']
    return [c for c in wanted if c in df]


def site_id_encoded(a,b):
    from sklearn.compose import ColumnTransformer
    from sklearn.preprocessing import OneHotEncoder,StandardScaler
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline
    nums=numeric_features(a)
    tr=ColumnTransformer([('num',Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=False)),('scale',StandardScaler())]),nums),('site',OneHotEncoder(handle_unknown='ignore'),['site_id'])],sparse_threshold=.2)
    X=tr.fit_transform(a);Y=tr.transform(b)
    return X,Y,tr


def clip_predictions(frame, p):
    p=np.asarray(p,float)
    if not np.isfinite(p).all():raise ValueError('Candidate predicted nonfinite')
    return np.clip(p,0,frame.cap.to_numpy(float))


def evaluate(ws, sites, opt, hold, extra):
    """Holdout labels only used after all candidate fitting and greedy assignment."""
    from _optimizer import score
    price=read_price(ws.root)
    init=sites.current_group.eq('A').to_numpy(bool)
    actual_opt=opt[['site_id','ts','energy','pred_kwh']].copy()
    actual_hold=hold[['site_id','ts','energy','pred_kwh']].copy()
    if actual_opt.pred_kwh.isna().any() or actual_hold.pred_kwh.isna().any():raise ValueError('Missing candidate predictions')
    actual_opt.to_parquet(ws.path('group_opt_site_predictions.parquet'),index=False)
    actual_hold.to_parquet(ws.path('holdout_site_predictions.parquet'),index=False)
    optmat,opt_ts,optmissing=residual_matrix(actual_opt,sites)
    holdmat,hold_ts,holdmissing=residual_matrix(actual_hold,sites)
    wopt=time_weights(opt_ts,price); whold=time_weights(hold_ts,price)
    optmask,trace_info,trace=greedy_resume(optmat,wopt,sites,init,ws.out,batch=ws.greedy_batch,max_iter=ws.greedy_max_iter)
    cap1=float(sites.loc[optmask,'capacity_kw'].sum()); cap2=float(sites.loc[~optmask,'capacity_kw'].sum())
    if min(cap1,cap2)<20_000:raise ValueError('Group capacity infeasible')
    pd.DataFrame({'site_id':sites.site_id,'group':np.where(optmask,'G1','G2')}).to_csv(ws.path('composition.csv'),index=False)
    # Scored only on independent Holdout; GROUP_OPT metrics separately disclosed.
    wrows=weight_for_rows(hold,price,capacity=False)
    mae=float(np.dot(wrows,abs(hold.pred_kwh.to_numpy(float)-hold.energy.to_numpy(float)))/wrows.sum())
    summary={'rank':ws.rank,'experiment':extra,'validation':'Random delivery-day 60:20:20 seed42, full historical model-fit only',
             'weighted_MAE_kwh':mae, 'initial_penalty_W_krw':score(holdmat,whold,init),
             'optimized_penalty_W_krw':score(holdmat,whold,optmask),
             'theoretical_lower_bound_W_krw':lb(holdmat,whold),
             'improvable_cost_W_krw':score(holdmat,whold,optmask)-lb(holdmat,whold),
             'group_opt_initial_W_krw':score(optmat,wopt,init),'group_opt_optimized_W_krw':score(optmat,wopt,optmask),
             'holdout_hours':len(hold_ts),'group_opt_hours':len(opt_ts),'missing_site_hours_filled_with_zero_groupopt':optmissing,
             'missing_site_hours_filled_with_zero_holdout':holdmissing,'group_G1_kw':cap1,'group_G2_kw':cap2,'greedy':trace_info,
             'metric_definition':'Site-level Weighted MAE weights SMP*k (no capacity repeat); W=0.10*sum SMP*k*(abs(G1err)+abs(G2err)).'}
    atomic_json(ws.path('summary.json'),summary)
    pd.DataFrame([{'No.':ws.rank,'Weighted MAE':mae,'Initial Penalty':summary['initial_penalty_W_krw'],
                  'Optimized Penalty':summary['optimized_penalty_W_krw'],
                  'Theoretical Lower Bound':summary['theoretical_lower_bound_W_krw'],
                  'Improvable Cost':summary['improvable_cost_W_krw']}]).to_csv(ws.path('results_row.csv'),index=False)
    # Reusable diagnostics, no test labels.
    for label,mt,ts in [('group_opt',optmat,opt_ts),('holdout',holdmat,hold_ts)]:
        np.savez_compressed(ws.path(f'{label}_residual_matrix.npz'),matrix=mt.astype('float32'),times=ts.tz_convert('UTC').tz_localize(None).to_numpy(),sites=sites.site_id.to_numpy())
    print('\n'+'='*70)
    print('RANK',ws.rank,'HOLDOUT:')
    print('Weighted MAE             =',f'{mae:.5f}')
    print('Initial Penalty W        =',f'{summary["initial_penalty_W_krw"]:,.2f}')
    print('Optimized Penalty W      =',f'{summary["optimized_penalty_W_krw"]:,.2f}')
    print('Theoretical Lower Bound  =',f'{summary["theoretical_lower_bound_W_krw"]:,.2f}')
    print('Improvable Cost          =',f'{summary["improvable_cost_W_krw"]:,.2f}')
    print('Saved:',ws.out,'\n'+'='*70,flush=True)
    return summary
