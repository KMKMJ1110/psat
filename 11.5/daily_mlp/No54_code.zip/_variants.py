"""Actual experimental methods. Each rank is dispatched independently; never fits on holdout labels."""
from __future__ import annotations
import json
import pickle
from pathlib import Path
import numpy as np
import pandas as pd
from _core import (log, read_sites,read_generation,split_frames,read_price,weight_for_rows,weather_features,
    import_baseline,augmented_baseline,df_features,frame_xy,fit_model,save_model,load_model,
    numeric_features,clip_predictions,days,site_id_encoded,to_kst)
from _optimizer import atomic_json, score, residual_matrix


def _save(ws,name,obj):save_model(obj,ws.path(name))


def _subsample(df, limit, seed=42):
    if len(df)<=limit:return df
    return df.sample(limit,random_state=seed).sort_index()


def _groups(df, n=5):
    from sklearn.model_selection import KFold
    vals=pd.DatetimeIndex(days(df.ts).drop_duplicates().sort_values())
    if len(vals)<n:return [(np.arange(len(df)),np.arange(len(df)))]
    day=days(df.ts)
    for tr,va in KFold(n_splits=n,shuffle=True,random_state=42).split(vals):
        train=np.flatnonzero(day.isin(vals[tr]).to_numpy())
        valid=np.flatnonzero(day.isin(vals[va]).to_numpy())
        yield train,valid


def _pipeline(df,kind='logit'):
    from sklearn.compose import ColumnTransformer
    from sklearn.preprocessing import StandardScaler,OneHotEncoder
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline
    from sklearn.linear_model import LogisticRegression,Ridge
    feats=numeric_features(df)
    transform=ColumnTransformer([
        ('num',Pipeline([('fill',SimpleImputer(strategy='median',keep_empty_features=True)),('scale',StandardScaler())]),feats),
        ('site',OneHotEncoder(handle_unknown='ignore'),['site_id'])], sparse_threshold=.3)
    clf=LogisticRegression(max_iter=180,C=.5,solver='lbfgs') if kind=='logit' else Ridge(alpha=80.,solver='lsqr')
    return Pipeline([('prep',transform),('estimator',clf)])


def _fit_model(df,y,kind,limit,seed=42):
    take=np.arange(len(df))
    if len(take)>limit: take=np.random.default_rng(seed).choice(take,limit,replace=False)
    X=df.iloc[take]
    Y=np.asarray(y)[take]
    if kind=='logit' and len(np.unique(Y))<2:
        from sklearn.dummy import DummyClassifier
        model=_pipeline(df,kind)
        model.set_params(estimator=DummyClassifier(strategy='constant',constant=int(Y[0])))
    else:model=_pipeline(df,kind)
    model.fit(X,Y)
    return model


def _prob(model,df):
    if df.empty:return np.array([])
    p=model.predict_proba(df)
    classes=model.named_steps['estimator'].classes_
    return p[:,list(classes).index(1)] if 1 in classes else np.zeros(len(df))


def _ridge_positive_negative(train,df,limit,seed):
    cap=train.cap.to_numpy(float)
    rr=(train.energy.to_numpy(float)-train.pred_kwh.to_numpy(float))/np.maximum(cap,1)
    sign=_fit_model(train,(rr>0).astype('int8'),'logit',limit,seed)
    pos=train.loc[rr>0]; neg=train.loc[rr<0]
    models={}
    for key,part,sgn in [('plus',pos,1),('minus',neg,-1)]:
        if len(part)<100: models[key]=None;continue
        posind=part.index
        rrpart=(part.energy.to_numpy(float)-part.pred_kwh.to_numpy(float))/np.maximum(part.cap.to_numpy(float),1)
        m=_fit_model(part,np.abs(rrpart),'ridge',limit,seed)
        models[key]=m
    p=_prob(sign,df)
    amp_plus=np.maximum(models['plus'].predict(df),0) if models['plus'] is not None else np.zeros(len(df))
    amp_minus=np.maximum(models['minus'].predict(df),0) if models['minus'] is not None else np.zeros(len(df))
    return (p*amp_plus-(1-p)*amp_minus),{'sign':sign,**models}


def _oof_ridge(ws,opt,hold,mode):
    # Train corrected residuals using group-opt only; score group-opt on day OOF corrections.
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    rr=(opt.energy.to_numpy(float)-opt.pred_kwh.to_numpy(float))/np.maximum(opt.cap.to_numpy(float),1)
    oo=np.zeros(len(opt)); model=None
    for fold,(tr,va) in enumerate(_groups(opt)):
        train=_subsample(opt.iloc[tr],ws.max_residual_train,seed=fold+42)
        corrector=_fit_model(train,(train.energy.to_numpy(float)-train.pred_kwh.to_numpy(float))/np.maximum(train.cap.to_numpy(float),1),'ridge',ws.max_residual_train)
        oo[va]=corrector.predict(opt.iloc[va]);
        _save(ws,f'fold_{fold}_ridge.pkl',corrector)
        del corrector
    full=_fit_model(opt,rr,'ridge',ws.max_residual_train)
    _save(ws,'residual_ridge_final.pkl',full)
    hh=np.asarray(full.predict(hold),float)
    return oo,hh,full


def _fit_sign_oof(ws,opt,hold):
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    sign=(opt.energy.to_numpy(float)-opt.pred_kwh.to_numpy(float)>0).astype(int)
    oof=np.zeros(len(opt))
    for fold,(tr,va) in enumerate(_groups(opt)):
        d=_subsample(opt.iloc[tr],ws.max_residual_train,seed=fold+41)
        lab=(d.energy.to_numpy(float)-d.pred_kwh.to_numpy(float)>0).astype(int)
        model=_fit_model(d,lab,'logit',ws.max_residual_train,seed=fold+99)
        oof[va]=_prob(model,opt.iloc[va]);_save(ws,f'fold_{fold}_sign.pkl',model)
    final=_fit_model(opt,sign,'logit',ws.max_residual_train)
    _save(ws,'sign_logistic_final.pkl',final)
    return oof,_prob(final,hold),final


def _line_scan_alpha(ws,opt,raw):
    # Tuning on group-opt OOF only, never on independent holdout. Prefer conservative shrinkage.
    from _core import read_price,time_weights
    from _optimizer import residual_matrix
    sites=read_sites(ws.root);price=read_price(ws.root)
    init=sites.current_group.eq('A').to_numpy(bool)
    best=(float('inf'),0.)
    for c in (0.,.15,.3,.5,.7,1.):
        df=opt[['site_id','ts','energy','pred_kwh']].copy();df['pred_kwh']=clip_predictions(opt,opt.pred_kwh.to_numpy(float)+c*raw)
        mat,t,_=residual_matrix(df,sites)
        v=score(mat,time_weights(t,price),init)
        if v<best[0]:best=(v,c)
    ws.checkpoint('alpha_search.json',{'alpha':float(best[1]),'groupopt_initial_W':best[0],'note':'single alpha chosen on group-opt day-OOF only'})
    return best[1]


def rank_1(ws,opt,hold,sites):
    """F1: G1/G2 error sign classification, allocation by capacity; conditional median magnitude."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    assign=sites.set_index('site_id').current_group.to_dict()
    def summed(df, allow_labels):
        x=df.copy();x['group']=x.site_id.map(assign)
        x['resid']=x.energy-x.pred_kwh if allow_labels else 0
        agg=x.groupby(['group','ts'],sort=False).agg(resid=('resid','sum'),pred=('pred_kwh','sum'),cap=('cap','sum'),
            cloud=('wa_cloud','mean'),humidity=('wa_humidity','mean'),uv=('wb_uv_idx','mean'),hour=('hour','first')).reset_index()
        return agg
    a=summed(opt,True);b=summed(hold,False)
    def xcols(d):return d[['pred','cap','cloud','humidity','uv','hour']]
    outa=[];outb=[];models={}
    for g in ['A','B']:
        tr=a[a.group==g].copy().reset_index(drop=True);te=b[b.group==g].copy().reset_index(drop=True)
        from sklearn.model_selection import KFold
        p=np.zeros(len(tr));mag=np.zeros(len(tr))
        for fold,(train,valid) in enumerate(_groups(tr)):
            xtr=xcols(tr.iloc[train]);yy=(tr.resid.iloc[train]>0).astype(int)
            if yy.nunique()<2:prob=np.full(len(valid),float(yy.iloc[0]));m=None
            else:
                m=make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(max_iter=400))
                m.fit(xtr,yy);prob=m.predict_proba(xcols(tr.iloc[valid]))[:,1]
            p[valid]=prob;mag[valid]=np.median(np.abs(tr.resid.iloc[train]))
        yy=(tr.resid>0).astype(int)
        if yy.nunique()<2:pr=np.full(len(te),float(yy.iloc[0]));model=None
        else:
            model=make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(max_iter=400))
            model.fit(xcols(tr),yy);pr=model.predict_proba(xcols(te))[:,1]
        modelpath=f'group_{g}_sign.pkl';_save(ws,modelpath,{'classifier':model,'median_magnitude':np.median(abs(tr.resid))})
        tr['corr']=(2*p-1)*mag;te['corr']=(2*pr-1)*np.median(abs(tr.resid))
        outa.append(tr[['group','ts','corr','cap']]);outb.append(te[['group','ts','corr','cap']])
    def spread(frame,delta):
        delta=pd.concat(delta)
        z=frame.copy();z['group']=z.site_id.map(assign)
        z=z.merge(delta,on=['group','ts'],suffixes=('','_grp'),validate='many_to_one')
        return z['corr'].to_numpy(float)*z.cap.to_numpy(float)/np.maximum(z.cap_grp.to_numpy(float),1.)
    ao=spread(opt,outa);ah=spread(hold,outb)
    alpha=_line_scan_alpha(ws,opt,ao)
    return clip_predictions(opt,opt.pred_kwh+alpha*ao),clip_predictions(hold,hold.pred_kwh+alpha*ah),{'algorithm':'F1 group-sign logistic/median magnitude','alpha':alpha}


def rank_2(ws,opt,hold,sites):
    """F5: sign-specific Ridge experts with logistic soft gate; OOF, site_id included."""
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    oc=np.zeros(len(opt))
    for fold,(tr,va) in enumerate(_groups(opt)):
        corr,mods=_ridge_positive_negative(_subsample(opt.iloc[tr],ws.max_residual_train,seed=fold+42),opt.iloc[va],ws.max_residual_train,fold+42)
        oc[va]=corr*opt.cap.to_numpy(float)[va];_save(ws,f'fold_{fold}_moe.pkl',mods)
    hc,mods=_ridge_positive_negative(_subsample(opt,ws.max_residual_train),hold,ws.max_residual_train,42)
    hc=hc*hold.cap.to_numpy(float);_save(ws,'moe_final.pkl',mods)
    alpha=_line_scan_alpha(ws,opt,oc)
    return clip_predictions(opt,opt.pred_kwh+alpha*oc),clip_predictions(hold,hold.pred_kwh+alpha*hc),{'algorithm':'F5 site-conditioned sign logistic + separate positive/negative Ridge','alpha':alpha}


def rank_3(ws,opt,hold,sites):
    """F4: gate existing Ridge correction only where an OOF-trained classifier predicts a gain."""
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    ro,rh,_=_oof_ridge(ws,opt,hold,'ridge')
    target=(abs(opt.energy-opt.pred_kwh)>abs(opt.energy-(opt.pred_kwh+ro*opt.cap))).astype(int)
    # Classifier OOF uses separate day folds, no training on the evaluated row.
    po=np.zeros(len(opt))
    for fold,(tr,va) in enumerate(_groups(opt)):
        train=_subsample(opt.iloc[tr],ws.max_residual_train,seed=fold+42)
        model=_fit_model(train,target.to_numpy()[train.index.to_numpy()], 'logit',ws.max_residual_train,seed=fold+42)
        po[va]=_prob(model,opt.iloc[va]);_save(ws,f'fold_{fold}_gate.pkl',model)
    final=_fit_model(opt,target.to_numpy(),'logit',ws.max_residual_train)
    _save(ws,'gate_final.pkl',final);ph=_prob(final,hold)
    # threshold selected using group-opt OOF only
    vals=[]
    for t in (.55,.65,.75,.85):
        c=ro*opt.cap.to_numpy(float)*(po>=t)
        aa=_line_scan_alpha(ws,opt,c)
        vals.append((float(json.loads(ws.path('alpha_search.json').read_text())['groupopt_initial_W']),t,aa))
    _,threshold,alpha=min(vals)
    ws.checkpoint('gate_threshold.json',{'threshold':threshold,'alpha':alpha,'choices':vals})
    return clip_predictions(opt,opt.pred_kwh+alpha*ro*opt.cap*(po>=threshold)),clip_predictions(hold,hold.pred_kwh+alpha*rh*hold.cap*(ph>=threshold)),{'algorithm':'F4 selective Ridge gate','threshold':threshold,'alpha':alpha}


def rank_4(ws,opt,hold,sites):
    """E6: W-constrained OOF simplex LGB/Cat blend (fixed initial composition)."""
    from scipy.optimize import minimize_scalar
    from _core import read_price,time_weights
    init=sites.current_group.eq('A').to_numpy(bool)
    price=read_price(ws.root)
    def pred(df,a):return a*(df.lgb_10+df.lgb_17).to_numpy(float)*.5+(1-a)*(df.cat_10+df.cat_17).to_numpy(float)*.5
    def obj(a):
        frame=opt[['site_id','ts','energy']].copy();frame['pred_kwh']=clip_predictions(opt,pred(opt,a))
        mat,t,_=residual_matrix(frame,sites)
        return score(mat,time_weights(t,price),init)
    result=minimize_scalar(obj,bounds=(.05,.95),method='bounded',options={'xatol':.005})
    alpha=float(result.x)
    ws.checkpoint('w_simplex.json',{'lgb':alpha,'cat':1-alpha,'group_opt_W':float(result.fun),'optimizer':'bounded scalar search'})
    return clip_predictions(opt,pred(opt,alpha)),clip_predictions(hold,pred(hold,alpha)),{'algorithm':'E6 OOF constrained W simplex','lgb_weight':alpha}


def rank_6(ws,opt,hold,sites):
    """E5: weather-regime conditional model selection, crossfitted in group-opt days."""
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    def groups(d):
        cloud=d.wa_cloud.fillna(50).to_numpy(float)
        return np.where(cloud>=70,2,np.where(cloud<30,0,1))*3 + np.where(d.hour.between(11,15),2,np.where(d.hour.between(8,17),1,0))
    reg=groups(opt);rgh=groups(hold)
    def learn(d,region):
        y=d.energy.to_numpy(float)
        aa=.5*(d.lgb_10+d.lgb_17).to_numpy(float)
        bb=.5*(d.cat_10+d.cat_17).to_numpy(float)
        price=read_price(ws.root);w=weight_for_rows(d,price)
        mapping={}
        for c in range(9):
            mask=region==c
            if mask.sum()<300: mapping[c]=.5;continue
            errs=[np.dot(w[mask],abs(a*aa[mask]+(1-a)*bb[mask]-y[mask])) for a in (0.,.25,.5,.75,1.)]
            candidate=float((0.,.25,.5,.75,1.)[int(np.argmin(errs))])
            mapping[c]=.5+min(1,mask.sum()/2500)*.7*(candidate-.5)
        return mapping
    weight=np.full(len(opt),.5)
    for tr,va in _groups(opt):
        mp=learn(opt.iloc[tr],reg[tr]);weight[va]=[mp[int(x)] for x in reg[va]]
    mp=learn(opt,reg)
    ws.checkpoint('weather_dynamic_model_weights.json',mp)
    wh=np.array([mp[int(x)] for x in rgh])
    def blend(d,w):return w*.5*(d.lgb_10+d.lgb_17).to_numpy(float)+(1-w)*.5*(d.cat_10+d.cat_17).to_numpy(float)
    return clip_predictions(opt,blend(opt,weight)),clip_predictions(hold,blend(hold,wh)),{'algorithm':'E5 weather conditional LGB/Cat selection','regime_alpha':mp}


def rank_8(ws,opt,hold,sites):
    """F2: 5-state site normalized residual multiclass model."""
    from lightgbm import LGBMClassifier
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    def ctarget(d):
        r=(d.energy-d.pred_kwh).to_numpy(float)/np.maximum(d.cap.to_numpy(float),1.)
        return np.digitize(r,[-.08,-.015,.015,.08])
    tr_y=ctarget(opt);center=np.zeros(5)
    def fit_predict(train,test):
        d=_subsample(train,ws.max_residual_train)
        ff=numeric_features(d); x=d[ff].replace([np.inf,-np.inf],np.nan)
        x=x.fillna(x.median()).astype('float32');xte=test[ff].replace([np.inf,-np.inf],np.nan).fillna(x.median()).astype('float32')
        y=ctarget(d)
        model=LGBMClassifier(n_estimators=90,learning_rate=.07,num_leaves=15,min_child_samples=60,random_state=42,verbosity=-1,n_jobs=3)
        model.fit(x,y)
        center=np.array([np.median(((d.energy-d.pred_kwh)/d.cap)[y==cl]) if np.any(y==cl) else 0. for cl in model.classes_])
        corr=model.predict_proba(xte)@center
        return corr,{'model':model,'features':ff,'fill':x.median(),'states':model.classes_.tolist(),'centers':center.tolist()}
    oo=np.zeros(len(opt))
    for fold,(tr,va) in enumerate(_groups(opt, n=3)):
        v,model=fit_predict(opt.iloc[tr],opt.iloc[va]);oo[va]=v*opt.cap.to_numpy(float)[va];_save(ws,f'fold_{fold}_fiveclass.pkl',model)
    hh,model=fit_predict(opt,hold);_save(ws,'fiveclass_final.pkl',model)
    hh*=hold.cap.to_numpy(float);alpha=_line_scan_alpha(ws,opt,oo)
    return clip_predictions(opt,opt.pred_kwh+alpha*oo),clip_predictions(hold,hold.pred_kwh+alpha*hh),{'algorithm':'F2 5-state error classification','alpha':alpha}


def rank_13(ws,opt,hold,sites):
    """F8: beta calibration of OOF sign probabilities, then directional shrinkage."""
    from sklearn.linear_model import LogisticRegression
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    po,ph,mod=_fit_sign_oof(ws,opt,hold)
    label=(opt.energy-opt.pred_kwh>0).astype('int8').to_numpy()
    eps=1e-5
    def beta_x(p):
        q=np.clip(p,eps,1-eps)
        return np.column_stack([np.log(q),-np.log1p(-q)])
    calibrator=LogisticRegression(max_iter=250).fit(beta_x(po),label)
    _save(ws,'beta_calibrator.pkl',calibrator)
    # OOF calibration itself should be crossfit: fold fit on others OOF probabilities.
    pb=np.zeros(len(opt))
    for tr,va in _groups(opt):
        m=LogisticRegression(max_iter=250).fit(beta_x(po[tr]),label[tr]);pb[va]=m.predict_proba(beta_x(po[va]))[:,1]
    hb=calibrator.predict_proba(beta_x(ph))[:,1]
    magnitude=np.median(np.abs((opt.energy-opt.pred_kwh)/opt.cap))*1.0
    oo=(2*pb-1)*magnitude*opt.cap.to_numpy(float)
    hh=(2*hb-1)*magnitude*hold.cap.to_numpy(float)
    alpha=_line_scan_alpha(ws,opt,oo)
    return clip_predictions(opt,opt.pred_kwh+alpha*oo),clip_predictions(hold,hold.pred_kwh+alpha*hh),{'algorithm':'F8 crossfitted beta calibration + directional correction','alpha':alpha,'median_abs_cf_resid':magnitude}


def rank_14(ws,opt,hold,sites):
    """F7: conditional residual median by season, cloud, humidity, hour; OOF shrinkage."""
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    def key(d):
        month=d.ts.dt.month.to_numpy()
        return pd.DataFrame({'season':(month%12)//3,'hour':d.hour.to_numpy(int)//3,
                             'cloud':np.clip((d.wa_cloud.fillna(50).to_numpy(float)//25).astype(int),0,4),
                             'humid':np.clip((d.wa_humidity.fillna(50).to_numpy(float)//25).astype(int),0,4)})
    keys=['season','hour','cloud','humid']
    def correct(train,test):
        a=key(train);b=key(test)
        a['rr']=(train.energy.to_numpy(float)-train.pred_kwh.to_numpy(float))/np.maximum(train.cap.to_numpy(float),1)
        med=a.groupby(keys).rr.agg(['median','count']).reset_index()
        out=b.merge(med,on=keys,how='left')
        fallback=float(np.median(a.rr))
        weight=out['count'].fillna(0).to_numpy(float)/(out['count'].fillna(0).to_numpy(float)+100)
        return weight*out['median'].fillna(fallback).to_numpy(float)+(1-weight)*fallback,med
    oo=np.zeros(len(opt))
    for fold,(tr,va) in enumerate(_groups(opt)):
        c,_=correct(opt.iloc[tr],opt.iloc[va]);oo[va]=c*opt.cap.to_numpy(float)[va]
    hh,med=correct(opt,hold);med.to_csv(ws.path('weather_residual_medians.csv'),index=False)
    hh=hh*hold.cap.to_numpy(float);alpha=_line_scan_alpha(ws,opt,oo)
    return clip_predictions(opt,opt.pred_kwh+alpha*oo),clip_predictions(hold,hold.pred_kwh+alpha*hh),{'algorithm':'F7 weather conditional median','alpha':alpha}


def rank_19(ws,opt,hold,sites):
    """F12: 2-D Gaussian kernel smoothed OOF residual CF surface (RH, cloud)."""
    from scipy.ndimage import gaussian_filter
    opt=opt.copy().reset_index(drop=True);hold=hold.copy().reset_index(drop=True)
    def which(d):
        x=np.clip(d.wa_humidity.fillna(50).to_numpy(float),0,100)
        y=np.clip(d.wa_cloud.fillna(50).to_numpy(float),0,100)
        return (np.clip((x/100*20).astype(int),0,19),np.clip((y/100*20).astype(int),0,19))
    def fit_apply(tr,te):
        aa,bb=which(tr)
        rr=(tr.energy.to_numpy(float)-tr.pred_kwh.to_numpy(float))/np.maximum(tr.cap.to_numpy(float),1.)
        rr=np.clip(rr,-.4,.4)
        num=np.zeros((20,20));cnt=np.zeros((20,20))
        np.add.at(num,(aa,bb),rr);np.add.at(cnt,(aa,bb),1.)
        n=gaussian_filter(num,sigma=1.4,mode='nearest');c=gaussian_filter(cnt,sigma=1.4,mode='nearest')
        surf=n/(c+25.); xx,yy=which(te)
        return surf[xx,yy],surf,cnt
    oo=np.zeros(len(opt))
    for fold,(tr,va) in enumerate(_groups(opt)):
        value,_,_=fit_apply(opt.iloc[tr],opt.iloc[va]);oo[va]=value*opt.cap.to_numpy(float)[va]
    hh,surf,counts=fit_apply(opt,hold)
    np.savez_compressed(ws.path('rh_cloud_kernel_surface.npz'),residual_cf=surf,cell_count=counts)
    hh*=hold.cap.to_numpy(float);alpha=_line_scan_alpha(ws,opt,oo)
    return clip_predictions(opt,opt.pred_kwh+alpha*oo),clip_predictions(hold,hold.pred_kwh+alpha*hh),{'algorithm':'F12 RH-cloud 2D Gaussian kernel surface','alpha':alpha}

# ---------------------------------------------------------
# Model-retraining variants: physically motivated features, DRO, weather BMA.
# Uses same 60/20/20 model_train only; holdout labels never enter training.
# ---------------------------------------------------------

def _train_retrained(ws, variant, extra_fn=None, custom_weight=None, feature_cols=None, data=None):
    """Four independent 10/17 LGBM/Cat models; checkpoint after every model and split prediction."""
    root=ws.root; base=augmented_baseline(import_baseline(root))
    sites=read_sites(root)
    if data is None:
        gen=read_generation(root)
        fit,opt,hold,_=split_frames(gen)
        del gen
    else:fit,opt,hold=data
    fa,fb=weather_features(root,base)
    price=read_price(root)
    frames={'group_opt':opt,'holdout':hold}
    for r in (10,17):
        for m in ('lgb','cat'):
            ck=ws.path(f'{variant}_{m}_r{r}.pkl')
            if not ck.exists():
                d=df_features(base,fit,sites,fa,fb,r)
                if extra_fn is not None:d=extra_fn(d, r)
                feats=list(base.FEATS)+(feature_cols or [])
                d=d[d.elev>0].copy()
                X,y=frame_xy(d,feats)
                w=weight_for_rows(d,price,capacity=True)
                if custom_weight is not None:w=w*np.asarray(custom_weight(d),float)
                w=w/max(w.mean(),1e-12)
                model=fit_model(m,X,y,w)
                _save(ws,ck.name,model)
                del d,X,y,w,model
                log(f'Rank {ws.rank} trained/checkpointed {m} round={r}')
        for name,raw in frames.items():
            cpath=ws.path(f'{variant}_{name}_r{r}.parquet')
            if cpath.exists():continue
            d=df_features(base,raw,sites,fa,fb,r)
            if extra_fn is not None:d=extra_fn(d,r)
            X,_=frame_xy(d,list(base.FEATS)+(feature_cols or []))
            one=d[['site_id','ts']].copy()
            for m in ('lgb','cat'):
                model=load_model(ws.path(f'{variant}_{m}_r{r}.pkl'))
                p=model.predict(X)
                one[m]=np.maximum(np.where(d.elev.to_numpy()>0,p,0.),0.)*d.cap.to_numpy(float)
            one.to_parquet(cpath,index=False)
            del d,X,one
    result={}
    for name,raw in frames.items():
        a=pd.read_parquet(ws.path(f'{variant}_{name}_r10.parquet'))
        b=pd.read_parquet(ws.path(f'{variant}_{name}_r17.parquet'))
        x=a.merge(b,on=['site_id','ts'],suffixes=('_10','_17'),validate='one_to_one')
        x['pred_kwh']=.25*(x.lgb_10+x.cat_10+x.lgb_17+x.cat_17)
        result[name]=x[['site_id','ts','pred_kwh']].copy()
    return result


def _attach_prediction(opt,hold,result):
    ret=[]
    for name,d in [('group_opt',opt),('holdout',hold)]:
        p=result[name]
        out=d.drop(columns=['pred_kwh']).merge(p,on=['site_id','ts'],validate='one_to_one',how='left')
        if len(out)!=len(d) or out.pred_kwh.isna().any(): raise ValueError('Retrained predictions missing')
        ret.append(clip_predictions(out,out.pred_kwh.to_numpy(float)))
    return ret[0],ret[1]


def _solar_interval_extra(d,r):
    # baseline.solar calculates at center(ts - 30min). Shift center +/-20min for quadrature.
    bas=_solar_interval_extra.base
    t=pd.DatetimeIndex(d.ts)
    la=d.lat.to_numpy(float);lo=d.lon.to_numpy(float)
    samples=[bas.solar(t+pd.Timedelta(minutes=shift),la,lo) for shift in (-20,0,20)]
    d['hour_elev_avg']=np.mean([x[0] for x in samples],axis=0).astype('float32')
    d['hour_cosz_avg']=np.mean([np.maximum(x[2],0) for x in samples],axis=0).astype('float32')
    return d


def rank_9(ws,opt,hold,sites):
    _solar_interval_extra.base=import_baseline(ws.root)
    result=_train_retrained(ws,'hour_integral',_solar_interval_extra,feature_cols=['hour_elev_avg','hour_cosz_avg'])
    p,q=_attach_prediction(opt,hold,result)
    return p,q,{'algorithm':'A3 3-point right-closed hourly solar quadrature features','quadrature_minute_offsets':[-20,0,20]}


def _site_orientation(ws):
    root=ws.root;sites=read_sites(root)
    gen=read_generation(root);fit,_,_,_=split_frames(gen)
    del gen
    base=augmented_baseline(import_baseline(root));fa,fb=weather_features(root,base)
    d=df_features(base,fit,sites,fa,fb,17)
    d=d[(d.elev>15)&(d.wa_cloud<45)&d.energy.notna()].copy()
    d['cf']=(d.energy/d.cap).clip(0,1.2)
    tilt_grid=np.arange(0,61,10); az_grid=np.arange(130,231,20)
    info={}
    for site,part in d.groupby('site_id'):
        x=part[['elev','azim','cf']].dropna()
        if len(x)>700: x=x.sample(700,random_state=42)
        if len(x)<20:info[str(site)]={'tilt':20.,'azimuth':180.,'n':int(len(x))};continue
        elev=np.deg2rad(x.elev.to_numpy(float));sunaz=np.deg2rad(x.azim.to_numpy(float)); y=x.cf.to_numpy(float)
        best=(float('inf'),20.,180.)
        for tilt in tilt_grid:
            tl=np.deg2rad(tilt)
            for az in az_grid:
                normal=np.cos(tl)*np.sin(elev)+np.sin(tl)*np.cos(elev)*np.cos(sunaz-np.deg2rad(az))
                normal=np.maximum(normal,0)
                # Fit only scale and offset; if training sunshine coverage poor, regularized default wins.
                a=np.column_stack((normal,np.ones(len(normal))))
                coeff=np.linalg.lstsq(a,y,rcond=None)[0]
                cost=np.mean((a@coeff-y)**2)+1e-5*((tilt-20.)/20)**2
                if cost<best[0]:best=(float(cost),float(tilt),float(az))
        info[str(site)]={'tilt':best[1],'azimuth':best[2],'n':int(len(x))}
    ws.checkpoint('orientation_parameters.json',info)
    return info


def rank_7(ws,opt,hold,sites):
    info=json.loads(ws.path('orientation_parameters.json').read_text()) if ws.path('orientation_parameters.json').exists() else _site_orientation(ws)
    def feature(d,r):
        tilt=np.deg2rad(d.site_id.map(lambda z:info.get(str(z),{'tilt':20})['tilt']).to_numpy(float))
        az=np.deg2rad(d.site_id.map(lambda z:info.get(str(z),{'azimuth':180})['azimuth']).to_numpy(float))
        el=np.deg2rad(d.elev.to_numpy(float));sa=np.deg2rad(d.azim.to_numpy(float))
        d['poa_direction_cos']=np.maximum(np.cos(tilt)*np.sin(el)+np.sin(tilt)*np.cos(el)*np.cos(sa-az),0).astype('float32')
        return d
    result=_train_retrained(ws,'orientation',feature,feature_cols=['poa_direction_cos'])
    a,b=_attach_prediction(opt,hold,result)
    return a,b,{'algorithm':'A1 orientation proxy from fit-only clear-sky rows, original coordinates never recovered'}


def _site_temperature(ws):
    root=ws.root;sites=read_sites(root)
    gen=read_generation(root);fit,_,_,_=split_frames(gen);del gen
    base=augmented_baseline(import_baseline(root));fa,fb=weather_features(root,base)
    d=df_features(base,fit,sites,fa,fb,17)
    d=d[(d.elev>10)&d.wa_temp.notna()&d.wa_cloud.notna()].copy()
    info={}
    for sid,g in d.groupby('site_id'):
        if len(g)>10000:g=g.sample(10000,random_state=42)
        if len(g)<100:info[str(sid)]=0.;continue
        y=(g.energy/g.cap).clip(0,1.2).to_numpy(float)
        temp=g.wa_temp.to_numpy(float)
        el=np.maximum(g.cosz.to_numpy(float),0)
        cloud=g.wa_cloud.to_numpy(float)/100.
        a=np.column_stack([el,el*cloud,el*(temp-25),np.ones(len(g))])
        # ridge regularization stabilizes high-cloud / temperature correlation.
        beta=np.linalg.solve(a.T@a+np.diag([1.,1.,100.,1.]),a.T@y)
        info[str(sid)]=float(np.clip(beta[2],-.02,0.))
    ws.checkpoint('temperature_coefficients.json',info)
    return info


def rank_16(ws,opt,hold,sites):
    info=json.loads(ws.path('temperature_coefficients.json').read_text()) if ws.path('temperature_coefficients.json').exists() else _site_temperature(ws)
    def fe(d,r):
        coef=d.site_id.map(lambda v: info.get(str(v),0.)).to_numpy(float)
        d['site_temp_coefficient']=coef.astype('float32')
        d['site_temperature_loss']=(coef*np.maximum(d.cosz.to_numpy(float),0)*(d.wa_temp.to_numpy(float)-25)).astype('float32')
        return d
    result=_train_retrained(ws,'temperature',fe,feature_cols=['site_temp_coefficient','site_temperature_loss'])
    p,q=_attach_prediction(opt,hold,result)
    return p,q,{'algorithm':'A9 site-specific fit-only effective temperature sensitivity feature','n_sites':len(info)}


def rank_12(ws,opt,hold,sites):
    """D8: soft-downweight only high-confidence unexplained midday zeros in model-fit."""
    def weight(d):
        # Do not discard data: suspect daytime near-zero only under clear, UV>3 and elev>25.
        suspect=(d.energy.to_numpy(float)<.001*d.cap.to_numpy(float)) & (d.wa_cloud.to_numpy(float)<20) & (d.wb_uv_idx.to_numpy(float)>3) & (d.elev.to_numpy(float)>25)
        return np.where(suspect,.2,1.)
    result=_train_retrained(ws,'robust_target',custom_weight=weight)
    p,q=_attach_prediction(opt,hold,result)
    return p,q,{'algorithm':'D8 anomalous clear-sky zero softdownweight','weight':.2}


def rank_15(ws,opt,hold,sites):
    """D5: three-step fit-only Group-DRO-style multiplicative adversarial reweighting.

    Validated on a nested subset of model_train; no groupopt/holdout labels used
    to decide difficult weather groups. Four full LGB/Cat models fit only after
    the three group-weight updates.
    """
    from lightgbm import LGBMRegressor
    root=ws.root; gen=read_generation(root);fit,_,_,_=split_frames(gen);del gen
    fit=_subsample(fit,min(ws.max_neural_train,150000),42)
    base=augmented_baseline(import_baseline(root));fa,fb=weather_features(root,base)
    d=df_features(base,fit,sites,fa,fb,17)
    d=d[d.elev>0].copy().reset_index(drop=True)
    def group(d):
        cl=d.wa_cloud.fillna(50).to_numpy(float)
        rn=d.wa_rain.fillna(0).to_numpy(float)
        return np.where(rn>0,2,np.where(cl>75,1,0)).astype(int)
    region=group(d)
    # Nested day split within primary training period, NEVER using groupopt/holdout.
    ds=pd.DatetimeIndex(days(d.ts).drop_duplicates().sort_values())
    if len(ds)<10:raise ValueError('Need 10 or more training days for Group DRO')
    rng=np.random.default_rng(42);perm=rng.permutation(len(ds));cut=max(1,int(.8*len(ds)))
    tr=np.flatnonzero(days(d.ts).isin(ds[perm[:cut]]).to_numpy())
    va=np.flatnonzero(days(d.ts).isin(ds[perm[cut:]]).to_numpy())
    x,y=frame_xy(d,list(base.FEATS))
    price=read_price(root);pweights=weight_for_rows(d,price,capacity=True)
    density=np.array([max(1,int(np.sum(region[tr]==j))) for j in range(3)],float)
    # Train each group with equal initial mass; update weights by worst-regime losses.
    balance=np.minimum(4.,density.sum()/density/3.)
    group_weight=np.ones(3,dtype=float)
    trace=[]
    for step in range(3):
        ww=pweights[tr]*balance[region[tr]]*group_weight[region[tr]]
        ww=ww/max(ww.mean(),1e-12)
        preview=LGBMRegressor(objective='regression_l1',n_estimators=140,learning_rate=.07,num_leaves=31,
                min_child_samples=100,verbosity=-1,n_jobs=4,random_state=42+step)
        preview.fit(x.iloc[tr],y.iloc[tr],sample_weight=ww)
        pred=preview.predict(x.iloc[va]);rr=np.abs(pred-y.to_numpy(float)[va])
        loss=np.array([float(np.average(rr[region[va]==j],weights=pweights[va][region[va]==j]))
                if np.any(region[va]==j) else 0. for j in range(3)])
        nonzero=loss[loss>0]
        factor=np.exp(np.clip(2*(loss/max(nonzero.mean(),1e-6)-1),-1,1))
        group_weight*=factor
        group_weight/=max(float(np.exp(np.mean(np.log(group_weight)))),1e-12)
        group_weight=np.clip(group_weight,.4,3.)
        trace.append({'step':step+1,'group_validation_MAE_CF':loss.tolist(),'group_weight':group_weight.tolist()})
    ws.checkpoint('group_dro_adversarial_weights.json',{'balance':balance.tolist(),
        'adversarial_weight':group_weight.tolist(),'trace':trace,'n_fit_preview':len(d),
        'method':'multiplicative three-step adversarial group weight updates on nested fit-only validation'})
    def weight(d):
        return balance[group(d)]*group_weight[group(d)]
    res=_train_retrained(ws,'weather_group_dro',custom_weight=weight)
    p,q=_attach_prediction(opt,hold,res)
    return p,q,{'algorithm':'D5 weather-regime Group-DRO style iterative minimax surrogate',
        'adversarial_group_weights':group_weight.tolist(),'n_updates':3,
        'note':'group DRO applied to training-site weighted L1 per meteorological group, not exact final group sum W'}

def _observed_weather(root):
    src=root/'output'/'preprocessed'/'train'
    obs=[]
    for a in ('wa','wb'):
        path=src/f'observed_{a}.parquet'
        if not path.exists():
            raise FileNotFoundError(f'{path} needed for observed-weather teacher/BMA; no test observations are used')
        d=pd.read_parquet(path);d['ts']=to_kst(d.ts)
        obs.append(d)
    return obs


def rank_5(ws,opt,hold,sites):
    """A7: privileged observed-weather teacher (fit only) distilled into forecast-only student."""
    from lightgbm import LGBMRegressor
    root=ws.root;gen=read_generation(root);fit,_,_,_=split_frames(gen);del gen
    fit=_subsample(fit,ws.max_neural_train,42)
    base=augmented_baseline(import_baseline(root));fa,fb=weather_features(root,base)
    oa,ob=_observed_weather(root)
    d=df_features(base,fit,sites,fa,fb,17)
    wa_name='wa_station';wb_name='wb_station'
    use_a=[c for c in ['wa_cloud','wa_temp','wa_humidity'] if c in oa]
    use_b=[c for c in ['wb_cloud','wb_temp','wb_rel_hum','wb_uv_idx'] if c in ob]
    oa=oa[[wa_name,'ts']+use_a].rename(columns={c:'observed_'+c for c in use_a})
    ob=ob[[wb_name,'ts']+use_b].rename(columns={c:'observed_'+c for c in use_b})
    d=d.merge(oa,on=['wa_station','ts'],how='left',validate='many_to_one')
    d=d.merge(ob,on=['wb_station','ts'],how='left',validate='many_to_one')
    observed=['observed_'+c for c in use_a+use_b]
    if not observed:raise RuntimeError('No usable observed weather fields')
    d=d[d.elev>0].reset_index(drop=True)
    x,y=frame_xy(d,list(base.FEATS)+observed)
    # Two-fold teacher OOF prevents student learning memorized teacher predictions.
    from sklearn.model_selection import KFold
    teacher_targets=np.zeros(len(d));paths=[]
    for fold,(tr,va) in enumerate(KFold(n_splits=2,shuffle=True,random_state=42).split(d)):
        m=LGBMRegressor(n_estimators=280,learning_rate=.055,num_leaves=31,min_child_samples=160,verbosity=-1,n_jobs=4)
        m.fit(x.iloc[tr],y.iloc[tr]);teacher_targets[va]=m.predict(x.iloc[va])
        _save(ws,f'teacher_fold_{fold}.pkl',m);paths.append(f'teacher_fold_{fold}.pkl')
    # Fixed teacher-student distillation weight; student never receives observed fields.
    target=.65*y.to_numpy(float)+.35*np.clip(teacher_targets,0,1.2)
    student=LGBMRegressor(n_estimators=500,learning_rate=.055,num_leaves=63,min_child_samples=180,verbosity=-1,n_jobs=4)
    student.fit(d[base.FEATS].astype('float32'),target)
    _save(ws,'forecast_only_student.pkl',student)
    result=[]
    for part in [opt,hold]:
        obs=part[['site_id','ts']]
        # Student uses only weather forecasts, never observation columns at inference.
        frame=df_features(base,obs,sites,fa,fb,17)
        p=np.clip(student.predict(frame[base.FEATS].astype('float32')),0,None)*frame.cap.to_numpy(float)
        pred=.65*part.pred_kwh.to_numpy(float)+.35*p
        result.append(clip_predictions(part,pred))
    return result[0],result[1],{'algorithm':'A7 fit-only observed weather 2-fold teacher => forecast-only distilled student','teacher_fields':observed,'student_blend':.35}


def rank_10(ws,opt,hold,sites):
    """A8: historical observed A/B cloud reliability -> conditional BMA cloud feature + refit."""
    root=ws.root; oa,ob=_observed_weather(root)
    base=augmented_baseline(import_baseline(root));fa,fb=weather_features(root,base)
    def reliab(fc,obs,key,col):
        merged=fc[[key,'ts','round',col]].merge(obs[[key,'ts',col]],on=[key,'ts'],suffixes=('_forecast','_actual'),how='inner')
        merged=merged[np.isfinite(merged[col+'_actual'])&np.isfinite(merged[col+'_forecast'])]
        if len(merged)<100:return np.ones(4)
        cloud=merged[col+'_forecast'].to_numpy(float)
        bins=np.clip((cloud//25).astype(int),0,3)
        err=(merged[col+'_forecast'].to_numpy(float)-merged[col+'_actual'].to_numpy(float))**2
        return np.array([float(np.mean(err[bins==k])) if (bins==k).sum()>100 else float(np.mean(err)) for k in range(4)])+1.
    a=reliab(fa,oa,'wa_station','wa_cloud');b=reliab(fb,ob,'wb_station','wb_cloud')
    # condition on cloudiness regime; Bayesian inverse-variance proxy, not posterior MCMC
    ws.checkpoint('weather_bma_cloud_var.json',{'A':a.tolist(),'B':b.tolist()})
    def feature(d,r):
        cA=d.wa_cloud.fillna(50).to_numpy(float);cB=d.wb_cloud.fillna(50).to_numpy(float)
        va=a[np.clip((cA//25).astype(int),0,3)];vb=b[np.clip((cB//25).astype(int),0,3)]
        pa=(1/va)/((1/va)+(1/vb)); d['bma_cloud']=(pa*cA+(1-pa)*cB).astype('float32')
        d['bma_cloud_weight_a']=pa.astype('float32')
        return d
    result=_train_retrained(ws,'bma',feature,feature_cols=['bma_cloud','bma_cloud_weight_a'])
    p,q=_attach_prediction(opt,hold,result)
    return p,q,{'algorithm':'A8 conditional inverse-variance BMA-style weather reliability','disclaimer':'same-station observed providers are distinct; BMA-style feature not strict hierarchical Bayesian posterior'}


def rank_20(ws,opt,hold,sites):
    """A6: daytime low-output probability hurdle paired with existing positive output regression."""
    from lightgbm import LGBMClassifier
    root=ws.root;g=read_generation(root);fit,_,_,_=split_frames(g);del g
    fit=_subsample(fit,ws.max_neural_train,42)
    base=augmented_baseline(import_baseline(root));fa,fb=weather_features(root,base)
    d=df_features(base,fit,sites,fa,fb,17)
    d=d[d.elev>5].copy()
    features=list(base.FEATS)
    X,_=frame_xy(d,features)
    y=(d.energy.to_numpy(float)<=.002*d.cap.to_numpy(float)).astype(int)
    if y.sum()<30:
        log('Hurdle: daytime zero outputs too rare -> no-op with explicit diagnostic')
        ws.checkpoint('hurdle_diagnostic.json',{'n_daytime_zeros':int(y.sum()),'n_total':int(len(y)),'reason':'insufficient positive labels'})
        return opt.pred_kwh.to_numpy(float),hold.pred_kwh.to_numpy(float),{'algorithm':'A6 no effect: insufficient daytime zeros'}
    classifier=LGBMClassifier(n_estimators=350,learning_rate=.05,num_leaves=31,random_state=42,verbosity=-1,n_jobs=4)
    classifier.fit(X,y)
    _save(ws,'daytime_zero_classifier.pkl',classifier)
    out=[]
    for target in [opt,hold]:
        frame=df_features(base,target[['site_id','ts']],sites,fa,fb,17)
        Xt,_=frame_xy(frame,features)
        p=classifier.predict_proba(Xt)[:,1]
        pred=target.pred_kwh.to_numpy(float)*(1-np.clip(p,0,.8))
        out.append(clip_predictions(target,pred))
    return out[0],out[1],{'algorithm':'A6 daytime hurdle classifier plus positive-output No.28 prediction','train_zero_fraction':float(y.mean())}
