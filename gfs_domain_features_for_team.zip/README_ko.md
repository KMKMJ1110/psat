# ☀️ GFS 4대 도메인 물리 피처 팩 (v1.0.0) — Technical Documentation

본 피처 패키지는 태양광 발전량 예측 파이프라인의 열역학적·천문학적 물리 타당성을 강화하고, 기상 예보 불확실성에 따른 오차를 정량 보정하기 위해 구축된 **4대 도메인 물리 피처 팩 (`gfs_domain_features4.parquet`)**입니다.

기존 단순 기상 변수 산출 방식에서 벗어나 **태양광 모듈 방열 메커니즘, NREL SPA 정밀 고도각, 글로벌/지역 예보 불일치 스파이크, 복사안개에 의한 오전 램프업 지연 현상**을 정교한 물리 수식으로 정량화했습니다.

---

## 📄 파일 구성 및 메타데이터 (Manifest)

- **메인 피처 파일**: `gfs_domain_features4.parquet`
- **전체 데이터 규모**: 총 8개 핵심 컬럼 (`site_id`, `ts` 포함), 대상 전체 타임스탬프 지원
- **시간 축 기준**: `ts` (KST, `Asia/Seoul` 타임존 규격)
- **결합 방식 (Join Key)**: `['site_id', 'ts']` 기준 Left Join

### 동봉 메타데이터 문서
1. `feature_audit.csv`: 전체 피처에 대한 결측률(Null %), 평균, 표준편차, 최솟값/최댓값 기초통계 보고서
2. `feature_groups.json`: 도메인 영역별(Thermodynamics, Solar Astronomy, Forecast Discrepancy, Humidity Lag) 피처 그룹 분류 정의서
3. `manifest.json`: 버전 정보, 생성 시각, 전체 행/사이트 수 및 스키마 명세서
4. `verification.json`: 데이터 무결성 및 인덱스 정합성 검증서

---

## 📌 피처 상세 설계 및 물리 메커니즘 (Physical Rationale)

### 1. 열역학 모듈 가열 및 대류 방열 지수 (`thermodynamics`)

* **도입 배경 (Why)**
  태양광 결정질 실리콘 셀은 표준시험조건(STC, 모듈 온도 25℃, 일사량 1000 W/m²)을 초과할 경우, 온도가 1℃ 상승할 때마다 발전 효율이 약 -0.4%/℃ 하강하는 음(-)의 온도 계수를 가집니다. 기존 모델이 단순 외기온도(T_air)만 사용할 경우, 한낮 직사일사로 인한 패널 가열 현상과 바람에 의한 대류 방열(Cooling) 효과를 반영하지 못해 여름철 한낮 발전량을 과대 예측하는 시스템 오차가 발생합니다.

* **물리 수식 및 연산 로직 (How)**
  외기온(T_air, wa_ta), 일사량(S, wa_ssrd), 풍속(V, wa_ws)을 통합하여 모듈 실질 작동 온도(T_module)를 추정하고, 25℃ 초과 구간에 대한 효율 저하 팩터를 정량화했습니다.

  T_module = T_air + (S / (25.0 + 1.2 * V))
  gfs_temp_eff_factor = 1.0 - 0.004 * max(0, T_module - 25.0)

* **제공 컬럼**: `gfs_wind_speed`, `gfs_t_module`, `gfs_temp_eff_factor`

---

### 2. NREL SPA 기반 정밀 태양 고도각 (`solar_astronomy`)

* **도입 배경 (Why)**
  단순 시간대(Hour)나 월(Month) 변수는 계절 변화에 따른 태양 남중고도 변화 및 대기질량(Air Mass) 통과 거리에 따른 기하학적 일사 입사각(Cos θ) 변화를 정교하게 학습하기 어렵습니다.

* **물리 수식 및 연산 로직 (How)**
  미국 국립재생에너지연구소(NREL)의 SPA(Solar Position Algorithm) 수식 기반 `pvlib` 엔진을 적용하여, 각 발전소 부지의 위도(Latitude)·경도(Longitude)와 시각 타임스탬프(`ts`) 기준 태양 고도각(Elevation Angle)을 0.01° 단위로 정밀 산출했습니다. 일몰 이후 야간 구간은 0°로 클리핑(Clipping) 처리했습니다.

* **제공 컬럼**: `solar_elevation`

---

### 3. GFS vs WA 예보 불일치 및 국소 기상 급변 지수 (`forecast_discrepancy`)

* **도입 배경 (Why)**
  글로벌 지구예보 모델(GFS)과 1순위 지역 기상관측소(WA) 간 일사량 예측값의 차이가 클 때는 국소 소나기구름, 통과성 적운, 층운 발달 등 기상 이변이 발생하는 높은 불확실성 구간입니다.

* **물리 수식 및 연산 로직 (How)**
  GFS 대표 일사량 격자 평균값과 WA 지역 관측소 일사량 예보값의 절대 편차를 계산하여, 트리 모델(LightGBM/CatBoost)이 예보 불확실성이 높은 구간을 감지하고 예측치를 보수적으로 분기(Split)하도록 차분 스파이크 힌트를 제공합니다.

  cloud_diff_gfs_wa = |SSRD_WA - SSRD_GFS|

* **제공 컬럼**: `cloud_diff_gfs_wa`

---

### 4. 복사안개/이슬 아침 램프업 지연 지수 (`humidity_lag`)

* **도입 배경 (Why)**
  오전 시간대(07~09시) 지표면 복사냉각으로 인한 짙은 안개나 패널 표면 이슬(서리) 맺힘은 해가 뜬 직후 빛을 반사·차단시켜 발전량 솟구침(Ramp-up)을 1~2시간 지연시킵니다. 이 현상을 반영하지 않으면 아침 시간대 과대 예측 페널티가 크게 발생합니다.

* **물리 수식 및 연산 로직 (How)**
  오전 07~09시 조건부 이진 마스크와 상대습도 수치(RH / 100)를 결합하여, 습도가 높을수록 오전 발전 램프업 지연 손실이 커짐을 정량적 지수로 표현했습니다.

  morning_dew_index = I(hour in {7, 8, 9}) * (RH_WA / 100)

* **제공 컬럼**: `morning_dew_index`

---

## 🛡️ 데이터 누수 방지 및 검증 무결성 (Validation Safeguards)

1. **미래 정보 참조 차단 (No Data Leakage)**: 모든 피처는 해당 시점(`ts`) 이전에 가용한 기상 예보 및 천문 수식만을 이용하여 산출되었으며, 타깃 변수(`energy`)나 미래 시점 관측 데이터를 전혀 참조하지 않았습니다.
2. **시계열 인덱스 정합성**: `ts` 타임스탬프는 `Asia/Seoul` KST 기준 timezone-aware 형식으로 통일되어 결합 시 시간 축 어긋남 현상을 원천 차단했습니다.
3. **학습 분할 독립성**: 파이프라인 결합 시 각 Split(Fold) 내부에서 독립적으로 `Left Join`이 수행되도록 설계되어 Holdout 및 Test 평가 무결성을 보장합니다.

---

## 🚀 파이프라인 결합 및 통합 가이드 (Integration Guide)

기존 파이프라인 코드 내부의 피처 생성 함수(`features_plus` 또는 `build_features`) 안에서 아래와 같이 `site_id`와 `ts`를 기준으로 병합하여 사용합니다.

```python
import pandas as pd

# 1. 팀 공유 피처 팩 로드
domain_df = pd.read_parquet('gfs_domain_features4.parquet')

# 2. 타임존 정규화 (KST 보장)
if domain_df['ts'].dt.tz is None:
    domain_df['ts'] = pd.to_datetime(domain_df['ts']).dt.tz_localize('Asia/Seoul')
else:
    domain_df['ts'] = domain_df['ts'].dt.tz_convert('Asia/Seoul')

# 3. 기존 피처 생성 함수 내 결합 로직
def features_plus(sites, gen, base, *args, **kwargs):
    # 기존 베이스라인 피처 생성
    df = base.features(sites, gen, base)

    # 4대 도메인 물리 피처 좌측 결합 (Left Join)
    init_len = len(df)
    df = df.merge(domain_df, on=['site_id', 'ts'], how='left')
    assert len(df) == init_len, 'Merge 과정에서 행 수가 변형되었습니다.'

    return df
```

---

## 📚 참고 문헌 및 표준 규격 (References)

* **Sandia National Laboratories**: *Photovoltaic Array Performance Model (SAPM) — Cell Temperature Derating Equations.*
* **NREL (National Renewable Energy Laboratory)**: *Solar Position Algorithm (SPA) for Solar Radiation Applications.*
* **PVsyst Technical Documentation**: *Thermal Loss Effect and Temperature Coefficient Ratio on Photovoltaic Modules.*
