﻿"""42번 트리 + 명준 MLP + 발전소별 TabPFN 섞기 + 시간별 배율 (재학습 없음).
위치: codes/mix_all.py
실행: python codes/mix_all.py
필요:
  output/feat_site/random/                 (트리, feat_site.py 결과)
  output/site_tabpfn/random/tabpfn_eval_pred.parquet   (site_tabpfn.py 결과)
  output/sleeping_ranking_50/...          (명준 MLP, 없으면 MLP 빼고 진행)

비율 후보: TabPFN 0 / 0.1 / 0.2 / 0.3, MLP 0.3 / 0.4 / 0.5, 나머지 트리 (트리 최소 0.2)
(mix_mlp 결과: 트리 60 : MLP 40 + 시간별 배율이 group_opt 기준 최선, holdout 58,096,215)
비율은 group_opt_optimized 가 제일 낮은 걸로 고르기 (holdout 은 확인용)
"""
import numpy as np
import pandas as pd

import baseline_validation as val
import baseline_optimizer as opt
import feat_site as fs

ROOT = val.DEFAULT_ROOT
opt.log = lambda message: None
OURS = ROOT / "output" / "feat_site" / "random"
TAB = ROOT / "output" / "site_tabpfn" / "random_big" / "tabpfn_eval_pred.parquet"
MJ = ROOT / "output" / "sleeping_ranking_50"
WA = 0.75
TAB_LIST = [0.4, 0.5, 0.6]
MLP_LIST = [0.2, 0.3, 0.4]
TREE_MIN = 0.1


def load_mlp():
    parts = []
    for part in ["group_opt", "holdout"]:
        base28 = pd.read_parquet(MJ / "_baseline_cache" / (part + "_predictions.parquet"),
                                 columns=["site_id", "ts", "pred_kwh"])
        cand = pd.read_parquet(MJ / "new_cand_17_tide_day_curve" / ("candidate_" + part + "_predictions.parquet"))
        d = base28.merge(cand, on=["site_id", "ts"], suffixes=("_28", "_cand"))
        d["mlp_kwh"] = ((d["pred_kwh_cand"] - 0.6 * d["pred_kwh_28"]) / 0.4).clip(lower=0)
        parts.append(d[["site_id", "ts", "mlp_kwh"]])
    mlp = pd.concat(parts, ignore_index=True)
    mlp["ts"] = val.to_kst(mlp["ts"])
    return mlp


def main():
    base = val.load_module(ROOT / "baseline.py", "oibc_baseline_mixall")
    sites = pd.read_csv(ROOT / "sites.csv")[[
        "site_id", "current_group", "capacity_kw", "lat", "lon",
        "wa_station", "wb_station"]]

    gen = pd.read_parquet(ROOT / "train" / "generation.parquet", columns=["site_id", "ts", "energy"])
    gen["ts"] = val.to_kst(gen["ts"])
    baseline_gen = gen[gen["ts"] >= base.TRAIN_FROM].copy()
    _, group_actual, hold_actual, _ = val.split_602020(baseline_gen, val.SEED)
    del gen, baseline_gen

    # 트리 (42번)
    pa = pd.read_parquet(OURS / "l1_cap_smpk_eval_pred.parquet")
    pb = pd.read_parquet(OURS / "cat_l1_cap_smpk_eval_pred.parquet")
    both = pa.merge(pb, on=["site_id", "ts"], suffixes=("_a", "_b"))
    d = both[["site_id", "ts"]].copy()
    d["tree"] = WA * both["pred_kwh_a"] + (1 - WA) * both["pred_kwh_b"]

    # TabPFN
    tab = pd.read_parquet(TAB).rename(columns={"pred_kwh": "tab"})
    tab["ts"] = val.to_kst(tab["ts"])
    d = d.merge(tab, on=["site_id", "ts"], how="left")
    d["tab"] = d["tab"].fillna(d["tree"])

    # MLP (있으면)
    mlp_list = MLP_LIST
    if (MJ / "new_cand_17_tide_day_curve" / "candidate_holdout_predictions.parquet").exists():
        mlp = load_mlp()
        d = d.merge(mlp, on=["site_id", "ts"], how="left")
        print("MLP 붙은 행:", int(d["mlp_kwh"].notna().sum()), "/", len(d))
        d["mlp"] = d["mlp_kwh"].fillna(d["tree"])
    else:
        print("명준 MLP 파일 없음 -> MLP 빼고 진행")
        d["mlp"] = d["tree"]
        mlp_list = [0.0]

    # 밤(트리 0)은 전부 0
    night = d["tree"] <= 0
    d.loc[night, "tab"] = 0.0
    d.loc[night, "mlp"] = 0.0

    init_mask = opt.initial_mask(sites)
    rows = []
    for w_tab in TAB_LIST:
        for w_mlp in mlp_list:
            w_tree = 1 - w_tab - w_mlp
            if w_tree < TREE_MIN - 1e-9:
                continue
            pred = d[["site_id", "ts"]].copy()
            pred["pred_kwh"] = w_tree * d["tree"] + w_mlp * d["mlp"] + w_tab * d["tab"]
            label = ("트리 " + str(int(round(w_tree * 100))) + " / MLP " + str(int(round(w_mlp * 100)))
                     + " / TabPFN " + str(int(round(w_tab * 100))))

            Pg, Yg, tg = fs.to_mats(group_actual, pred, sites.site_id)
            Ph, Yh, th = fs.to_mats(hold_actual, pred, sites.site_id)
            wg = opt.time_weights(ROOT, tg)
            c_hour = {}
            for h in range(24):
                idx = (tg.hour == h)
                if idx.sum() == 0:
                    c_hour[h] = 1.0
                else:
                    c_hour[h] = fs.best_c(Pg[idx], Yg[idx], wg[idx])

            for how in ["보정 없음", "시간별 배율"]:
                pred_h = pred.merge(hold_actual[["site_id", "ts"]], on=["site_id", "ts"])
                if how == "보정 없음":
                    cg, ch = 1.0, 1.0
                else:
                    cg = np.array([c_hour[h] for h in tg.hour])[:, None]
                    ch = np.array([c_hour[h] for h in th.hour])[:, None]
                    pred_h["pred_kwh"] = pred_h["pred_kwh"] * pred_h["ts"].dt.hour.map(c_hour)
                m_h = val.model_metrics(ROOT, hold_actual, pred_h)

                mat_g = cg * Pg - Yg
                mat_h = ch * Ph - Yh
                optimized, meta, trace = opt.greedy_best_improvement(mat_g, wg, sites, init_mask)
                score_g = val.score_group(opt, ROOT, mat_g, tg, init_mask, optimized)
                score_h = val.score_group(opt, ROOT, mat_h, th, init_mask, optimized)
                row = {"blend": label, "fix": how,
                       "weighted_MAE": round(m_h["weighted_MAE_kwh"], 5),
                       "group_opt_optimized": round(score_g["W_optimized_krw"]),
                       "initial": round(score_h["W_initial_krw"]),
                       "optimized": round(score_h["W_optimized_krw"]),
                       "lower_bound": round(score_h["W_lower_bound_krw"])}
                rows.append(row)
                print(label, how, "| 최적", f"{row['optimized']:,}", "| group_opt", f"{row['group_opt_optimized']:,}")

    table = pd.DataFrame(rows)
    table.to_csv(OURS / "mix_all_result.csv", index=False)
    best = table.loc[table["group_opt_optimized"].idxmin()]
    print("=" * 70)
    print("비교: 트리 60 : MLP 40 + 시간별 배율 (TabPFN 없음) 58,096,215 / 명준 1등 58,744,359")
    print(table.to_string(index=False))
    print("-" * 70)
    print("group_opt 기준 최선:", best["blend"], best["fix"], "-> holdout 최적", f"{best['optimized']:,}")


if __name__ == "__main__":
    main()
